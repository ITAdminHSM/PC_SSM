@echo off
echo Cleaning PC Care Pro build artifacts...

if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"
if exist ".pytest_cache" rmdir /s /q ".pytest_cache"
if exist ".mypy_cache" rmdir /s /q ".mypy_cache"
if exist ".ruff_cache" rmdir /s /q ".ruff_cache"
del /s /q *.pyc >nul 2>&1
for /d /r . %%d in (__pycache__) do @if exist "%%d" rd /s /q "%%d"

echo Build directories and Python bytecode cleaned.
