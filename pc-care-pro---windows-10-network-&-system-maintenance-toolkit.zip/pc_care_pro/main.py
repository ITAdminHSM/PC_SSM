"""
PC Care Pro - Main Application Entry Point
==========================================
Bootstraps application logging, loads configurations, detects privilege state,
and launches the CustomTkinter desktop graphical interface.
"""

import os
import sys

# Ensure app root is on Python module search path
sys.path.insert(0, os.path.abspath(os.path.dirname(__file__)))

from app.config import AppConfig
from app.constants import APP_NAME, APP_SUBTITLE, APP_VERSION
from app.core.admin_manager import AdminManager
from app.core.logger import AppLogger


def main() -> None:
    """Initializes and runs the PC Care Pro desktop application."""
    # Step 1: Initialize logging
    logger = AppLogger.setup()
    logger.info(f"Starting {APP_NAME} v{APP_VERSION} - {APP_SUBTITLE}")

    # Step 2: Load user preferences
    config = AppConfig()
    is_admin = AdminManager.is_running_as_admin()
    logger.info(f"Process privilege level: {'Administrator (Elevated)' if is_admin else 'Standard User'}")

    # Step 3: Launch CustomTkinter GUI
    try:
        from app.application import PCCareProApp
        app = PCCareProApp(config=config, is_admin=is_admin)
        app.mainloop()
    except ImportError as e:
        logger.error(f"GUI dependencies missing: {e}")
        print(f"[ERROR] Could not start GUI: {e}")
        print("Please ensure dependencies are installed via: pip install -r requirements.txt")
        sys.exit(1)
    except Exception as e:
        logger.critical(f"Unhandled exception during app execution: {e}", exc_info=True)
        sys.exit(1)
    finally:
        logger.info("=== PC Care Pro Application Terminated ===")


if __name__ == "__main__":
    main()
