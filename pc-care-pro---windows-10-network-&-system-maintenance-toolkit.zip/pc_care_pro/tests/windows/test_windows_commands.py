"""
Windows Environment Integration Tests
=====================================
Live integration tests designed to execute against real Windows 10 binaries.
Skipped automatically when executed on non-Windows platforms (e.g. Linux CI).
"""

import platform
import unittest

from app.services.network_service import NetworkService
from app.services.system_service import SystemService


@unittest.skipUnless(platform.system() == "Windows", "Requires native Windows operating system")
class TestWindowsLiveCommands(unittest.TestCase):
    """Executes non-destructive real Windows CLI tools."""

    def setUp(self) -> None:
        self.network_service = NetworkService()
        self.system_service = SystemService()

    def test_live_ipconfig(self) -> None:
        """Runs real ipconfig on Windows."""
        res = self.network_service.run_ipconfig()
        self.assertEqual(res.exit_code, 0)
        self.assertIn("Windows IP Configuration", res.stdout)

    def test_live_hostname(self) -> None:
        """Runs real hostname command on Windows."""
        res = self.network_service.get_hostname()
        self.assertEqual(res.exit_code, 0)
        self.assertGreater(len(res.stdout), 0)


if __name__ == "__main__":
    unittest.main()
