"""
Integration Tests - Report Service & Cross-Module Aggregation
=============================================================
Tests compilation of multi-service telemetry into TXT and JSON support packages.
"""

from pathlib import Path
import tempfile
import unittest

from app.services.cleaner_service import CleanerService
from app.services.network_service import NetworkService
from app.services.repair_service import RepairService
from app.services.report_service import ReportService
from app.services.system_service import SystemService
from app.services.wifi_service import WiFiService
from tests.conftest import MockCommandExecutor


class TestReportIntegration(unittest.TestCase):
    """Test suite for ReportService integration."""

    def setUp(self) -> None:
        self.mock_executor = MockCommandExecutor()
        self.system_service = SystemService(executor=self.mock_executor)
        self.network_service = NetworkService(executor=self.mock_executor)
        self.wifi_service = WiFiService(executor=self.mock_executor)
        self.repair_service = RepairService(executor=self.mock_executor)
        self.cleaner_service = CleanerService()

        self.report_service = ReportService(
            system_service=self.system_service,
            network_service=self.network_service,
            wifi_service=self.wifi_service,
            repair_service=self.repair_service,
            cleaner_service=self.cleaner_service,
        )

    def test_text_report_generation(self) -> None:
        """Text report must assemble cleanly with all expected section headers."""
        text = self.report_service.generate_text_report()
        self.assertIn("PC CARE PRO - SYSTEM & NETWORK DIAGNOSTIC REPORT", text)
        self.assertIn("HARDWARE SPECIFICATIONS & UTILIZATION", text)
        self.assertIn("WIRELESS NETWORKING STATE", text)
        self.assertIn("REPAIR HISTORY", text)

    def test_file_export_txt_and_json(self) -> None:
        """Exports TXT and JSON reports to disk without error."""
        with tempfile.TemporaryDirectory() as tmp_dir:
            txt_path = Path(tmp_dir) / "diag.txt"
            json_path = Path(tmp_dir) / "diag.json"

            self.report_service.export_report_to_file(txt_path, as_json=False)
            self.report_service.export_report_to_file(json_path, as_json=True)

            self.assertTrue(txt_path.exists())
            self.assertTrue(json_path.exists())
            self.assertGreater(txt_path.stat().st_size, 100)
            self.assertGreater(json_path.stat().st_size, 100)


if __name__ == "__main__":
    unittest.main()
