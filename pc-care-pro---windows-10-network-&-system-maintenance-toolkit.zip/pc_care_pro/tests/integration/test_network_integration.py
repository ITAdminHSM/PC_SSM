"""
Integration Tests - Network Diagnostics & Repair Integration
============================================================
Verifies end-to-end communication between NetworkService, RepairService, and CommandExecutor.
"""

import unittest

from app.services.network_service import NetworkService
from app.services.repair_service import RepairService
from tests.conftest import MockCommandExecutor


class TestNetworkIntegration(unittest.TestCase):
    """Test suite for Network & Repair module integration."""

    def setUp(self) -> None:
        self.mock_executor = MockCommandExecutor()
        self.network_service = NetworkService(executor=self.mock_executor)
        self.repair_service = RepairService(executor=self.mock_executor)

    def test_dns_flush_and_history_logging(self) -> None:
        """Executing flush_dns via repair service must log an audit entry."""
        self.mock_executor.set_mock_response(stdout="Successfully flushed the DNS Resolver Cache.", exit_code=0)
        res = self.repair_service.flush_dns()
        self.assertTrue(res.is_success)

        history = self.repair_service.get_history()
        self.assertEqual(len(history), 1)
        self.assertEqual(history[0].operation_name, "Flush DNS Cache")
        self.assertTrue(history[0].is_success)
        self.assertIn("flushed", history[0].details)

    def test_dhcp_release_renew_pipeline(self) -> None:
        """DHCP renewal issues release followed by renew."""
        self.mock_executor.set_mock_response(stdout="DHCP configured", exit_code=0)
        results = self.repair_service.release_and_renew_dhcp()
        self.assertEqual(len(results), 2)
        self.assertEqual(self.mock_executor.executed_commands[-2], ["ipconfig", "/release"])
        self.assertEqual(self.mock_executor.executed_commands[-1], ["ipconfig", "/renew"])


if __name__ == "__main__":
    unittest.main()
