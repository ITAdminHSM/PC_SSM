"""
Unit Tests - Cleaner Service
============================
Tests dry-run calculation, safe file deletion, locked file handling, and path security.
"""

import os
from pathlib import Path
import tempfile
import unittest

from app.core.exceptions import UnsafePathError
from app.services.cleaner_service import CleanerService


class TestCleanerService(unittest.TestCase):
    """Test suite for CleanerService."""

    def setUp(self) -> None:
        self.service = CleanerService()
        # Create a mock temporary directory mimicking %TEMP%
        self.test_dir = tempfile.mkdtemp(prefix="PC_Care_Pro_TEMP_")

    def tearDown(self) -> None:
        import shutil
        if os.path.exists(self.test_dir):
            shutil.rmtree(self.test_dir, ignore_errors=True)

    def test_dry_run_scans_without_deleting(self) -> None:
        """Dry-run must calculate file sizes but leave files intact."""
        # Populate test directory
        f1 = Path(self.test_dir) / "temp1.tmp"
        f2 = Path(self.test_dir) / "temp2.log"
        f1.write_bytes(b"A" * 1024)
        f2.write_bytes(b"B" * 2048)

        summary = self.service.clean_target(self.test_dir, dry_run=True)
        self.assertEqual(summary.scanned_files, 2)
        self.assertEqual(summary.deleted_files, 0)
        self.assertEqual(summary.bytes_freed, 3072)
        self.assertTrue(f1.exists())
        self.assertTrue(f2.exists())

    def test_clean_removes_unlocked_files(self) -> None:
        """Standard cleanup deletes unreferenced files and returns accurate bytes freed."""
        f1 = Path(self.test_dir) / "scratch.tmp"
        f1.write_bytes(b"C" * 4096)

        summary = self.service.clean_target(self.test_dir, dry_run=False)
        self.assertEqual(summary.deleted_files, 1)
        self.assertEqual(summary.bytes_freed, 4096)
        self.assertFalse(f1.exists())

    def test_unsafe_paths_prevented(self) -> None:
        """Cleanup on unapproved user folders must fail with UnsafePathError."""
        with self.assertRaises(UnsafePathError):
            self.service.clean_target("/home/user/Documents", dry_run=True)


if __name__ == "__main__":
    unittest.main()
