"""
Unit Tests - Input & Security Validators
========================================
Verifies regex patterns, boundaries, and protection against command injections.
"""

from pathlib import Path
import unittest

from app.core.exceptions import InvalidInputError, UnsafePathError
from app.core.validators import InputValidators


class TestInputValidators(unittest.TestCase):
    """Test suite for InputValidators."""

    def test_valid_ipv4_addresses(self) -> None:
        """Valid IPv4 addresses must pass normalization."""
        valid_ips = ["127.0.0.1", "192.168.1.1", "8.8.8.8", "10.0.0.254", " 1.1.1.1 "]
        for ip in valid_ips:
            result = InputValidators.validate_ipv4(ip)
            self.assertEqual(result, ip.strip())

    def test_invalid_ipv4_addresses(self) -> None:
        """Malformed or out-of-range IP addresses must raise InvalidInputError."""
        invalid_ips = ["256.1.1.1", "192.168.1", "abc.def.ghi.jkl", "1.2.3.4.5", ""]
        for ip in invalid_ips:
            with self.assertRaises(InvalidInputError):
                InputValidators.validate_ipv4(ip)

    def test_valid_hostnames(self) -> None:
        """Standard domain names must pass validation."""
        valid_hosts = ["google.com", "dns.google", "my-server.local", "sub.domain.co.uk"]
        for host in valid_hosts:
            result = InputValidators.validate_hostname(host)
            self.assertEqual(result, host)

    def test_command_injection_attempts_in_hostname(self) -> None:
        """Hostnames containing shell metacharacters must be rejected immediately."""
        malicious_inputs = [
            "google.com; calc.exe",
            "8.8.8.8 && dir",
            "google.com | netstat",
            "test`id`",
            "$(whoami).com",
            "host > out.txt",
            "host < in.txt",
            "domain&whoami",
        ]
        for bad_input in malicious_inputs:
            with self.assertRaises(InvalidInputError):
                InputValidators.validate_hostname(bad_input)

    def test_validate_ping_count_boundaries(self) -> None:
        """Ping count must strictly fall between 1 and 100."""
        self.assertEqual(InputValidators.validate_ping_count(1), 1)
        self.assertEqual(InputValidators.validate_ping_count(4), 4)
        self.assertEqual(InputValidators.validate_ping_count(100), 100)
        self.assertEqual(InputValidators.validate_ping_count("10"), 10)

        with self.assertRaises(InvalidInputError):
            InputValidators.validate_ping_count(0)
        with self.assertRaises(InvalidInputError):
            InputValidators.validate_ping_count(101)
        with self.assertRaises(InvalidInputError):
            InputValidators.validate_ping_count("invalid")

    def test_validate_ping_timeout_boundaries(self) -> None:
        """Ping timeout must fall between 100ms and 60,000ms."""
        self.assertEqual(InputValidators.validate_ping_timeout_ms(100), 100)
        self.assertEqual(InputValidators.validate_ping_timeout_ms(2000), 2000)
        self.assertEqual(InputValidators.validate_ping_timeout_ms(60000), 60000)

        with self.assertRaises(InvalidInputError):
            InputValidators.validate_ping_timeout_ms(99)
        with self.assertRaises(InvalidInputError):
            InputValidators.validate_ping_timeout_ms(60001)

    def test_validate_cleaner_path_security(self) -> None:
        """Approved temp paths pass, while sensitive directories raise UnsafePathError."""
        # Simulated approved paths
        approved = Path("C:/Users/TestUser/AppData/Local/Temp")
        # In test environments without Windows drives, check path logic
        with self.assertRaises(UnsafePathError):
            InputValidators.validate_cleaner_path("C:/Users/TestUser/Documents")

        with self.assertRaises(UnsafePathError):
            InputValidators.validate_cleaner_path("C:/Windows/System32")


if __name__ == "__main__":
    unittest.main()
