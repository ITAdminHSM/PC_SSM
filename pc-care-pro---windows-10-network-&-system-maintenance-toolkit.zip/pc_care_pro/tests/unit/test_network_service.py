"""
Unit Tests - Network Service
============================
Tests Windows command generation, ping output parsing, packet loss, and latency metrics.
"""

import unittest

from app.core.exceptions import InvalidInputError
from app.services.network_service import NetworkService
from tests.conftest import MockCommandExecutor


class TestNetworkService(unittest.TestCase):
    """Test suite for NetworkService."""

    def setUp(self) -> None:
        self.mock_executor = MockCommandExecutor()
        self.service = NetworkService(executor=self.mock_executor)

    def test_run_ipconfig_arguments(self) -> None:
        """ipconfig commands must append correct arguments."""
        self.service.run_ipconfig()
        self.assertEqual(self.mock_executor.executed_commands[-1], ["ipconfig"])

        self.service.flush_dns()
        self.assertEqual(self.mock_executor.executed_commands[-1], ["ipconfig", "/flushdns"])

        self.service.release_ip()
        self.assertEqual(self.mock_executor.executed_commands[-1], ["ipconfig", "/release"])

        self.service.renew_ip()
        self.assertEqual(self.mock_executor.executed_commands[-1], ["ipconfig", "/renew"])

    def test_invalid_ipconfig_argument_rejected(self) -> None:
        """Invalid flags must be rejected before execution."""
        with self.assertRaises(InvalidInputError):
            self.service.run_ipconfig("/malicious_flag")

    def test_ping_command_construction(self) -> None:
        """Ping commands must format count and timeout accurately."""
        self.service.ping(target="8.8.8.8", count=4, timeout_ms=2000)
        expected = ["ping", "-n", "4", "-w", "2000", "8.8.8.8"]
        self.assertEqual(self.mock_executor.executed_commands[-1], expected)

    def test_ping_output_parsing_success(self) -> None:
        """Parses standard Windows ping response with 0% loss and valid latency."""
        sample_output = """
Pinging 8.8.8.8 with 32 bytes of data:
Reply from 8.8.8.8: bytes=32 time=12ms TTL=117
Reply from 8.8.8.8: bytes=32 time=14ms TTL=117
Reply from 8.8.8.8: bytes=32 time=11ms TTL=117
Reply from 8.8.8.8: bytes=32 time=13ms TTL=117

Ping statistics for 8.8.8.8:
    Packets: Sent = 4, Received = 4, Lost = 0 (0% loss),
Approximate round trip times in milli-seconds:
    Minimum = 11ms, Maximum = 14ms, Average = 12ms
"""
        stats = self.service.parse_ping_output(sample_output, target="8.8.8.8")
        self.assertEqual(stats.packets_sent, 4)
        self.assertEqual(stats.packets_received, 4)
        self.assertEqual(stats.packets_lost, 0)
        self.assertEqual(stats.packet_loss_pct, 0.0)
        self.assertEqual(stats.min_ms, 11.0)
        self.assertEqual(stats.max_ms, 14.0)
        self.assertEqual(stats.avg_ms, 12.0)
        self.assertTrue(stats.is_reachable)

    def test_ping_output_parsing_timeout(self) -> None:
        """Parses complete packet loss (100% loss)."""
        sample_timeout = """
Pinging 192.168.1.250 with 32 bytes of data:
Request timed out.
Request timed out.
Request timed out.
Request timed out.

Ping statistics for 192.168.1.250:
    Packets: Sent = 4, Received = 0, Lost = 4 (100% loss),
"""
        stats = self.service.parse_ping_output(sample_timeout, target="192.168.1.250")
        self.assertEqual(stats.packets_sent, 4)
        self.assertEqual(stats.packets_received, 0)
        self.assertEqual(stats.packets_lost, 4)
        self.assertEqual(stats.packet_loss_pct, 100.0)
        self.assertIsNone(stats.min_ms)
        self.assertIsNone(stats.avg_ms)
        self.assertFalse(stats.is_reachable)

    def test_nslookup_command_construction(self) -> None:
        """nslookup commands must pass valid target."""
        self.service.nslookup("google.com")
        self.assertEqual(self.mock_executor.executed_commands[-1], ["nslookup", "google.com"])


if __name__ == "__main__":
    unittest.main()
