"""
Unit Tests - Wi-Fi Service
==========================
Tests wireless adapter status parsing, SSID extraction, signal strength parsing,
and handling of missing Wi-Fi hardware.
"""

import unittest

from app.services.wifi_service import WiFiService
from tests.conftest import MockCommandExecutor


class TestWiFiService(unittest.TestCase):
    """Test suite for WiFiService."""

    def setUp(self) -> None:
        self.mock_executor = MockCommandExecutor()
        self.service = WiFiService(executor=self.mock_executor)

    def test_parse_interface_output_connected(self) -> None:
        """Parses active Wi-Fi interface details successfully."""
        sample_output = """
There is 1 interface on the system:

    Name                   : Wi-Fi
    Description            : Intel(R) Wi-Fi 6 AX200 160MHz
    GUID                   : 4a2b3c4d-5e6f-7a8b-9c0d-1e2f3a4b5c6d
    Physical address       : 00:11:22:33:44:55
    State                  : connected
    SSID                   : Office_HighSpeed_5G
    BSSID                  : aa:bb:cc:dd:ee:ff
    Network type           : Infrastructure
    Radio type             : 802.11ax
    Authentication         : WPA2-Personal
    Cipher                 : CCMP
    Connection mode        : Profile
    Channel                : 36
    Receive rate (Mbps)    : 866
    Transmit rate (Mbps)   : 866
    Signal                 : 94%
"""
        adapter = self.service.parse_interface_output(sample_output)
        self.assertIsNotNone(adapter)
        assert adapter is not None
        self.assertEqual(adapter.name, "Wi-Fi")
        self.assertEqual(adapter.state, "connected")
        self.assertEqual(adapter.ssid, "Office_HighSpeed_5G")
        self.assertEqual(adapter.signal_pct, 94)
        self.assertEqual(adapter.receive_rate_mbps, 866.0)
        self.assertEqual(adapter.channel, 36)

    def test_parse_interface_missing_hardware(self) -> None:
        """When no Wi-Fi interface exists, parser must return None safely."""
        missing_output = "There is no wireless interface on the system."
        adapter = self.service.parse_interface_output(missing_output)
        self.assertIsNone(adapter)

    def test_parse_available_networks(self) -> None:
        """Parses list of nearby wireless access points."""
        sample_networks = """
Interface name : Wi-Fi
There are 2 networks currently visible.

SSID 1 : Guest_WiFi
    Network type            : Infrastructure
    Authentication          : Open
    Encryption              : None
    BSSID 1                 : 11:22:33:44:55:66
         Signal             : 75%
         Radio type         : 802.11ac

SSID 2 : Corp_Secure_Net
    Network type            : Infrastructure
    Authentication          : WPA2-Enterprise
    Encryption              : CCMP
    BSSID 1                 : aa:bb:cc:11:22:33
         Signal             : 88%
         Radio type         : 802.11ax
"""
        networks = self.service.parse_networks_output(sample_networks)
        self.assertEqual(len(networks), 2)
        self.assertEqual(networks[0].ssid, "Guest_WiFi")
        self.assertEqual(networks[0].signal_pct, 75)
        self.assertEqual(networks[1].ssid, "Corp_Secure_Net")
        self.assertEqual(networks[1].signal_pct, 88)


if __name__ == "__main__":
    unittest.main()
