"""
Unit Tests - Command Executor
=============================
Tests command validation, allowlist enforcement, timeouts, and cancellation.
"""

import sys
import unittest
from unittest.mock import MagicMock, patch

from app.core.command_executor import CancellationToken, CommandExecutor, CommandResult
from app.core.exceptions import InvalidInputError


class TestCommandExecutor(unittest.TestCase):
    """Test suite for CommandExecutor."""

    def setUp(self) -> None:
        self.executor = CommandExecutor(enforce_allowlist=True)

    def test_empty_command_raises_error(self) -> None:
        """Executing an empty command list must raise InvalidInputError."""
        with self.assertRaises(InvalidInputError):
            self.executor._validate_command([])

    def test_non_whitelisted_command_rejected(self) -> None:
        """Arbitrary executables not in ALLOWED_SYSTEM_COMMANDS must be rejected."""
        unapproved_commands = [
            ["curl", "https://example.com"],
            ["powershell", "-Command", "Write-Host 'hello'"],
            ["format", "C:"],
            ["del", "/f", "file.txt"],
        ]
        for cmd in unapproved_commands:
            with self.assertRaises(InvalidInputError):
                self.executor._validate_command(cmd)

    def test_whitelisted_commands_accepted(self) -> None:
        """Approved commands must pass allowlist validation."""
        approved_commands = [
            ["ipconfig", "/all"],
            ["ping", "8.8.8.8"],
            ["tracert", "google.com"],
            ["netstat", "-ano"],
            ["netsh", "wlan", "show", "interfaces"],
            ["sfc", "/verifyonly"],
        ]
        for cmd in approved_commands:
            # Should not raise
            self.executor._validate_command(cmd)

    def test_cancellation_token(self) -> None:
        """CancellationToken should reflect state changes properly."""
        token = CancellationToken()
        self.assertFalse(token.is_cancelled)
        token.cancel()
        self.assertTrue(token.is_cancelled)


if __name__ == "__main__":
    unittest.main()
