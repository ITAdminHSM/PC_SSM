"""
Unit Tests - System Service
===========================
Tests telemetry metrics gathering, partition inspection, and system tool execution.
"""

import unittest

from app.services.system_service import SystemService
from tests.conftest import MockCommandExecutor


class TestSystemService(unittest.TestCase):
    """Test suite for SystemService."""

    def setUp(self) -> None:
        self.mock_executor = MockCommandExecutor()
        self.service = SystemService(executor=self.mock_executor)

    def test_get_telemetry_returns_valid_structure(self) -> None:
        """get_telemetry must provide all required fields."""
        telemetry = self.service.get_telemetry()
        self.assertIsNotNone(telemetry.os_name)
        self.assertIsNotNone(telemetry.cpu_model)
        self.assertGreaterEqual(telemetry.cpu_cores, 1)
        self.assertGreater(telemetry.total_ram_gb, 0.0)
        self.assertGreater(len(telemetry.partitions), 0)

    def test_sfc_scan_arguments(self) -> None:
        """SFC command options must match Windows syntax."""
        self.service.run_sfc_verify()
        self.assertEqual(self.mock_executor.executed_commands[-1], ["sfc", "/verifyonly"])

        self.service.run_sfc_scan()
        self.assertEqual(self.mock_executor.executed_commands[-1], ["sfc", "/scannow"])

    def test_dism_command_arguments(self) -> None:
        """DISM health checks must match component servicing syntax."""
        self.service.run_dism_check_health()
        self.assertEqual(
            self.mock_executor.executed_commands[-1],
            ["dism", "/Online", "/Cleanup-Image", "/CheckHealth"],
        )


if __name__ == "__main__":
    unittest.main()
