"""
PC Care Pro - Pytest & Unittest Test Configuration & Shared Fixtures
"""

import os
from pathlib import Path
import shutil
import tempfile
from typing import Generator, List
import unittest
from unittest.mock import MagicMock

from app.core.command_executor import CommandExecutor, CommandResult


class MockCommandExecutor(CommandExecutor):
    """
    Mock command executor that intercepts CLI commands and returns canned results.
    Guarantees no actual system commands are run during unit tests.
    """

    def __init__(self) -> None:
        super().__init__(enforce_allowlist=True)
        self.executed_commands: List[List[str]] = []
        self.mock_return_code = 0
        self.mock_stdout = ""
        self.mock_stderr = ""

    def set_mock_response(self, stdout: str = "", stderr: str = "", exit_code: int = 0) -> None:
        self.mock_stdout = stdout
        self.mock_stderr = stderr
        self.mock_return_code = exit_code

    def execute_sync(self, cmd_args: List[str], timeout_sec: int = 30, cancellation_token=None) -> CommandResult:
        self._validate_command(cmd_args)
        self.executed_commands.append(cmd_args)
        return CommandResult(
            command=cmd_args,
            exit_code=self.mock_return_code,
            stdout=self.mock_stdout,
            stderr=self.mock_stderr,
            duration_sec=0.05,
            is_success=(self.mock_return_code == 0),
        )
