# -*- mode: python ; coding: utf-8 -*-
import os
import sys

block_cipher = None

# CustomTkinter assets collection
import customtkinter
ctk_dir = os.path.dirname(customtkinter.__file__)

added_files = [
    (ctk_dir, 'customtkinter/'),
    ('app/resources', 'app/resources'),
]

a = Analysis(
    ['main.py'],
    pathex=['.'],
    binaries=[],
    datas=added_files,
    hiddenimports=[
        'customtkinter',
        'psutil',
        'ctypes',
        'subprocess',
        'threading',
        'queue',
        'ipaddress',
        'platform',
        'socket',
        're',
        'shutil',
    ],
    hookspath=[],
    hooksconfig={},
    runtime_hooks=[],
    excludes=['tkinter.test', 'unittest', 'pytest'],
    win_no_prefer_redirects=False,
    win_private_assemblies=False,
    cipher=block_cipher,
    noarchive=False,
)

pyz = PYZ(a.pure, a.zipped_data, cipher=block_cipher)

exe = EXE(
    pyz,
    a.scripts,
    a.binaries,
    a.zipfiles,
    a.datas,
    [],
    name='PC_Care_Pro',
    debug=False,
    bootloader_ignore_signals=False,
    strip=False,
    upx=True,
    upx_exclude=[],
    runtime_tmpdir=None,
    console=False,  # Set to True for debug console builds
    disable_windowed_traceback=False,
    argv_emulation=False,
    target_arch=None,
    codesign_identity=None,
    entitlements_file=None,
    icon=None,
)
