# PC Care Pro - Architecture & System Design Document
**Windows 10 Network Diagnostics, Internet Troubleshooting & PC Maintenance Suite**

Version: 1.0.0-dev  
Target Operating System: Windows 10 (64-bit)  
Runtime: Python 3.10+ with CustomTkinter & Win32 API Bridges  

---

## 1. Executive Architectural Overview

PC Care Pro is structured using a strict **Layered Modular Architecture** with clear **Separation of Concerns (SoC)**, **Dependency Inversion (DI)**, and **Defensive Windows Execution Safeguards**. 

The application is engineered to meet 4 non-negotiable architectural constraints:
1. **Never Freeze the UI**: All external Windows binaries (`ipconfig`, `ping`, `netsh`, `dism`, `sfc`, etc.) and file system scans execute in background worker threads with thread-safe UI message queues.
2. **Defensive Command Allowlists**: No arbitrary shell execution is permitted. Subprocesses use `shell=False` with explicit argument vectors (`List[str]`), strict regex validation on user inputs (hostnames, IPs, interface names), and mandatory execution timeouts.
3. **Privilege Boundary Enforcement**: Operations requiring Windows Administrator elevation (e.g. Winsock reset, TCP/IP stack re-initialization, adapter toggle, firewall restoration) are clearly marked, preemptively checked, and gracefully escalated via Windows UAC without silent elevation or fatal crashes.
4. **Safety-Guaranteed Filesystem Operations**: Temporary file cleanup operates strictly within an approved directory whitelist (`%TEMP%`, `C:\Windows\Temp`), skipping locked/in-use files, never traversing symbolic links outside safe roots, and strictly forbidding touching User Documents, Desktop, Downloads, browser profiles, or system state.

---

## 2. Layered Architecture Diagram

```
+----------------------------------------------------------------------------+
|                          PRESENTATION LAYER (GUI)                          |
|  CustomTkinter Dark Navy Theme (#0A1128 / #1C2541 / #48CAE4 Accent)       |
|                                                                            |
|  +--------------------+  +----------------------------------------------+  |
|  |   Left Sidebar     |  |          View Controller / Pages             |  |
|  | - Dashboard        |  |  * DashboardView      * CleanerView          |  |
|  | - Diagnostics      |  |  * DiagnosticsView    * WindowsToolsView     |  |
|  | - Wi-Fi Manager    |  |  * WiFiManagerView    * SystemInfoView       |  |
|  | - Network Repair   |  |  * RepairCenterView   * ConsoleView          |  |
|  | - PC Cleaner       |  |  * ReportsView        * SettingsView         |  |
|  +--------------------+  +----------------------------------------------+  |
|                                |                                           |
|                  UI State & Thread-Safe Queue Handlers                     |
+--------------------------------+-------------------------------------------+
                                 | Calls Service Methods / Dispatches Jobs
                                 v
+----------------------------------------------------------------------------+
|                            SERVICE LAYER                                   |
|  Business Logic, Result Parsing, Sanitization, State Tracking              |
|                                                                            |
|  * NetworkService   : Ping parser, DNS lookup, IPConfig aggregator         |
|  * WiFiService      : netsh wlan parser, adapter state, signal metric      |
|  * RepairService    : Winsock, TCP/IP, DNS flush, Adapter reset sequences  |
|  * CleanerService   : Safe scan, dry-run preview, atomic file remover      |
|  * SystemService    : psutil/WMI/registry reader, uptime, memory, disk     |
|  * ReportService    : Diagnostic aggregation, TXT/JSON report generator    |
+--------------------------------+-------------------------------------------+
                                 | Uses Core Utilities & Execution Engine
                                 v
+----------------------------------------------------------------------------+
|                              CORE LAYER                                    |
|  Low-Level Execution, Safety Guards, Privilege & Logging                   |
|                                                                            |
|  * CommandExecutor  : Threaded subprocess wrapper (stdout/stderr separation|
|                       timeouts, cancellation tokens, allowlist enforcement)|
|  * AdminManager     : ctypes Shell32 IsUserAnAdmin detection & runas bridge|
|  * InputValidators  : IPv4, IPv6, FQDN hostname, and interface sanitizers   |
|  * AppLogger        : Rotating file logger (RFC 5424 timestamping, no PII) |
|  * Exceptions       : Custom typed exceptions for predictable recovery     |
+--------------------------------+-------------------------------------------+
                                 | Invokes Windows Subsystems
                                 v
+----------------------------------------------------------------------------+
|                        WINDOWS 10 SUBSYSTEMS                               |
|                                                                            |
|  * Windows CLI       : ipconfig.exe, ping.exe, tracert.exe, nslookup.exe    |
|  * Windows NetSH     : netsh.exe (interface, wlan, advfirewall, winsock)   |
|  * Windows Servicing : dism.exe, sfc.exe, chkdsk.exe                        |
|  * Win32 / Kernel32  : ctypes Win32 APIs, GetDiskFreeSpaceEx, ShellExecute |
|  * Windows Registry  : HKLM/HKCU CurrentVersion, NetworkCards              |
+----------------------------------------------------------------------------+
```

---

## 3. Data Flow & Execution Sequence

### A. Non-Elevated Diagnostic Command (e.g., Ping / IPConfig)
1. **User Action**: User enters target (`google.com`), packet count (`4`), and clicks "Execute Ping".
2. **Input Validation**: `InputValidators.validate_hostname_or_ip("google.com")` ensures no shell metacharacters (`&`, `|`, `;`, `>`, `<`, `` ` ``) are present.
3. **Dispatch**: `NetworkService.ping(target, count, timeout)` constructs the exact argv list: `["ping", "-n", "4", "-w", "2000", "google.com"]`.
4. **Execution**: `CommandExecutor.execute_async(cmd, on_chunk, on_complete)` spawns a worker thread.
5. **Streaming**: As stdout chunks arrive, they are dispatched through thread-safe callbacks to `ConsoleView` and `DiagnosticsView`.
6. **Result Parsing**: When the process exits, `NetworkService.parse_ping_output(raw_stdout)` calculates:
   - Packet Loss percentage (e.g. `0%`)
   - Latency metrics: Minimum, Maximum, Average (e.g. `12ms`, `15ms`, `13ms`)
7. **Log**: The operation is recorded in `reports/pc_care_pro.log` without personal identifiers.

### B. Elevated Network Repair Operation (e.g., Reset Winsock)
1. **User Action**: User clicks "Reset Winsock Catalog" in Network Repair Centre.
2. **Confirmation Modal**: Explains action, states system restart may be required, and asks for explicit confirmation.
3. **Admin Check**: `AdminManager.is_running_as_admin()` checks privilege:
   - If **Elevated**: Proceeds directly to step 4.
   - If **Standard User**: Informs user with dialog: *"This operation requires Windows Administrator privileges. Would you like to elevate PC Care Pro?"*. Invokes `AdminManager.request_elevation()`.
4. **Safe Invocation**: `RepairService.reset_winsock()` invokes `netsh winsock reset` via `CommandExecutor`.
5. **Audit Record**: Operation, timestamp, exit code, and stdout/stderr are saved to the internal Repair History and exported diagnostic logs.

### C. Safe PC Cleanup (Two-Phase Verification)
1. **Phase 1 (Scan / Dry-Run)**:
   - `CleanerService.scan_targets()` scans only verified temporary paths:
     - User `%TEMP%` (`os.environ.get('TEMP')`)
     - System `%SystemRoot%\Temp`
     - Windows Prefetch (if elevated & enabled)
   - Resolves all canonical paths (`os.path.realpath`). If any path points outside approved directories, it is discarded immediately.
   - Calculates candidate file count, total byte size, and detects file locks without touching file contents.
2. **Phase 2 (User Preview & Approval)**:
   - UI displays exact counts and recovered disk space estimate (e.g., "1,420 files, 3.42 GB removable").
   - Explicit confirmation required before deletion occurs.
3. **Phase 3 (Atomic Removal)**:
   - Deletion loop handles `PermissionError` (in-use files) by recording them in `skipped_files` rather than terminating.
   - Outputs comprehensive audit: `{"cleaned_bytes": 3548231000, "deleted_files": 1380, "skipped_files": 40}`.

---

## 4. Module Directory Structure & Responsibilities

```
pc_care_pro/
├── main.py                     # Entry point: bootstrapping, single-instance check, logging setup
├── requirements.txt            # Production runtime dependencies (customtkinter, psutil)
├── requirements-dev.txt        # Development & QA dependencies (pytest, ruff, mypy, pyinstaller)
├── pytest.ini                  # Pytest configuration and custom markers
├── pyproject.toml              # Build tool configuration & metadata
├── README.md                   # Comprehensive user and developer guide
├── ARCHITECTURE.md             # This document
├── CONTRIBUTING.md             # Contribution, TDD guidelines, style guides
├── CHANGELOG.md                # Release notes and history
├── LICENSE                     # MIT License
├── build.bat                   # Standalone EXE automated build script
├── clean_build.bat             # Clean build artifacts (dist/, build/, .pytest_cache)
│
├── app/
│   ├── __init__.py             # Package marker
│   ├── config.py               # App configuration, theme settings, paths, timeouts
│   ├── constants.py            # Command definitions, allowlists, color palettes
│   ├── application.py          # Application root controller (CustomTkinter CTk)
│   │
│   ├── core/                   # Platform abstractions and security guarantees
│   │   ├── __init__.py
│   │   ├── command_executor.py # Async/sync subprocess runner, timeouts, token cancellation
│   │   ├── admin_manager.py    # Windows UAC / ctypes Shell32 bridge
│   │   ├── logger.py           # Thread-safe rotating logger with formatters
│   │   ├── validators.py       # Regex validators for IPs, hostnames, interface names
│   │   └── exceptions.py       # Typed domain exceptions (ValidationError, ExecutionTimeout)
│   │
│   ├── services/               # Pure business logic and Windows parsing engines
│   │   ├── __init__.py
│   │   ├── network_service.py  # IP configuration, ping/traceroute/nslookup orchestration
│   │   ├── wifi_service.py     # netsh wlan interface/networks/profiles parser
│   │   ├── repair_service.py   # Winsock, TCP/IP, DNS flush, Adapter reset sequences
│   │   ├── cleaner_service.py  # Path-whitelist-protected file scanner and remover
│   │   ├── system_service.py   # CPU, RAM, Disk partitions, Windows version, uptime
│   │   └── report_service.py   # Formatted text and JSON diagnostic reports generator
│   │
│   ├── ui/                     # Presentation components using CustomTkinter
│   │   ├── __init__.py
│   │   ├── main_window.py      # Main application window with navigation coordinator
│   │   ├── sidebar.py          # Collapsible left navigation bar with 11 routes
│   │   ├── dashboard.py        # System health widgets, live telemetry, quick actions
│   │   ├── diagnostics.py      # IPConfig, Ping, Traceroute, DNS lookup workbenches
│   │   ├── wifi_manager.py     # Wireless adapter state, SSID scanner, signal meter
│   │   ├── repair_center.py    # Repair workflows with confirmation dialogs
│   │   ├── cleaner.py          # Safe temp file scanner, dry-run table, space reclaim
│   │   ├── windows_tools.py    # Launchers for SFC, DISM, Chkdsk, TaskMgr, DeviceMgr
│   │   ├── system_info.py      # Detailed hardware, OS build, memory, NIC table
│   │   ├── console.py          # Real-time stdout/stderr console with copy/export
│   │   ├── reports.py          # Log viewer, system report exporter
│   │   └── settings.py         # Ping timeout configuration, theme, logging level
│   │
│   └── resources/
│       └── icons/              # Embedded vector/PNG icons for buttons and tabs
│
├── tests/                      # Automated test suite (TDD Red-Green-Refactor)
│   ├── __init__.py
│   ├── conftest.py             # Shared fixtures, mock subprocess runners, test directories
│   ├── unit/                   # Unit tests (Mock-based, safe on any OS)
│   │   ├── test_validators.py
│   │   ├── test_command_executor.py
│   │   ├── test_network_service.py
│   │   ├── test_wifi_service.py
│   │   ├── test_cleaner_service.py
│   │   └── test_system_service.py
│   ├── integration/            # Cross-module communication tests
│   │   ├── test_network_integration.py
│   │   ├── test_wifi_integration.py
│   │   ├── test_cleaner_integration.py
│   │   └── test_report_integration.py
│   └── windows/                # Real Windows integration tests (conditional execution)
│       └── test_windows_commands.py
│
└── reports/                    # User export directory for diagnostic reports
    └── .gitkeep
```

---

## 5. Security Architecture & Threat Model

| Potential Risk | Architectural Mitigation |
|---|---|
| **Command Injection via target input** | User input is strictly validated against an alphanumeric/hyphen/period regex for hostnames and standard IPv4/IPv6 regexes. Subprocesses use `shell=False` and pass arguments as lists, eliminating shell command chaining. |
| **Accidental System Destruction in Cleaner** | All scan and delete routines check paths against a hardcoded whitelist (`%TEMP%`, `C:\Windows\Temp`). User directories (`C:\Users\<Name>\Documents`, `Downloads`, `Desktop`) are strictly excluded. Any symbolic link pointing outside the approved root is rejected. |
| **Denial of Service from Hung Commands** | Every command executed through `CommandExecutor` enforces a configurable timeout (default: 15s for ping, 60s for trace, 300s for DISM). Timed-out processes are forcefully terminated. |
| **Wi-Fi Credential Leakage** | The Wi-Fi manager runs `netsh wlan show networks` and `netsh wlan show profiles` but strictly forbids invoking `key=clear` or extracting plaintext WPA2/WPA3 keys. |
| **Silent Privilege Escalation** | Elevation requests invoke the standard Windows UAC prompt (`runas` verb via `ctypes.windll.shell32.ShellExecuteW`) with explicit user notice explaining the reason. |

---

## 6. Error Handling Taxonomy

All service methods return structured, predictable result objects (`CommandResult`, `ScanResult`, `RepairResult`) rather than raw primitive strings:

- `CommandResult(command: str, exit_code: int, stdout: str, stderr: str, duration_sec: float, is_success: bool)`
- `PingResult(target: str, packets_sent: int, packets_received: int, packet_loss_pct: float, min_ms: float, max_ms: float, avg_ms: float, raw_output: str)`
- `WiFiNetwork(ssid: str, signal_pct: int, auth: str, cipher: str, bssid: str)`
- `CleanSummary(scanned_files: int, deleted_files: int, skipped_files: int, bytes_freed: int, errors: List[str])`

This ensures UI presentation code never has to parse unstructured text or handle unexpected subprocess crashes.
