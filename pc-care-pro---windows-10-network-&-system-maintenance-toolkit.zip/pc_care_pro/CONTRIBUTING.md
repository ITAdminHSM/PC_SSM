# Contributing to PC Care Pro

Thank you for helping improve **PC Care Pro**! This document provides technical guidelines for maintaining, extending, and upgrading the software.

---

## 1. Development Principles

All contributions to PC Care Pro must adhere to the following core tenets:

1. **Test-Driven Development (TDD)**:
   - **RED**: Write a failing test in `tests/unit/` or `tests/integration/` describing the desired behavior before writing the production code.
   - **GREEN**: Write the minimal amount of clean code in `app/` to make the test pass.
   - **REFACTOR**: Polish the implementation for readability, safety, and performance while ensuring all tests remain green.

2. **Security & Defensive Programming**:
   - Never use `shell=True` in subprocess calls.
   - Always sanitize hostnames, IP addresses, and adapter names with `InputValidators`.
   - Never extract, print, or log plaintext Wi-Fi passwords.
   - Never delete files outside the verified temporary directory whitelist.

3. **Code Readability for Non-Advanced Developers**:
   - Add clear docstrings to all classes and functions detailing purpose, parameters, return types, and exceptions.
   - Add inline comments explaining the *rationale* behind non-obvious operations.
   - Use standard Python type hints (`str`, `int`, `Optional[T]`, `List[T]`, `Dict[str, Any]`).

---

## 2. Setting Up the Development Environment

```cmd
git clone https://github.com/your-username/pc_care_pro.git
cd pc_care_pro
python -m venv venv
venv\Scripts\activate
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

---

## 3. Running Quality Checks

Before submitting any code changes, ensure all checks pass:

```cmd
# 1. Run unit tests
pytest tests/unit -v

# 2. Run integration tests (safe mocked mode)
pytest tests/integration -v

# 3. Check types with mypy
mypy app tests

# 4. Lint code with ruff
ruff check app tests
```

---

## 4. Test Categories & Pytest Markers

Tests are classified using custom pytest markers defined in `pytest.ini`:

- `@pytest.mark.unit`: Fast, isolated tests mocking all OS/subprocess interactions. Safe to execute anywhere (including Linux and macOS CI runners).
- `@pytest.mark.integration`: Component integration tests verifying cross-module coordination.
- `@pytest.mark.windows_only`: Tests that interact with live Windows 10 native binaries. Skipped automatically on non-Windows platforms.
- `@pytest.mark.admin_only`: Tests that require elevated administrator rights. Skipped unless explicitly enabled.
