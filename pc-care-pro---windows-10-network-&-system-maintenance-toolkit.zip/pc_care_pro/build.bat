@echo off
setlocal enabledelayedexpansion

echo =====================================================================
echo  PC CARE PRO - Standalone Windows Executable Builder
echo =====================================================================
echo.

:: Step 1: Verify Python installation
where python >nul 2>nul
if %errorlevel% neq 0 (
    echo [ERROR] Python 3 was not found in your system PATH.
    echo Please install Python 3.10+ from python.org and check "Add Python to PATH".
    pause
    exit /b 1
)

for /f "tokens=*" %%i in ('python --version 2^>^&1') do set PYTHON_VER=%%i
echo [*] Detected: %PYTHON_VER%

:: Step 2: Ensure virtual environment exists or is activated
if not exist "venv\Scripts\activate.bat" (
    echo [*] Creating virtual environment in venv...
    python -m venv venv
    if %errorlevel% neq 0 (
        echo [ERROR] Failed to create virtual environment.
        pause
        exit /b 1
    )
)

call venv\Scripts\activate.bat

:: Step 3: Check and install required dependencies
echo [*] Checking dependencies...
python -m pip install --upgrade pip >nul 2>&1
python -m pip install -r requirements.txt -r requirements-dev.txt
if %errorlevel% neq 0 (
    echo [ERROR] Failed to install required packages.
    pause
    exit /b 1
)

:: Step 4: Run test suite before building
echo.
echo [*] Executing test suite prior to build...
python -m pytest tests/unit -v
if %errorlevel% neq 0 (
    echo.
    echo [FATAL] Test suite failed! Aborting build to prevent defective EXE.
    pause
    exit /b 1
)
echo [OK] All tests passed successfully!

:: Step 5: Clean prior build artifacts
echo.
echo [*] Cleaning previous build folders...
if exist "build" rmdir /s /q "build"
if exist "dist" rmdir /s /q "dist"

:: Step 6: Compile with PyInstaller
echo [*] Compiling standalone executable with PyInstaller...
pyinstaller --clean PC_Care_Pro.spec
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] PyInstaller compilation failed.
    pause
    exit /b 1
)

:: Step 7: Verify output
echo.
if exist "dist\PC_Care_Pro.exe" (
    echo =====================================================================
    echo [SUCCESS] Build completed successfully!
    echo Final Executable Location:
    echo %CD%\dist\PC_Care_Pro.exe
    echo =====================================================================
) else (
    echo [ERROR] Output file dist\PC_Care_Pro.exe was not found.
    pause
    exit /b 1
)

pause
