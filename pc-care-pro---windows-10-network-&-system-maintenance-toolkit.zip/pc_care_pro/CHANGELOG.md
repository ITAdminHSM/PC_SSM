# Changelog - PC Care Pro

All notable changes to this project will be documented in this file.
The format is based on [Keep a Changelog](https://keepachangelog.com/en/1.0.0/),
and this project adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

---

## [1.0.0] - 2026-11-01

### Added
- **Core Execution Engine**:
  - `CommandExecutor` supporting synchronous and asynchronous background execution with thread-safe UI callbacks.
  - Strict subprocess timeouts and cancellation tokens.
  - `AdminManager` with native Windows `Shell32.IsUserAnAdmin` checks and UAC elevation triggers.
  - Comprehensive input sanitizers (`InputValidators`) for IPv4, IPv6, FQDN hostnames, and interface names.
  - Thread-safe rotating file logger with customizable retention limits and RFC 5424 timestamps.

- **Network Diagnostics Module**:
  - `ipconfig` runner (`/all`, `/displaydns`, `/flushdns`, `/release`, `/renew`).
  - High-precision ping engine with custom packet count, timeout, and response statistics parsing (min/max/avg latency, packet loss percentage).
  - Trace route (`tracert`) and path diagnostic (`pathping`).
  - DNS lookup utility (`nslookup`).
  - Network state inspectors (`netstat -ano`, `arp -a`, `route print`, `getmac`).

- **Wi-Fi Manager Module**:
  - Wireless adapter detection and state reader.
  - Active SSID and signal strength (%) display.
  - Available wireless network scanner (`netsh wlan show networks`).
  - Saved profile manager with safe profile reconnection.
  - Defensive security: Wi-Fi credentials and passwords are never extracted or exposed.

- **Network Repair Centre**:
  - Step-by-step repair actions with user confirmation dialogues and admin requirement notices.
  - Winsock catalog reset (`netsh winsock reset`).
  - TCP/IP stack reset (`netsh int ip reset`).
  - Adapter disable/enable/restart sequences.
  - Windows Firewall configuration reset (`netsh advfirewall reset`).
  - Persistent repair history table with timestamp and execution status.

- **PC Cleaner Module**:
  - Safe two-phase scanner for User `%TEMP%` and Windows `%SystemRoot%\Temp`.
  - Preview/Dry-run capability calculating candidate file counts and estimated disk space recovery.
  - Safe error recovery: skips in-use/locked files without halting cleanup.
  - Hardcoded safety whitelist: strictly prevents scanning or deletion of Documents, Downloads, Desktop, or personal files.

- **Windows Repair & System Tools**:
  - System file integrity checks (`sfc /verifyonly`, `sfc /scannow`).
  - Component store servicing (`DISM CheckHealth`, `ScanHealth`, `RestoreHealth`).
  - Point-and-click shortcuts for Task Manager, Device Manager, Services, Event Viewer, Disk Management, and Network Connections.

- **Presentation & UI**:
  - Dark Navy & Teal IT utility theme built with CustomTkinter.
  - 11-section responsive sidebar layout.
  - Live system telemetries: CPU load, RAM usage, disk usage, active IPv4, and system uptime.
  - Real-time command output console with stdout/stderr segregation, search, clipboard copy, and text export.

- **Testing & Packaging**:
  - Automated unit test suite with 100% mocked offline execution.
  - Automated PyInstaller packaging spec (`PC_Care_Pro.spec`) and one-click `build.bat` script.
