# PC Care Pro
> **Windows 10 Network Diagnostics, Internet Troubleshooting and PC Maintenance Suite**

[![Platform](https://img.shields.io/badge/Platform-Windows%2010%20(64--bit)-0078D6.svg)](https://microsoft.com/windows)
[![Python](https://img.shields.io/badge/Python-3.10%2B-3776AB.svg)](https://python.org)
[![UI](https://img.shields.io/badge/UI-CustomTkinter-1f538d.svg)](https://github.com/TomSchimansky/CustomTkinter)
[![Testing](https://img.shields.io/badge/Tests-pytest%20%7C%20unittest-green.svg)](https://pytest.org)
[![License](https://img.shields.io/badge/License-MIT-teal.svg)](LICENSE)

---

## 1. Project Overview

**PC Care Pro** is a modern, standalone Windows 10 maintenance utility engineered for non-technical users and IT support technicians alike. It unifies essential Windows networking, internet diagnostics, Wi-Fi management, safe temporary file cleaning, system repairs, and hardware telemetries into a clean, responsive graphical desktop interface.

### Key Capabilities

1. **Dashboard**: Instant live status of Internet connectivity, Wi-Fi link, local IPv4, Default Gateway, DNS servers, real-time CPU/RAM/Disk loads, and system uptime.
2. **Internet Diagnostics**: One-click execution of `ipconfig (/all, /flushdns, /renew)`, high-precision ping tests with configurable packets & timeouts, traceroute, pathping, DNS lookups (`nslookup`), `netstat`, ARP, and routing tables.
3. **Wi-Fi Manager**: Wireless adapter detection, active SSID display, signal strength metering, driver details, scanning for available 2.4/5GHz networks, and reconnecting to saved profiles (passwords are **never** extracted or exposed).
4. **Network Repair Centre**: Safe, step-by-step restoration tools for Winsock catalog, TCP/IP stack re-initialization, DNS cache flushing, adapter resets, and Windows Firewall restoration.
5. **PC Cleaner**: Safe temporary file scanner for `%TEMP%` and `C:\Windows\Temp`. Features a mandatory two-step dry-run / preview workflow before any file deletion occurs. Never touches Documents, Downloads, Desktop, or personal files.
6. **Windows Repair Tools**: Point-and-click interface to Windows system servicing tools (`sfc /scannow`, `DISM Health check/restore`, CHKDSK status) and instant launchers for administrative applets (Task Manager, Device Manager, Services, Event Viewer).
7. **System Information**: Comprehensive breakdown of OS edition/build, CPU model & core topology, RAM utilization, partition free space, and MAC/IP bindings with one-click export to TXT.
8. **Command Console**: Live terminal displaying raw `stdout` and `stderr` streams, timestamps, operation status badges, with instant clipboard copy and export.
9. **Logs & Reports**: User-accessible rotating log file manager and diagnostic report aggregator.
10. **Zero External APIs**: Operates 100% offline with zero telemetry, zero analytics, zero data collection, and zero third-party cloud dependencies.

---

## 2. Directory Structure

```text
pc_care_pro/
├── main.py                     # Application entry point
├── requirements.txt            # Production dependencies (customtkinter, psutil)
├── requirements-dev.txt        # Development dependencies (pytest, mypy, ruff, pyinstaller)
├── pytest.ini                  # Pytest configuration with test markers
├── pyproject.toml              # Project configuration and linter settings
├── README.md                   # This documentation
├── ARCHITECTURE.md             # Detailed system design and security specifications
├── CONTRIBUTING.md             # Developer guidelines and TDD instructions
├── CHANGELOG.md                # Release notes and version history
├── LICENSE                     # MIT Open Source License
├── build.bat                   # Automated Windows EXE compilation script
├── clean_build.bat             # Artifact cleanup script
├── PC_Care_Pro.spec            # PyInstaller specification for single-file packaging
│
├── app/
│   ├── config.py               # Application configurations, timeouts, color themes
│   ├── constants.py            # Command allowlists, default targets, UI palettes
│   ├── application.py          # CustomTkinter main application orchestrator
│   │
│   ├── core/                   # Safety and execution framework
│   │   ├── command_executor.py # Threaded subprocess runner (stdout/stderr stream)
│   │   ├── admin_manager.py    # Windows UAC elevation detection and runas bridge
│   │   ├── logger.py           # Rotating file logger with RFC 5424 timestamps
│   │   ├── validators.py       # Input sanitizers for IP addresses and hostnames
│   │   └── exceptions.py       # Custom typed domain exceptions
│   │
│   ├── services/               # Pure business logic and Windows parsers
│   │   ├── network_service.py  # Network testing, ping calculation, ipconfig parser
│   │   ├── wifi_service.py     # netsh wlan interface, scan, and profile parser
│   │   ├── repair_service.py   # Winsock, TCP/IP, and firewall repair actions
│   │   ├── cleaner_service.py  # Whitelist-restricted temporary file scanner & cleaner
│   │   ├── system_service.py   # Hardware and OS metrics provider
│   │   └── report_service.py   # Diagnostic report exporter (TXT and JSON)
│   │
│   └── ui/                     # UI Views (CustomTkinter)
│       ├── main_window.py      # Main window layout with responsive frame switching
│       ├── sidebar.py          # Left navigation menu (11 sections)
│       ├── dashboard.py        # Telemetry cards and quick action buttons
│       ├── diagnostics.py      # IPConfig, Ping, and network tool interfaces
│       ├── wifi_manager.py     # Wireless adapter state and network scanner
│       ├── repair_center.py    # Repair workflows with confirmation dialogs
│       ├── cleaner.py          # Safe disk cleaner preview and execution
│       ├── windows_tools.py    # SFC, DISM, and Windows applet launchers
│       ├── system_info.py      # Detailed hardware breakdown & report generator
│       ├── console.py          # Real-time stdout/stderr console
│       ├── reports.py          # Log viewer and diagnostics exporter
│       └── settings.py         # Application preferences
│
├── tests/
│   ├── conftest.py             # Shared fixtures and mock execution harnesses
│   ├── unit/                   # Unit tests (runnable on any OS)
│   │   ├── test_validators.py
│   │   ├── test_command_executor.py
│   │   ├── test_network_service.py
│   │   ├── test_wifi_service.py
│   │   ├── test_cleaner_service.py
│   │   └── test_system_service.py
│   └── integration/            # Cross-service integration tests
│       ├── test_network_integration.py
│       ├── test_wifi_integration.py
│       ├── test_cleaner_integration.py
│       └── test_report_integration.py
│
└── reports/                    # Generated system and diagnostic logs
```

---

## 3. Installation & Running from Source

### Prerequisites
- Windows 10 (64-bit) or compatible environment
- Python 3.10 or newer (ensure *"Add Python to PATH"* is checked during installation)

### Step 1: Clone or Extract the Project
```cmd
cd pc_care_pro
```

### Step 2: Create a Virtual Environment
```cmd
python -m venv venv
venv\Scripts\activate
```

### Step 3: Install Dependencies
```cmd
pip install -r requirements.txt
pip install -r requirements-dev.txt
```

### Step 4: Run the Application
```cmd
python main.py
```

---

## 4. Running the Automated Test Suite

PC Care Pro is developed using strict **Test-Driven Development (TDD)** principles. All business logic, input validation, output parsing, and safety guards have automated tests.

Run all unit tests with pytest:
```cmd
pytest tests/unit -v
```

Or run using Python's built-in unittest runner without any external packages:
```cmd
python -m unittest discover -s tests -p "test_*.py" -v
```

---

## 5. Building the Standalone Windows Executable (.EXE)

A convenient one-click build script is provided:

```cmd
build.bat
```

This batch script automatically:
1. Verifies Python 3 installation and PATH configuration.
2. Checks and installs required dependencies.
3. Executes the full test suite and halts if any test fails.
4. Cleans previous compilation artifacts.
5. Invokes PyInstaller with `PC_Care_Pro.spec`.
6. Produces the single-file executable: `dist\PC_Care_Pro.exe`.

---

## 6. Guide for Beginners & Future Modifications

### How to Add a New Network Command
1. Open `app/constants.py` and register your new command in the command dictionary.
2. Open `app/services/network_service.py` and implement a service method with input validation.
3. Add a unit test in `tests/unit/test_network_service.py` verifying command construction and parser behavior.
4. Add the button to `app/ui/diagnostics.py` connecting to your new service method.

### How to Modify the Safe Cleaner Rules
The cleaner is designed to be bulletproof. Safety whitelists are enforced in `app/services/cleaner_service.py`. Only explicitly approved temporary paths can ever be targeted.

---

## 7. License
Distributed under the MIT License. See `LICENSE` for more information.
