"""
PC Care Pro - Application Package
=================================
Windows 10 Network Diagnostics, Internet Troubleshooting and PC Maintenance Suite.
"""

__version__ = "1.0.0"
__author__ = "PC Care Pro Development Team"
