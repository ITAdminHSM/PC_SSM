"""
PC Care Pro - App Configuration
===============================
Manages runtime configuration, persistent settings (stored in %APPDATA%/PCCarePro),
and default preferences for ping timeouts, logging levels, and UI theme.
"""

import json
import os
from pathlib import Path
from typing import Any, Dict


class AppConfig:
    """
    Handles loading, storing, and accessing user configuration.
    
    Configuration is persisted in JSON format in the user's AppData directory
    (e.g., %APPDATA%\\PCCarePro\\settings.json) or current working directory.
    """

    def __init__(self, config_dir: Path | None = None) -> None:
        if config_dir is None:
            # On Windows, use %APPDATA%\PCCarePro. On other OS, use ~/.pc_care_pro
            appdata = os.environ.get("APPDATA")
            if appdata:
                self.config_dir = Path(appdata) / "PCCarePro"
            else:
                self.config_dir = Path.home() / ".pc_care_pro"
        else:
            self.config_dir = config_dir

        self.config_file = self.config_dir / "settings.json"
        self._data: Dict[str, Any] = self._default_settings()
        self._ensure_dir_exists()
        self.load()

    def _default_settings(self) -> Dict[str, Any]:
        """Returns the default configuration values."""
        return {
            "theme": "dark",
            "accent_color": "cyan",
            "default_ping_target": "8.8.8.8",
            "default_ping_count": 4,
            "default_ping_timeout_ms": 2000,
            "enable_verbose_logs": False,
            "confirm_elevated_actions": True,
            "auto_scroll_console": True,
        }

    def _ensure_dir_exists(self) -> None:
        """Creates configuration directory if it does not exist."""
        try:
            self.config_dir.mkdir(parents=True, exist_ok=True)
        except OSError:
            # Fallback to local execution directory if AppData is inaccessible
            self.config_dir = Path("./config")
            self.config_file = self.config_dir / "settings.json"
            self.config_dir.mkdir(parents=True, exist_ok=True)

    def load(self) -> None:
        """Loads settings from JSON file on disk, merging with defaults."""
        if self.config_file.exists():
            try:
                with open(self.config_file, "r", encoding="utf-8") as f:
                    saved = json.load(f)
                    if isinstance(saved, dict):
                        self._data.update(saved)
            except (json.JSONDecodeError, OSError):
                # If file is corrupted, preserve defaults and avoid crashing
                pass

    def save(self) -> None:
        """Saves current settings to disk atomically."""
        try:
            self._ensure_dir_exists()
            with open(self.config_file, "w", encoding="utf-8") as f:
                json.dump(self._data, f, indent=4)
        except OSError:
            pass

    def get(self, key: str, default: Any = None) -> Any:
        """Retrieves a configuration value."""
        return self._data.get(key, default)

    def set(self, key: str, value: Any) -> None:
        """Sets a configuration value and persists changes."""
        self._data[key] = value
        self.save()
