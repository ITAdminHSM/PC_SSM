"""
PC Care Pro - Wi-Fi Management Service
======================================
Manages Windows wireless interfaces using netsh wlan.
Extracts active SSID, signal strength, available networks, and saved profiles.
Defensive rule: Plaintext Wi-Fi passwords are NEVER extracted, logged, or displayed.
"""

from dataclasses import dataclass
import re
from typing import Dict, List, Optional

from app.core.command_executor import CommandExecutor, CommandResult
from app.core.exceptions import CommandExecutionError, InvalidInputError
from app.core.validators import InputValidators


@dataclass
class WiFiNetworkEntry:
    """An available wireless network discovered via netsh wlan show networks."""
    ssid: str
    network_type: str
    authentication: str
    encryption: str
    signal_pct: int
    bssid: Optional[str] = None


@dataclass
class WiFiAdapterState:
    """Status and driver details of the primary wireless adapter."""
    name: str
    description: str
    state: str
    ssid: Optional[str]
    bssid: Optional[str]
    radio_type: Optional[str]
    authentication: Optional[str]
    cipher: Optional[str]
    signal_pct: Optional[int]
    receive_rate_mbps: Optional[float]
    transmit_rate_mbps: Optional[float]
    channel: Optional[int]


class WiFiService:
    """
    Service layer for querying and managing Windows Wi-Fi hardware.
    """

    def __init__(self, executor: Optional[CommandExecutor] = None) -> None:
        self.executor = executor or CommandExecutor(enforce_allowlist=True)

    def is_wifi_available(self) -> bool:
        """Checks if a wireless interface is present on the machine."""
        res = self.executor.execute_sync(["netsh", "wlan", "show", "interfaces"])
        if "There is no wireless interface on the system" in res.stdout:
            return False
        return "Name" in res.stdout

    def get_interface_details(self) -> Optional[WiFiAdapterState]:
        """
        Parses output of 'netsh wlan show interfaces'.
        Returns None if no Wi-Fi interface is found.
        """
        res = self.executor.execute_sync(["netsh", "wlan", "show", "interfaces"])
        if not res.is_success or "There is no wireless interface" in res.stdout:
            return None

        return self.parse_interface_output(res.stdout)

    @staticmethod
    def parse_interface_output(raw_output: str) -> Optional[WiFiAdapterState]:
        """Parses the text output of 'netsh wlan show interfaces'."""
        lines = [line.strip() for line in raw_output.splitlines() if ":" in line]
        kv: Dict[str, str] = {}
        for line in lines:
            parts = line.split(":", 1)
            if len(parts) == 2:
                kv[parts[0].strip()] = parts[1].strip()

        if "Name" not in kv and "Description" not in kv:
            return None

        # Extract signal %
        signal_pct = None
        if "Signal" in kv:
            sig_match = re.search(r"(\d+)%", kv["Signal"])
            if sig_match:
                signal_pct = int(sig_match.group(1))

        # Extract rates
        rx_rate = None
        tx_rate = None
        if "Receive rate (Mbps)" in kv:
            try:
                rx_rate = float(kv["Receive rate (Mbps)"])
            except ValueError:
                pass
        if "Transmit rate (Mbps)" in kv:
            try:
                tx_rate = float(kv["Transmit rate (Mbps)"])
            except ValueError:
                pass

        channel = None
        if "Channel" in kv:
            try:
                channel = int(kv["Channel"])
            except ValueError:
                pass

        return WiFiAdapterState(
            name=kv.get("Name", "Wi-Fi"),
            description=kv.get("Description", "Wireless Adapter"),
            state=kv.get("State", "disconnected"),
            ssid=kv.get("SSID", None),
            bssid=kv.get("BSSID", None),
            radio_type=kv.get("Radio type", None),
            authentication=kv.get("Authentication", None),
            cipher=kv.get("Cipher", None),
            signal_pct=signal_pct,
            receive_rate_mbps=rx_rate,
            transmit_rate_mbps=tx_rate,
            channel=channel,
        )

    def scan_available_networks(self) -> List[WiFiNetworkEntry]:
        """
        Scans for visible Wi-Fi access points via 'netsh wlan show networks mode=bssid'.
        """
        res = self.executor.execute_sync(["netsh", "wlan", "show", "networks", "mode=bssid"])
        if not res.is_success or "There is no wireless interface" in res.stdout:
            return []

        return self.parse_networks_output(res.stdout)

    @staticmethod
    def parse_networks_output(raw_output: str) -> List[WiFiNetworkEntry]:
        """Parses output from 'netsh wlan show networks mode=bssid'."""
        networks: List[WiFiNetworkEntry] = []
        blocks = re.split(r"\n\s*\nSSID \d+ : ", "\n" + raw_output)

        for block in blocks:
            if not block.strip() or "SSID" not in block:
                continue

            lines = [l.strip() for l in block.splitlines()]
            ssid = lines[0].replace("SSID :", "").strip() if lines else ""
            if not ssid and "SSID" in lines[0]:
                ssid = lines[0].split(":", 1)[-1].strip()

            if not ssid:
                continue

            network_type = "Infrastructure"
            auth = "WPA2-Personal"
            enc = "CCMP"
            signal = 50
            bssid = None

            for line in lines[1:]:
                if "Network type" in line:
                    network_type = line.split(":", 1)[-1].strip()
                elif "Authentication" in line:
                    auth = line.split(":", 1)[-1].strip()
                elif "Encryption" in line:
                    enc = line.split(":", 1)[-1].strip()
                elif "Signal" in line:
                    sig_m = re.search(r"(\d+)%", line)
                    if sig_m:
                        signal = int(sig_m.group(1))
                elif "BSSID 1" in line:
                    bssid = line.split(":", 1)[-1].strip()

            networks.append(
                WiFiNetworkEntry(
                    ssid=ssid,
                    network_type=network_type,
                    authentication=auth,
                    encryption=enc,
                    signal_pct=signal,
                    bssid=bssid,
                )
            )

        return networks

    def get_saved_profiles(self) -> List[str]:
        """
        Lists names of saved Wi-Fi connection profiles.
        Defensive: NEVER uses 'key=clear' to avoid retrieving plaintext passwords.
        """
        res = self.executor.execute_sync(["netsh", "wlan", "show", "profiles"])
        if not res.is_success:
            return []

        profiles: List[str] = []
        for line in res.stdout.splitlines():
            if "All User Profile" in line or "User Profile" in line:
                parts = line.split(":", 1)
                if len(parts) == 2:
                    profile_name = parts[1].strip()
                    if profile_name:
                        profiles.append(profile_name)

        return profiles

    def reconnect_profile(self, profile_name: str, interface_name: str = "Wi-Fi") -> CommandResult:
        """
        Reconnects to an existing, already saved Wi-Fi profile.
        """
        valid_interface = InputValidators.validate_interface_name(interface_name)
        cmd = ["netsh", "wlan", "connect", f"name={profile_name}", f"interface={valid_interface}"]
        return self.executor.execute_sync(cmd)

    def enable_adapter(self, interface_name: str = "Wi-Fi") -> CommandResult:
        """Enables the specified wireless adapter. Requires elevation."""
        valid_interface = InputValidators.validate_interface_name(interface_name)
        cmd = ["netsh", "interface", "set", "interface", valid_interface, "enable"]
        return self.executor.execute_sync(cmd)

    def disable_adapter(self, interface_name: str = "Wi-Fi") -> CommandResult:
        """Disables the specified wireless adapter. Requires elevation."""
        valid_interface = InputValidators.validate_interface_name(interface_name)
        cmd = ["netsh", "interface", "set", "interface", valid_interface, "disable"]
        return self.executor.execute_sync(cmd)

    def restart_adapter(self, interface_name: str = "Wi-Fi") -> List[CommandResult]:
        """Disables and re-enables adapter with a brief delay."""
        res1 = self.disable_adapter(interface_name)
        import time
        time.sleep(1.0)
        res2 = self.enable_adapter(interface_name)
        return [res1, res2]
