"""
PC Care Pro - Network Diagnostics Service
=========================================
Implements Windows networking diagnostic commands (ipconfig, ping, tracert, nslookup,
netstat, arp, route) and provides parsed telemetry for latency, packet loss, and IP state.
"""

from dataclasses import dataclass
import re
from typing import Dict, List, Optional, Tuple

from app.core.command_executor import CommandExecutor, CommandResult
from app.core.exceptions import InvalidInputError
from app.core.validators import InputValidators


@dataclass
class PingStatistics:
    """Detailed parsing metrics from a Windows ping command output."""
    target: str
    packets_sent: int
    packets_received: int
    packets_lost: int
    packet_loss_pct: float
    min_ms: Optional[float]
    max_ms: Optional[float]
    avg_ms: Optional[float]
    raw_output: str

    @property
    def is_reachable(self) -> bool:
        """True if at least one response packet was received."""
        return self.packets_received > 0


@dataclass
class NetworkAdapterInfo:
    """Summary of an active network interface."""
    name: str
    status: str
    ipv4_address: str
    subnet_mask: str
    default_gateway: str
    dns_servers: List[str]


class NetworkService:
    """
    Coordinates execution and parsing of network diagnostic commands.
    """

    def __init__(self, executor: Optional[CommandExecutor] = None) -> None:
        self.executor = executor or CommandExecutor(enforce_allowlist=True)

    # -------------------------------------------------------------------------
    # IP Configuration Commands
    # -------------------------------------------------------------------------

    def run_ipconfig(self, argument: Optional[str] = None) -> CommandResult:
        """
        Executes ipconfig with an optional argument.
        
        Args:
            argument: None, '/all', '/displaydns', '/flushdns', '/release', '/renew'
        """
        cmd = ["ipconfig"]
        if argument:
            allowed_args = {"/all", "/displaydns", "/flushdns", "/release", "/renew"}
            if argument.lower() not in allowed_args:
                raise InvalidInputError(f"Invalid ipconfig argument: {argument}", field_name="ipconfig")
            cmd.append(argument)
        return self.executor.execute_sync(cmd)

    def flush_dns(self) -> CommandResult:
        """Clears and flushes the Windows DNS client resolver cache."""
        return self.run_ipconfig("/flushdns")

    def release_ip(self) -> CommandResult:
        """Releases the current DHCP-assigned IPv4 address."""
        return self.run_ipconfig("/release")

    def renew_ip(self) -> CommandResult:
        """Renews DHCP lease with the active router/DHCP server."""
        return self.run_ipconfig("/renew")

    # -------------------------------------------------------------------------
    # Ping & Connectivity Testing
    # -------------------------------------------------------------------------

    def ping(
        self,
        target: str = "8.8.8.8",
        count: int = 4,
        timeout_ms: int = 2000,
    ) -> Tuple[CommandResult, PingStatistics]:
        """
        Executes a Windows ping command and parses packet loss and latency.
        
        Args:
            target: Valid IP or Hostname.
            count: Number of echo request packets (1 - 100).
            timeout_ms: Timeout in milliseconds per packet.
            
        Returns:
            Tuple of (raw CommandResult, parsed PingStatistics).
        """
        valid_target, _ = InputValidators.validate_hostname_or_ip(target)
        valid_count = InputValidators.validate_ping_count(count)
        valid_timeout = InputValidators.validate_ping_timeout_ms(timeout_ms)

        cmd = [
            "ping",
            "-n", str(valid_count),
            "-w", str(valid_timeout),
            valid_target,
        ]

        total_timeout_sec = int((valid_count * valid_timeout / 1000) + 5)
        result = self.executor.execute_sync(cmd, timeout_sec=total_timeout_sec)
        parsed_stats = self.parse_ping_output(result.stdout, target=valid_target, sent_count=valid_count)

        return result, parsed_stats

    @staticmethod
    def parse_ping_output(raw_output: str, target: str = "Unknown", sent_count: int = 4) -> PingStatistics:
        """
        Parses the raw text output of the Windows ping command.
        Extracts sent/received/lost packets and min/max/avg latency.
        """
        # Packets: Sent = 4, Received = 4, Lost = 0 (0% loss)
        loss_match = re.search(
            r"Packets:\s+Sent\s*=\s*(\d+),\s*Received\s*=\s*(\d+),\s*Lost\s*=\s*(\d+)\s*\(([\d\.]+)%\s*loss\)",
            raw_output,
            re.IGNORECASE,
        )

        # Minimum = 12ms, Maximum = 15ms, Average = 13ms
        time_match = re.search(
            r"Minimum\s*=\s*(\d+)ms,\s*Maximum\s*=\s*(\d+)ms,\s*Average\s*=\s*(\d+)ms",
            raw_output,
            re.IGNORECASE,
        )

        if loss_match:
            sent = int(loss_match.group(1))
            received = int(loss_match.group(2))
            lost = int(loss_match.group(3))
            loss_pct = float(loss_match.group(4))
        else:
            # Fallback calculation if Windows localized output differs
            sent = sent_count
            received = len(re.findall(r"Reply from", raw_output, re.IGNORECASE))
            lost = max(0, sent - received)
            loss_pct = (lost / sent * 100.0) if sent > 0 else 100.0

        min_ms = float(time_match.group(1)) if time_match else None
        max_ms = float(time_match.group(2)) if time_match else None
        avg_ms = float(time_match.group(3)) if time_match else None

        return PingStatistics(
            target=target,
            packets_sent=sent,
            packets_received=received,
            packets_lost=lost,
            packet_loss_pct=loss_pct,
            min_ms=min_ms,
            max_ms=max_ms,
            avg_ms=avg_ms,
            raw_output=raw_output,
        )

    # -------------------------------------------------------------------------
    # Traceroute & DNS Lookups
    # -------------------------------------------------------------------------

    def traceroute(self, target: str = "8.8.8.8", max_hops: int = 30) -> CommandResult:
        """Executes tracert to identify intermediate routing hops."""
        valid_target, _ = InputValidators.validate_hostname_or_ip(target)
        cmd = ["tracert", "-d", "-h", str(max_hops), valid_target]
        return self.executor.execute_sync(cmd, timeout_sec=60)

    def pathping(self, target: str = "8.8.8.8") -> CommandResult:
        """Executes pathping for packet loss analysis over hops."""
        valid_target, _ = InputValidators.validate_hostname_or_ip(target)
        cmd = ["pathping", "-n", "-q", "2", valid_target]
        return self.executor.execute_sync(cmd, timeout_sec=90)

    def nslookup(self, domain_or_ip: str = "google.com") -> CommandResult:
        """Queries DNS server for domain record mapping."""
        valid_target, _ = InputValidators.validate_hostname_or_ip(domain_or_ip)
        cmd = ["nslookup", valid_target]
        return self.executor.execute_sync(cmd)

    # -------------------------------------------------------------------------
    # Network Information Commands
    # -------------------------------------------------------------------------

    def get_netstat(self) -> CommandResult:
        """Lists active TCP/UDP ports and connections."""
        return self.executor.execute_sync(["netstat", "-ano"])

    def get_arp_table(self) -> CommandResult:
        """Reads local ARP cache mappings."""
        return self.executor.execute_sync(["arp", "-a"])

    def get_routing_table(self) -> CommandResult:
        """Displays Windows kernel IP routing table."""
        return self.executor.execute_sync(["route", "print"])

    def get_hostname(self) -> CommandResult:
        """Returns the local computer hostname."""
        return self.executor.execute_sync(["hostname"])

    def get_mac_addresses(self) -> CommandResult:
        """Retrieves physical MAC addresses of installed network adapters."""
        return self.executor.execute_sync(["getmac"])

    def get_interfaces_status(self) -> CommandResult:
        """Queries Windows network interface states via netsh."""
        return self.executor.execute_sync(["netsh", "interface", "show", "interface"])

    def get_ip_config_details(self) -> CommandResult:
        """Queries IP configuration bindings for all adapters via netsh."""
        return self.executor.execute_sync(["netsh", "interface", "ip", "show", "config"])

    def test_internet_connectivity(self) -> Dict[str, any]:
        """
        Runs a rapid multi-point connectivity verification against primary and backup DNS.
        """
        result_primary, stats_primary = self.ping(target="8.8.8.8", count=2, timeout_ms=1500)
        result_secondary, stats_secondary = self.ping(target="1.1.1.1", count=2, timeout_ms=1500)

        is_connected = stats_primary.is_reachable or stats_secondary.is_reachable
        best_latency = min(
            [s for s in (stats_primary.avg_ms, stats_secondary.avg_ms) if s is not None],
            default=None,
        )

        return {
            "is_connected": is_connected,
            "latency_ms": best_latency,
            "primary_dns_reachable": stats_primary.is_reachable,
            "secondary_dns_reachable": stats_secondary.is_reachable,
            "details": f"8.8.8.8: {stats_primary.packet_loss_pct}% loss, 1.1.1.1: {stats_secondary.packet_loss_pct}% loss",
        }
