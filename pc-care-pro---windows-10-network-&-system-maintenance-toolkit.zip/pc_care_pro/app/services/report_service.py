"""
PC Care Pro - Diagnostic Report Generation Service
==================================================
Compiles full hardware snapshots, network configurations, repair histories,
and system status logs into cleanly formatted TXT and JSON reports for IT support.
"""

from datetime import datetime
import json
import os
from pathlib import Path
from typing import Any, Dict, Optional

from app.services.cleaner_service import CleanerService
from app.services.network_service import NetworkService
from app.services.repair_service import RepairService
from app.services.system_service import SystemService
from app.services.wifi_service import WiFiService


class ReportService:
    """
    Coordinates aggregation and file export of diagnostic data.
    """

    def __init__(
        self,
        system_service: Optional[SystemService] = None,
        network_service: Optional[NetworkService] = None,
        wifi_service: Optional[WiFiService] = None,
        repair_service: Optional[RepairService] = None,
        cleaner_service: Optional[CleanerService] = None,
    ) -> None:
        self.system_service = system_service or SystemService()
        self.network_service = network_service or NetworkService()
        self.wifi_service = wifi_service or WiFiService()
        self.repair_service = repair_service or RepairService()
        self.cleaner_service = cleaner_service or CleanerService()

    def generate_full_report_dict(self) -> Dict[str, Any]:
        """Collects structured diagnostic telemetry across all services."""
        now = datetime.now()
        telemetry = self.system_service.get_telemetry()
        wifi_state = self.wifi_service.get_interface_details()
        history = self.repair_service.get_history()

        partitions_data = [
            {
                "device": p.device,
                "mountpoint": p.mountpoint,
                "total_gb": p.total_gb,
                "used_gb": p.used_gb,
                "free_gb": p.free_gb,
                "percent_used": p.percent_used,
            }
            for p in telemetry.partitions
        ]

        repair_data = [
            {
                "operation": h.operation_name,
                "timestamp": h.timestamp,
                "success": h.is_success,
                "summary": h.summary,
            }
            for h in history
        ]

        return {
            "application": "PC Care Pro",
            "version": "1.0.0",
            "generated_at": now.strftime("%Y-%m-%d %H:%M:%S"),
            "system": {
                "os": telemetry.os_name,
                "version": telemetry.os_version,
                "build": telemetry.os_build,
                "computer_name": telemetry.computer_name,
                "cpu_model": telemetry.cpu_model,
                "cpu_cores": telemetry.cpu_cores,
                "cpu_utilization_pct": telemetry.cpu_percent,
                "total_ram_gb": telemetry.total_ram_gb,
                "used_ram_gb": telemetry.used_ram_gb,
                "ram_utilization_pct": telemetry.ram_percent,
                "uptime": telemetry.uptime_str,
                "partitions": partitions_data,
            },
            "wifi": {
                "adapter": wifi_state.name if wifi_state else "None",
                "state": wifi_state.state if wifi_state else "Not present",
                "ssid": wifi_state.ssid if wifi_state else None,
                "signal_pct": wifi_state.signal_pct if wifi_state else None,
            },
            "repairs_executed": repair_data,
        }

    def generate_text_report(self) -> str:
        """Renders an ASCII text report suitable for printing or email support."""
        data = self.generate_full_report_dict()
        sys_data = data["system"]
        wifi_data = data["wifi"]

        lines = [
            "=" * 70,
            f"          PC CARE PRO - SYSTEM & NETWORK DIAGNOSTIC REPORT",
            "=" * 70,
            f"Generated At    : {data['generated_at']}",
            f"Application     : {data['application']} v{data['version']}",
            f"Computer Name   : {sys_data['computer_name']}",
            f"Operating System: {sys_data['os']} (Build {sys_data['build']})",
            f"System Uptime   : {sys_data['uptime']}",
            "-" * 70,
            "HARDWARE SPECIFICATIONS & UTILIZATION",
            "-" * 70,
            f"Processor (CPU) : {sys_data['cpu_model']} ({sys_data['cpu_cores']} cores)",
            f"CPU Current Load: {sys_data['cpu_utilization_pct']}%",
            f"Installed Memory: {sys_data['total_ram_gb']} GB (In Use: {sys_data['used_ram_gb']} GB / {sys_data['ram_utilization_pct']}%)",
            "",
            "DISK PARTITIONS:",
        ]

        for p in sys_data["partitions"]:
            lines.append(f"  Drive {p['device']} ({p['mountpoint']}) - Total: {p['total_gb']} GB | Free: {p['free_gb']} GB ({p['percent_used']}% used)")

        lines.extend([
            "-" * 70,
            "WIRELESS NETWORKING STATE",
            "-" * 70,
            f"Adapter Status  : {wifi_data['adapter']} ({wifi_data['state']})",
            f"Active SSID     : {wifi_data['ssid'] or 'Not Connected'}",
            f"Signal Strength : {str(wifi_data['signal_pct']) + '%' if wifi_data['signal_pct'] is not None else 'N/A'}",
            "-" * 70,
            "REPAIR HISTORY (CURRENT SESSION)",
            "-" * 70,
        ])

        if not data["repairs_executed"]:
            lines.append("  No maintenance repair operations recorded in this session.")
        else:
            for r in data["repairs_executed"]:
                status_tag = "[SUCCESS]" if r["success"] else "[FAILED]"
                lines.append(f"  {r['timestamp']} {status_tag} {r['operation']} - {r['summary']}")

        lines.extend([
            "=" * 70,
            "                 END OF DIAGNOSTIC REPORT",
            "=" * 70,
        ])

        return "\n".join(lines)

    def export_report_to_file(self, destination_path: Path | str, as_json: bool = False) -> Path:
        """Writes report to file."""
        target = Path(destination_path)
        target.parent.mkdir(parents=True, exist_ok=True)

        if as_json:
            data = self.generate_full_report_dict()
            with open(target, "w", encoding="utf-8") as f:
                json.dump(data, f, indent=4)
        else:
            content = self.generate_text_report()
            with open(target, "w", encoding="utf-8") as f:
                f.write(content)

        return target
