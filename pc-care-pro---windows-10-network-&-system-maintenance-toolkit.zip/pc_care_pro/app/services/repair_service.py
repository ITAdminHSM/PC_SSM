"""
PC Care Pro - Network Repair Service
====================================
Coordinates Windows network stack repair operations:
- Winsock Catalog Reset
- TCP/IP Stack Reinitialization
- DNS Cache Flush
- DHCP Release & Renew
- Network Adapter Cycling
- Windows Firewall Reset

Enforces safety checks, administrative verification, and records persistent repair audit histories.
"""

from dataclasses import dataclass
from datetime import datetime
import os
import subprocess
from typing import List, Optional

from app.core.admin_manager import AdminManager
from app.core.command_executor import CommandExecutor, CommandResult
from app.core.exceptions import PermissionDeniedError
from app.core.validators import InputValidators


@dataclass
class RepairHistoryEntry:
    """Record of an executed repair operation."""
    operation_name: str
    timestamp: str
    is_success: bool
    requires_reboot: bool
    summary: str
    details: str


class RepairService:
    """
    Manages safe execution of individual network repair procedures.
    """

    def __init__(self, executor: Optional[CommandExecutor] = None) -> None:
        self.executor = executor or CommandExecutor(enforce_allowlist=True)
        self.history: List[RepairHistoryEntry] = []

    def _record_history(
        self,
        op_name: str,
        result: CommandResult,
        requires_reboot: bool = False,
        summary: str = "",
    ) -> RepairHistoryEntry:
        entry = RepairHistoryEntry(
            operation_name=op_name,
            timestamp=datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
            is_success=result.is_success,
            requires_reboot=requires_reboot,
            summary=summary or ("Success" if result.is_success else "Failed"),
            details=result.full_output,
        )
        self.history.append(entry)
        return entry

    # -------------------------------------------------------------------------
    # Safe Repairs (Non-Elevated / Low Impact)
    # -------------------------------------------------------------------------

    def flush_dns(self) -> CommandResult:
        """Flushes and recreates the DNS client resolver cache."""
        res = self.executor.execute_sync(["ipconfig", "/flushdns"])
        self._record_history(
            op_name="Flush DNS Cache",
            result=res,
            requires_reboot=False,
            summary="Successfully cleared local DNS resolver cache" if res.is_success else "DNS flush encountered an error",
        )
        return res

    def release_and_renew_dhcp(self) -> List[CommandResult]:
        """Releases and re-requests an IPv4 DHCP configuration."""
        res_rel = self.executor.execute_sync(["ipconfig", "/release"])
        res_ren = self.executor.execute_sync(["ipconfig", "/renew"])
        combined_success = res_rel.is_success and res_ren.is_success

        self._record_history(
            op_name="Release & Renew DHCP IP",
            result=res_ren,
            requires_reboot=False,
            summary="DHCP IP lease refreshed" if combined_success else "Failed to renew DHCP lease",
        )
        return [res_rel, res_ren]

    # -------------------------------------------------------------------------
    # Elevated Repairs (Requires Administrator)
    # -------------------------------------------------------------------------

    def reset_winsock(self) -> CommandResult:
        """
        Resets the Windows Sockets API catalog back to defaults.
        Requires Administrator privileges.
        Requires system restart to take complete effect.
        """
        if not AdminManager.is_running_as_admin():
            raise PermissionDeniedError("Winsock Catalog Reset")

        res = self.executor.execute_sync(["netsh", "winsock", "reset"])
        self._record_history(
            op_name="Reset Winsock Catalog",
            result=res,
            requires_reboot=True,
            summary="Winsock catalog reset successfully. System restart recommended." if res.is_success else "Winsock reset failed",
        )
        return res

    def reset_tcpip(self) -> CommandResult:
        """
        Resets TCP/IP stack parameters and rewrites corrupted IP registry keys.
        Requires Administrator privileges.
        Requires system restart.
        """
        if not AdminManager.is_running_as_admin():
            raise PermissionDeniedError("TCP/IP Stack Reset")

        # Writes reset log to temp directory
        temp_dir = os.environ.get("TEMP", "C:\\Windows\\Temp")
        log_file = os.path.join(temp_dir, "tcpip_reset.log")
        res = self.executor.execute_sync(["netsh", "int", "ip", "reset", log_file])
        self._record_history(
            op_name="Reset TCP/IP Stack",
            result=res,
            requires_reboot=True,
            summary="TCP/IP stack reset. System restart required." if res.is_success else "TCP/IP reset failed",
        )
        return res

    def reset_firewall(self) -> CommandResult:
        """
        Restores Windows Defender Firewall to default settings.
        Warning: Removes custom user firewall rules!
        Requires Administrator privileges.
        """
        if not AdminManager.is_running_as_admin():
            raise PermissionDeniedError("Reset Windows Firewall")

        res = self.executor.execute_sync(["netsh", "advfirewall", "reset"])
        self._record_history(
            op_name="Reset Windows Firewall",
            result=res,
            requires_reboot=False,
            summary="Windows Firewall restored to default rules" if res.is_success else "Firewall reset failed",
        )
        return res

    def restart_adapter(self, adapter_name: str) -> List[CommandResult]:
        """
        Restarts a specific network adapter by disabling then re-enabling it.
        Requires Administrator privileges.
        """
        valid_name = InputValidators.validate_interface_name(adapter_name)
        if not AdminManager.is_running_as_admin():
            raise PermissionDeniedError("Network Adapter Restart")

        res_disable = self.executor.execute_sync(["netsh", "interface", "set", "interface", valid_name, "disable"])
        import time
        time.sleep(1.5)
        res_enable = self.executor.execute_sync(["netsh", "interface", "set", "interface", valid_name, "enable"])

        combined = res_disable.is_success and res_enable.is_success
        self._record_history(
            op_name=f"Restart Adapter '{valid_name}'",
            result=res_enable,
            requires_reboot=False,
            summary=f"Adapter '{valid_name}' restarted successfully" if combined else "Adapter restart failed",
        )
        return [res_disable, res_enable]

    def launch_network_troubleshooter(self) -> bool:
        """
        Opens Windows native Network Diagnostics troubleshooter interface.
        """
        try:
            # Launch Windows Network Diagnostics wizard
            subprocess.Popen(["msdt.exe", "/id", "NetworkDiagnosticsNetworkAdapter"])
            return True
        except Exception:
            try:
                # Modern Windows 10/11 URI launcher fallback
                os.system("start ms-settings:network-troubleshoot")
                return True
            except Exception:
                return False

    def get_history(self) -> List[RepairHistoryEntry]:
        """Returns the chronological audit log of all repairs executed in this session."""
        return list(self.history)
