"""
PC Care Pro - Main Application Coordinator
==========================================
Subclasses customtkinter.CTk to establish window geometry, themes,
navigation coordination, and service instances.
"""

from typing import Optional

try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    # Graceful dummy fallback if GUI libraries are not yet installed in headless CI
    import tkinter as ctk  # type: ignore

from app.config import AppConfig
from app.constants import (
    APP_NAME,
    APP_SUBTITLE,
    COLOR_BG_DARK,
    COLOR_PANEL_DARK,
)
from app.core.logger import AppLogger
from app.services.cleaner_service import CleanerService
from app.services.network_service import NetworkService
from app.services.repair_service import RepairService
from app.services.report_service import ReportService
from app.services.system_service import SystemService
from app.services.wifi_service import WiFiService


class PCCareProApp(ctk.CTk if hasattr(ctk, "CTk") else ctk.Tk):
    """
    Main application root window and state manager.
    """

    def __init__(self, config: Optional[AppConfig] = None, is_admin: bool = False) -> None:
        super().__init__()
        self.config = config or AppConfig()
        self.is_admin = is_admin
        self.logger = AppLogger.get_logger()

        # Initialize shared services
        self.system_service = SystemService()
        self.network_service = NetworkService()
        self.wifi_service = WiFiService()
        self.repair_service = RepairService()
        self.cleaner_service = CleanerService()
        self.report_service = ReportService(
            system_service=self.system_service,
            network_service=self.network_service,
            wifi_service=self.wifi_service,
            repair_service=self.repair_service,
            cleaner_service=self.cleaner_service,
        )

        # Configure window geometry and title
        self.title(f"{APP_NAME} - {APP_SUBTITLE}")
        self.geometry("1200x780")
        self.minsize(1050, 680)

        if hasattr(ctk, "set_appearance_mode"):
            ctk.set_appearance_mode("dark")
            ctk.set_default_color_theme("blue")

        self._init_layout()

    def _init_layout(self) -> None:
        """Sets up the left sidebar and main content frame container."""
        # Main grid: 0 = sidebar (fixed width), 1 = main content (expanding)
        self.grid_rowconfigure(0, weight=1)
        self.grid_columnconfigure(1, weight=1)

        # Build Sidebar
        from app.ui.sidebar import SidebarView
        self.sidebar = SidebarView(self, on_navigate=self.navigate_to)
        self.sidebar.grid(row=0, column=0, sticky="nsew")

        # Container for pages
        if hasattr(ctk, "CTkFrame"):
            self.content_container = ctk.CTkFrame(self, fg_color=COLOR_BG_DARK, corner_radius=0)
        else:
            self.content_container = ctk.Frame(self, bg=COLOR_BG_DARK)
        self.content_container.grid(row=0, column=1, sticky="nsew")
        self.content_container.grid_rowconfigure(0, weight=1)
        self.content_container.grid_columnconfigure(0, weight=1)

        # Track active page
        self.current_page = None
        self.navigate_to("dashboard")

    def navigate_to(self, page_id: str) -> None:
        """Switches the active view in the content container."""
        self.logger.debug(f"Navigating to page: {page_id}")
        if self.current_page is not None:
            self.current_page.destroy()

        from app.ui import create_view_by_id
        self.current_page = create_view_by_id(page_id, self.content_container, self)
        self.current_page.grid(row=0, column=0, sticky="nsew")
        self.sidebar.set_active_item(page_id)
