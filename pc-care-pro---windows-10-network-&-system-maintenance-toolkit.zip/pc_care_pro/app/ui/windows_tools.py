"""
PC Care Pro - Windows Repair Tools View
=======================================
Shortcuts and runners for Windows system servicing tools:
SFC, DISM Component Store Servicing, CHKDSK Analysis, and Win32 MMC Consoles.
"""

import threading
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class WindowsToolsView(ctk.CTkScrollableFrame if hasattr(ctk, "CTkScrollableFrame") else ctk.Frame):
    """Windows repair tools and system servicing panel."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Windows Repair & Administrative Servicing Tools",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Run System File Checker (SFC), DISM Component Store health checks, and launch administrative applets",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # ---------------------------------------------------------------------
        # Section 1: System File Repair & Servicing (SFC / DISM)
        # ---------------------------------------------------------------------
        servicing_box = ctk.CTkFrame(self, fg_color=COLOR_CARD_DARK, corner_radius=10)
        servicing_box.pack(fill="x", padx=25, pady=(0, 15))

        ctk.CTkLabel(
            servicing_box,
            text="System Integrity & Servicing Operations (Requires Administrator)",
            font=("Segoe UI", 14, "bold"),
        ).pack(anchor="w", padx=20, pady=(15, 10))

        grid_sfc = ctk.CTkFrame(servicing_box, fg_color="transparent")
        grid_sfc.pack(fill="x", padx=20, pady=(0, 15))
        grid_sfc.grid_columnconfigure((0, 1, 2), weight=1)

        ctk.CTkButton(
            grid_sfc,
            text="SFC Verify Only\n(sfc /verifyonly)",
            command=lambda: self._run_tool(self.app.system_service.run_sfc_verify),
        ).grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            grid_sfc,
            text="SFC Repair\n(sfc /scannow)",
            fg_color="#D97706",
            hover_color="#B45309",
            command=lambda: self._run_tool(self.app.system_service.run_sfc_scan),
        ).grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            grid_sfc,
            text="CHKDSK (Read-Only)\n(chkdsk C:)",
            command=lambda: self._run_tool(self.app.system_service.check_disk_status),
        ).grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            grid_sfc,
            text="DISM Check Health\n(/CheckHealth)",
            command=lambda: self._run_tool(self.app.system_service.run_dism_check_health),
        ).grid(row=1, column=0, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            grid_sfc,
            text="DISM Scan Health\n(/ScanHealth)",
            command=lambda: self._run_tool(self.app.system_service.run_dism_scan_health),
        ).grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            grid_sfc,
            text="DISM Restore Health\n(/RestoreHealth)",
            fg_color="#D97706",
            hover_color="#B45309",
            command=lambda: self._run_tool(self.app.system_service.run_dism_restore_health),
        ).grid(row=1, column=2, padx=5, pady=5, sticky="ew")

        # ---------------------------------------------------------------------
        # Section 2: Windows Administrative Shortcuts
        # ---------------------------------------------------------------------
        applets_box = ctk.CTkFrame(self, fg_color=COLOR_CARD_DARK, corner_radius=10)
        applets_box.pack(fill="x", padx=25, pady=10)

        ctk.CTkLabel(
            applets_box,
            text="Windows Administrative Consoles & Snap-ins",
            font=("Segoe UI", 14, "bold"),
        ).pack(anchor="w", padx=20, pady=(15, 10))

        grid_applets = ctk.CTkFrame(applets_box, fg_color="transparent")
        grid_applets.pack(fill="x", padx=20, pady=(0, 20))
        grid_applets.grid_columnconfigure((0, 1, 2, 3), weight=1)

        applet_list = [
            ("Task Manager", "task_manager"),
            ("Device Manager", "device_manager"),
            ("Services Console", "services"),
            ("Event Viewer", "event_viewer"),
            ("Disk Management", "disk_management"),
            ("Windows Update", "windows_update"),
            ("Network Connections", "network_connections"),
            ("System Info (msinfo32)", "system_info"),
        ]

        for idx, (label, key) in enumerate(applet_list):
            row = idx // 4
            col = idx % 4
            ctk.CTkButton(
                grid_applets,
                text=label,
                fg_color="#1E293B",
                hover_color="#334155",
                command=lambda k=key: self.app.system_service.launch_applet(k),
            ).grid(row=row, column=col, padx=4, pady=4, sticky="ew")

        # ---------------------------------------------------------------------
        # Output Terminal
        # ---------------------------------------------------------------------
        term_box = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        term_box.pack(fill="both", expand=True, padx=25, pady=(10, 25))

        ctk.CTkLabel(term_box, text="Tool Execution Output", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=15, pady=(12, 5))

        self.txt_output = ctk.CTkTextbox(
            term_box,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#38BDF8",
            height=200,
            corner_radius=6,
        )
        self.txt_output.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        self.txt_output.insert("end", "Select any repair tool or utility above to run it.\nNote: DISM and SFC operations can take several minutes to complete.\n\n")

    def _run_tool(self, func: Any) -> None:
        self.txt_output.insert("end", "[*] Starting tool execution. Please wait...\n")
        self.txt_output.see("end")

        def _worker():
            try:
                res = func()
                out = f"> {' '.join(res.command)}\n{res.full_output}\n(Finished with exit code {res.exit_code})\n\n"
                self.after(0, lambda: [self.txt_output.insert("end", out), self.txt_output.see("end")])
            except Exception as e:
                self.after(0, lambda: [self.txt_output.insert("end", f"[ERROR] {str(e)}\n\n"), self.txt_output.see("end")])

        threading.Thread(target=_worker, daemon=True).start()
