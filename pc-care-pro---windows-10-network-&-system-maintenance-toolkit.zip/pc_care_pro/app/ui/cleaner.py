"""
PC Care Pro - Safe PC Cleaner View
==================================
Two-phase temporary file cleaning interface:
Phase 1: Dry-run scan displaying file count and recoverable disk space.
Phase 2: Atomic cleanup with permission error tolerance and audit summary.
"""

import threading
from typing import Any, List
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore
    from tkinter import messagebox
else:
    from tkinter import messagebox

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_SUCCESS,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)
from app.services.cleaner_service import CleanerTargetSummary


class CleanerView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Temporary file scanner and safe disk space reclaimer."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self.scanned_targets: List[CleanerTargetSummary] = []
        self._build_widgets()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="PC Cleaner & Temporary File Reclaimer",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Safely scan and clean temporary application and system caches with zero risk to personal documents",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Top summary card
        summary_card = ctk.CTkFrame(self, fg_color=COLOR_CARD_DARK, corner_radius=10)
        summary_card.pack(fill="x", padx=25, pady=(0, 15))
        summary_card.grid_columnconfigure((0, 1, 2), weight=1)

        self.lbl_candidate_files = self._metric_box(summary_card, 0, "Candidate Files", "0 files")
        self.lbl_recoverable_space = self._metric_box(summary_card, 1, "Estimated Reclaim", "0.0 MB")
        self.lbl_scan_status = self._metric_box(summary_card, 2, "Scanner Status", "Ready to Scan")

        # Action bar
        act_bar = ctk.CTkFrame(self, fg_color="transparent")
        act_bar.pack(fill="x", padx=25, pady=5)

        self.btn_scan = ctk.CTkButton(
            act_bar,
            text="1. Scan & Preview Targets (Dry Run)",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            command=self._start_scan,
        )
        self.btn_scan.pack(side="left", padx=(0, 10))

        self.btn_clean = ctk.CTkButton(
            act_bar,
            text="2. Clean Selected Temporary Files",
            fg_color="#059669",
            hover_color="#10B981",
            state="disabled",
            command=self._start_clean,
        )
        self.btn_clean.pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Launch Windows Disk Cleanup",
            fg_color="#334155",
            hover_color="#475569",
            command=self.app.cleaner_service.launch_windows_disk_cleanup,
        ).pack(side="right")

        # Detailed Target List & Log
        content_box = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        content_box.pack(fill="both", expand=True, padx=25, pady=(10, 20))

        ctk.CTkLabel(content_box, text="Cleanup Targets & Execution Details", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=15, pady=(15, 5))

        self.txt_log = ctk.CTkTextbox(
            content_box,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#38BDF8",
            corner_radius=6,
        )
        self.txt_log.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        self.txt_log.insert(
            "end",
            "Safe Cleaner Ready.\n"
            "Safety Guarantee: Only %TEMP% and C:\\Windows\\Temp are scanned.\n"
            "Personal folders (Documents, Desktop, Downloads, Photos) are strictly excluded.\n"
            "Click 'Scan & Preview Targets' to estimate recoverable space.\n\n"
        )

    def _metric_box(self, parent: Any, col: int, title: str, default_val: str) -> Any:
        f = ctk.CTkFrame(parent, fg_color="transparent")
        f.grid(row=0, column=col, padx=15, pady=15, sticky="nsew")
        ctk.CTkLabel(f, text=title, font=("Segoe UI", 11), text_color=COLOR_TEXT_MUTED).pack(anchor="w")
        lbl = ctk.CTkLabel(f, text=default_val, font=("Segoe UI", 18, "bold"), text_color=COLOR_TEXT_PRIMARY)
        lbl.pack(anchor="w")
        return lbl

    def _start_scan(self) -> None:
        self.btn_scan.configure(state="disabled")
        self.lbl_scan_status.configure(text="Scanning...")
        self.txt_log.insert("end", "[*] Starting dry-run scan of approved temporary locations...\n")

        def _worker():
            summaries = self.app.cleaner_service.scan_all()
            total_files = sum(s.file_count for s in summaries)
            total_bytes = sum(s.total_bytes for s in summaries)

            formatted_bytes = "0.0 MB"
            bv = total_bytes
            for unit in ["B", "KB", "MB", "GB"]:
                if bv < 1024.0:
                    formatted_bytes = f"{bv:.1f} {unit}"
                    break
                bv /= 1024.0

            def _update():
                self.scanned_targets = summaries
                self.lbl_candidate_files.configure(text=f"{total_files:,} files")
                self.lbl_recoverable_space.configure(text=formatted_bytes)
                self.lbl_scan_status.configure(text="Scan Complete")
                self.btn_scan.configure(state="normal")
                self.btn_clean.configure(state="normal" if total_files > 0 else "disabled")

                for s in summaries:
                    self.txt_log.insert("end", f"  Target: {s.target_name}\n")
                    self.txt_log.insert("end", f"    Path : {s.path}\n")
                    self.txt_log.insert("end", f"    Stats: {s.file_count:,} files ({s.formatted_size})\n\n")

                self.txt_log.insert("end", f"[OK] Scan finished. Estimated space to reclaim: {formatted_bytes}.\n\n")
                self.txt_log.see("end")

            self.after(0, _update)

        threading.Thread(target=_worker, daemon=True).start()

    def _start_clean(self) -> None:
        confirm = messagebox.askyesno(
            "Confirm Temporary File Cleanup",
            f"Are you sure you want to clean temporary files?\n\n"
            f"Found: {self.lbl_candidate_files.cget('text')} ({self.lbl_recoverable_space.cget('text')})\n"
            f"Note: In-use or locked files will be skipped automatically."
        )
        if not confirm:
            return

        self.btn_clean.configure(state="disabled")
        self.btn_scan.configure(state="disabled")
        self.lbl_scan_status.configure(text="Cleaning...")
        self.txt_log.insert("end", "[*] Executing safe file removal...\n")

        def _worker():
            total_deleted = 0
            total_skipped = 0
            total_freed = 0

            for target in self.app.cleaner_service.get_supported_targets():
                summary = self.app.cleaner_service.clean_target(target["path"], dry_run=False)
                total_deleted += summary.deleted_files
                total_skipped += summary.skipped_files
                total_freed += summary.bytes_freed

            def _update():
                self.btn_scan.configure(state="normal")
                self.btn_clean.configure(state="disabled")
                self.lbl_scan_status.configure(text="Cleanup Finished")
                self.lbl_candidate_files.configure(text="0 files")
                self.lbl_recoverable_space.configure(text="0.0 MB")

                freed_fmt = f"{total_freed / (1024**2):.1f} MB"
                self.txt_log.insert(
                    "end",
                    f"\n[SUMMARY] Cleanup Completed Successfully!\n"
                    f"  - Deleted files: {total_deleted:,}\n"
                    f"  - Skipped (locked / in-use): {total_skipped:,}\n"
                    f"  - Reclaimed space: {freed_fmt}\n\n"
                )
                self.txt_log.see("end")

            self.after(0, _update)

        threading.Thread(target=_worker, daemon=True).start()
