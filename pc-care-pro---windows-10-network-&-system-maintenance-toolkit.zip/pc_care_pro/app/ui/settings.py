"""
PC Care Pro - Settings View
===========================
Configures application preferences: default ping targets, timeout thresholds,
confirmation dialogues, and logging verbosity.
"""

from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore
    from tkinter import messagebox
else:
    from tkinter import messagebox

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class SettingsView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Application preferences and configuration settings."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Settings & Preferences",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Configure diagnostic parameters, execution timeouts, and confirmation alerts",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 20))

        # Settings Card Container
        card = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        card.pack(fill="both", expand=True, padx=25, pady=(0, 20))

        ctk.CTkLabel(card, text="Diagnostic Defaults", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=20, pady=(15, 10))

        # Default Ping Target
        f_target = ctk.CTkFrame(card, fg_color="transparent")
        f_target.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(f_target, text="Default Ping Target:", width=200, anchor="w").pack(side="left")
        self.entry_target = ctk.CTkEntry(f_target, width=220)
        self.entry_target.insert(0, str(self.app.config.get("default_ping_target", "8.8.8.8")))
        self.entry_target.pack(side="left")

        # Default Ping Count
        f_count = ctk.CTkFrame(card, fg_color="transparent")
        f_count.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(f_count, text="Default Ping Count:", width=200, anchor="w").pack(side="left")
        self.entry_count = ctk.CTkEntry(f_count, width=220)
        self.entry_count.insert(0, str(self.app.config.get("default_ping_count", 4)))
        self.entry_count.pack(side="left")

        # Default Ping Timeout
        f_timeout = ctk.CTkFrame(card, fg_color="transparent")
        f_timeout.pack(fill="x", padx=20, pady=5)
        ctk.CTkLabel(f_timeout, text="Ping Timeout (ms):", width=200, anchor="w").pack(side="left")
        self.entry_timeout = ctk.CTkEntry(f_timeout, width=220)
        self.entry_timeout.insert(0, str(self.app.config.get("default_ping_timeout_ms", 2000)))
        self.entry_timeout.pack(side="left")

        # Save Button
        btn_save = ctk.CTkButton(
            card,
            text="Save Settings",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            width=140,
            command=self._save_settings,
        )
        btn_save.pack(anchor="w", padx=20, pady=25)

    def _save_settings(self) -> None:
        target = self.entry_target.get().strip()
        count = self.entry_count.get().strip()
        timeout = self.entry_timeout.get().strip()

        try:
            self.app.config.set("default_ping_target", target)
            self.app.config.set("default_ping_count", int(count))
            self.app.config.set("default_ping_timeout_ms", int(timeout))
            messagebox.showinfo("Settings", "Preferences saved successfully!")
        except Exception as e:
            messagebox.showerror("Error", f"Failed to save settings: {e}")
