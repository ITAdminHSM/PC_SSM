"""
PC Care Pro - Wi-Fi Manager View
================================
Displays wireless adapter telemetry (SSID, signal %, radio type, rates),
lists scanned access points, and saved profile names with safe reconnection.
Password protection: Passwords are NEVER queried or displayed.
"""

import threading
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class WiFiManagerView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Wi-Fi interface and wireless networks manager."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()
        self.refresh_wifi_data()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Wi-Fi & Wireless Adapter Manager",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Inspect wireless link quality, detect access points, and manage profiles without revealing credentials",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Main horizontal split
        split_frame = ctk.CTkFrame(self, fg_color="transparent")
        split_frame.pack(fill="both", expand=True, padx=25, pady=(0, 20))
        split_frame.grid_columnconfigure((0, 1), weight=1)
        split_frame.grid_rowconfigure(0, weight=1)

        # Left Column: Adapter Telemetry & Adapter Actions
        left_col = ctk.CTkFrame(split_frame, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        left_col.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        ctk.CTkLabel(left_col, text="Wireless Interface Telemetry", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        self.lbl_adapter_name = self._add_stat_row(left_col, "Adapter Name:", "Scanning...")
        self.lbl_adapter_state = self._add_stat_row(left_col, "Interface State:", "Scanning...")
        self.lbl_ssid = self._add_stat_row(left_col, "Connected SSID:", "None")
        self.lbl_signal = self._add_stat_row(left_col, "Signal Strength:", "N/A")
        self.lbl_radio = self._add_stat_row(left_col, "Radio Protocol:", "N/A")
        self.lbl_rates = self._add_stat_row(left_col, "Rx / Tx Rates:", "N/A")
        self.lbl_channel = self._add_stat_row(left_col, "Channel:", "N/A")

        # Adapter Control Buttons
        btn_box = ctk.CTkFrame(left_col, fg_color=COLOR_CARD_DARK, corner_radius=8)
        btn_box.pack(fill="x", padx=15, pady=20)
        ctk.CTkLabel(btn_box, text="Hardware Controls (Requires Admin)", font=("Segoe UI", 12, "bold")).pack(anchor="w", padx=10, pady=(10, 5))

        ctk.CTkButton(
            btn_box,
            text="Restart Wireless Adapter",
            fg_color="#D97706",
            hover_color="#B45309",
            command=self._restart_adapter,
        ).pack(fill="x", padx=10, pady=5)

        ctk.CTkButton(
            btn_box,
            text="Refresh Wi-Fi Status",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            command=self.refresh_wifi_data,
        ).pack(fill="x", padx=10, pady=(5, 10))

        # Right Column: Available Networks & Saved Profiles
        right_col = ctk.CTkFrame(split_frame, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        right_col.grid(row=0, column=1, sticky="nsew")

        ctk.CTkLabel(right_col, text="Visible Networks & Saved Profiles", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        self.txt_networks = ctk.CTkTextbox(
            right_col,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#38BDF8",
            corner_radius=6,
        )
        self.txt_networks.pack(fill="both", expand=True, padx=15, pady=(0, 15))

    def _add_stat_row(self, parent: Any, label_text: str, default_val: str) -> Any:
        f = ctk.CTkFrame(parent, fg_color="transparent")
        f.pack(fill="x", padx=15, pady=3)
        ctk.CTkLabel(f, text=label_text, width=140, anchor="w", font=("Segoe UI", 11), text_color=COLOR_TEXT_MUTED).pack(side="left")
        lbl_val = ctk.CTkLabel(f, text=default_val, anchor="w", font=("Segoe UI", 11, "bold"), text_color=COLOR_TEXT_PRIMARY)
        lbl_val.pack(side="left", fill="x", expand=True)
        return lbl_val

    def refresh_wifi_data(self) -> None:
        def _worker():
            state = self.app.wifi_service.get_interface_details()
            networks = self.app.wifi_service.scan_available_networks()
            profiles = self.app.wifi_service.get_saved_profiles()

            def _update():
                if state:
                    self.lbl_adapter_name.configure(text=state.name)
                    self.lbl_adapter_state.configure(text=state.state)
                    self.lbl_ssid.configure(text=state.ssid or "Disconnected")
                    self.lbl_signal.configure(text=f"{state.signal_pct}%" if state.signal_pct is not None else "N/A")
                    self.lbl_radio.configure(text=f"{state.radio_type or 'N/A'} ({state.authentication or ''})")
                    self.lbl_rates.configure(text=f"{state.receive_rate_mbps or 0} / {state.transmit_rate_mbps or 0} Mbps")
                    self.lbl_channel.configure(text=str(state.channel or "N/A"))
                else:
                    self.lbl_adapter_name.configure(text="No Wireless Adapter Detected")
                    self.lbl_adapter_state.configure(text="Inactive")

                # Format network list
                self.txt_networks.delete("1.0", "end")
                self.txt_networks.insert("end", f"=== SAVED PROFILES ({len(profiles)}) ===\n")
                for p in profiles:
                    self.txt_networks.insert("end", f"  * {p}\n")

                self.txt_networks.insert("end", f"\n=== VISIBLE NETWORKS ({len(networks)}) ===\n")
                for n in networks:
                    self.txt_networks.insert(
                        "end",
                        f"  [Signal: {n.signal_pct}%] {n.ssid:<25} | {n.authentication} | {n.encryption}\n",
                    )

            self.after(0, _update)

        threading.Thread(target=_worker, daemon=True).start()

    def _restart_adapter(self) -> None:
        def _worker():
            try:
                self.app.wifi_service.restart_adapter()
                self.after(1500, self.refresh_wifi_data)
            except Exception as e:
                pass
        threading.Thread(target=_worker, daemon=True).start()
