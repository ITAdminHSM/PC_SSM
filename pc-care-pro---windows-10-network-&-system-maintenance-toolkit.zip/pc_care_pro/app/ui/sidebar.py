"""
PC Care Pro - Sidebar Navigation View
=====================================
Reusable sidebar displaying branding, administrative status indicator,
and 11 navigation buttons.
"""

from typing import Callable, Dict, List, Tuple
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore

from app.constants import (
    APP_NAME,
    COLOR_ACCENT_HOVER,
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class SidebarView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Left navigation panel with 11 primary sections."""

    NAV_ITEMS: List[Tuple[str, str]] = [
        ("dashboard", "Dashboard"),
        ("diagnostics", "Internet Diagnostics"),
        ("wifi_manager", "Wi-Fi Manager"),
        ("repair_center", "Network Repair Centre"),
        ("cleaner", "PC Cleaner"),
        ("windows_tools", "Windows Repair Tools"),
        ("system_info", "System Information"),
        ("console", "Command Console"),
        ("reports", "Logs and Reports"),
        ("settings", "Settings"),
        ("about", "About PC Care Pro"),
    ]

    def __init__(self, parent, on_navigate: Callable[[str], None], **kwargs) -> None:
        super().__init__(parent, width=240, fg_color=COLOR_PANEL_DARK, corner_radius=0, **kwargs)
        self.on_navigate = on_navigate
        self.buttons: Dict[str, Any] = {}
        self.active_id: str = "dashboard"

        self._build_widgets()

    def _build_widgets(self) -> None:
        """Constructs branding header, admin badge, and navigation buttons."""
        # Branding Header
        header_frame = ctk.CTkFrame(self, fg_color="transparent")
        header_frame.pack(fill="x", padx=15, pady=(20, 15))

        title_label = ctk.CTkLabel(
            header_frame,
            text=APP_NAME,
            font=("Segoe UI", 18, "bold"),
            text_color=COLOR_ACCENT_TEAL,
            anchor="w",
        )
        title_label.pack(fill="x")

        subtitle_label = ctk.CTkLabel(
            header_frame,
            text="Maintenance Toolkit",
            font=("Segoe UI", 11),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_label.pack(fill="x")

        # Admin Badge
        is_admin = getattr(self.master, "is_admin", False)
        badge_color = "#10B981" if is_admin else "#64748B"
        badge_text = "ADMINISTRATOR" if is_admin else "STANDARD USER"

        badge_frame = ctk.CTkFrame(self, fg_color=badge_color, corner_radius=6, height=24)
        badge_frame.pack(fill="x", padx=15, pady=(0, 15))
        badge_lbl = ctk.CTkLabel(
            badge_frame,
            text=badge_text,
            font=("Segoe UI", 10, "bold"),
            text_color="#FFFFFF",
        )
        badge_lbl.pack(pady=2)

        # Navigation Buttons List
        nav_scroll = ctk.CTkScrollableFrame(self, fg_color="transparent")
        nav_scroll.pack(fill="both", expand=True, padx=8, pady=5)

        for item_id, label in self.NAV_ITEMS:
            btn = ctk.CTkButton(
                nav_scroll,
                text=label,
                anchor="w",
                font=("Segoe UI", 12),
                height=36,
                corner_radius=6,
                fg_color="transparent",
                text_color=COLOR_TEXT_PRIMARY,
                hover_color=COLOR_CARD_DARK,
                command=lambda id_=item_id: self._handle_click(id_),
            )
            btn.pack(fill="x", pady=2)
            self.buttons[item_id] = btn

        # Version footer
        footer_lbl = ctk.CTkLabel(
            self,
            text="v1.0.0 | Offline-First",
            font=("Segoe UI", 10),
            text_color=COLOR_TEXT_MUTED,
        )
        footer_lbl.pack(side="bottom", pady=10)

    def _handle_click(self, item_id: str) -> None:
        self.set_active_item(item_id)
        self.on_navigate(item_id)

    def set_active_item(self, item_id: str) -> None:
        """Highlights the active button."""
        self.active_id = item_id
        for bid, btn in self.buttons.items():
            if bid == item_id:
                btn.configure(fg_color=COLOR_ACCENT_TEAL, text_color="#0A1128", font=("Segoe UI", 12, "bold"))
            else:
                btn.configure(fg_color="transparent", text_color=COLOR_TEXT_PRIMARY, font=("Segoe UI", 12))
