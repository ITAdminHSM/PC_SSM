"""
PC Care Pro - Network Repair Centre View
========================================
Interactive repair actions with confirmation modal workflows,
administrator privilege badges, and live audit history table.
"""

import threading
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore
    from tkinter import messagebox
else:
    from tkinter import messagebox

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_DANGER,
    COLOR_PANEL_DARK,
    COLOR_SUCCESS,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
    COLOR_WARNING,
)


class RepairCenterView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Network stack troubleshooting and repair workbench."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Network Repair Centre",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Step-by-step restoration tools for socket catalogs, IP stacks, DNS cache, and firewall rules",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Split pane: Left Repair Actions, Right Repair History
        panes = ctk.CTkFrame(self, fg_color="transparent")
        panes.pack(fill="both", expand=True, padx=25, pady=(0, 20))
        panes.grid_columnconfigure((0, 1), weight=1)
        panes.grid_rowconfigure(0, weight=1)

        # Left: Repair Action Cards (Scrollable)
        actions_scroll = ctk.CTkScrollableFrame(panes, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        actions_scroll.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        ctk.CTkLabel(actions_scroll, text="Available Repair Operations", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        # Action 1: Flush DNS
        self._create_repair_card(
            parent=actions_scroll,
            title="1. Flush DNS Resolver Cache",
            desc="Clears corrupted DNS name mappings from memory without interrupting connections.",
            is_elevated=False,
            btn_text="Flush DNS Cache",
            btn_color=COLOR_ACCENT_TEAL,
            action=self._action_flush_dns,
        )

        # Action 2: Release & Renew DHCP
        self._create_repair_card(
            parent=actions_scroll,
            title="2. Release & Renew DHCP IP",
            desc="Drops current local IP lease and re-queries the router for fresh configuration.",
            is_elevated=False,
            btn_text="Refresh DHCP Lease",
            btn_color=COLOR_ACCENT_TEAL,
            action=self._action_dhcp_renew,
        )

        # Action 3: Reset Winsock Catalog
        self._create_repair_card(
            parent=actions_scroll,
            title="3. Reset Winsock Catalog (Requires Restart)",
            desc="Restores Windows socket API providers to pristine defaults. Fixes LSP hijacking.",
            is_elevated=True,
            btn_text="Reset Winsock",
            btn_color="#D97706",
            action=self._action_reset_winsock,
        )

        # Action 4: Reset TCP/IP Stack
        self._create_repair_card(
            parent=actions_scroll,
            title="4. Reset TCP/IP Stack (Requires Restart)",
            desc="Rewrites damaged IP interface registry keys back to standard Windows defaults.",
            is_elevated=True,
            btn_text="Reset TCP/IP",
            btn_color="#D97706",
            action=self._action_reset_tcpip,
        )

        # Action 5: Reset Windows Firewall
        self._create_repair_card(
            parent=actions_scroll,
            title="5. Reset Windows Defender Firewall",
            desc="Restores firewall rules to default state. Warning: Custom rules will be reset!",
            is_elevated=True,
            btn_text="Reset Firewall",
            btn_color=COLOR_DANGER,
            action=self._action_reset_firewall,
        )

        # Action 6: Native Troubleshooter
        self._create_repair_card(
            parent=actions_scroll,
            title="6. Windows Network Diagnostics Wizard",
            desc="Opens the automated built-in Windows diagnostic and recovery utility.",
            is_elevated=False,
            btn_text="Launch Wizard",
            btn_color="#334155",
            action=self.app.repair_service.launch_network_troubleshooter,
        )

        # Right: Repair History Table
        history_panel = ctk.CTkFrame(panes, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        history_panel.grid(row=0, column=1, sticky="nsew")

        ctk.CTkLabel(history_panel, text="Session Repair Audit History", font=("Segoe UI", 14, "bold")).pack(anchor="w", padx=15, pady=(15, 10))

        self.txt_history = ctk.CTkTextbox(
            history_panel,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#F8FAFC",
            corner_radius=6,
        )
        self.txt_history.pack(fill="both", expand=True, padx=15, pady=(0, 15))
        self._refresh_history_display()

    def _create_repair_card(
        self,
        parent: Any,
        title: str,
        desc: str,
        is_elevated: bool,
        btn_text: str,
        btn_color: str,
        action: Any,
    ) -> None:
        card = ctk.CTkFrame(parent, fg_color=COLOR_CARD_DARK, corner_radius=8)
        card.pack(fill="x", padx=10, pady=6)

        hdr = ctk.CTkFrame(card, fg_color="transparent")
        hdr.pack(fill="x", padx=12, pady=(10, 2))
        ctk.CTkLabel(hdr, text=title, font=("Segoe UI", 12, "bold")).pack(side="left")

        if is_elevated:
            badge = ctk.CTkLabel(
                hdr,
                text="ADMIN",
                font=("Segoe UI", 9, "bold"),
                text_color="#F59E0B",
            )
            badge.pack(side="right")

        ctk.CTkLabel(
            card,
            text=desc,
            font=("Segoe UI", 11),
            text_color=COLOR_TEXT_MUTED,
            wraplength=400,
            justify="left",
        ).pack(anchor="w", padx=12, pady=2)

        ctk.CTkButton(
            card,
            text=btn_text,
            fg_color=btn_color,
            text_color="#0A1128" if btn_color == COLOR_ACCENT_TEAL else "#FFFFFF",
            height=30,
            command=action,
        ).pack(fill="x", padx=12, pady=(6, 10))

    def _refresh_history_display(self) -> None:
        entries = self.app.repair_service.get_history()
        self.txt_history.delete("1.0", "end")
        if not entries:
            self.txt_history.insert("end", "No repair operations executed in this session.\nSelect any operation on the left to begin.")
            return

        for e in reversed(entries):
            tag = "[SUCCESS]" if e.is_success else "[FAILED]"
            reboot_notice = " * SYSTEM RESTART RECOMMENDED" if e.requires_reboot else ""
            self.txt_history.insert("end", f"{e.timestamp} {tag} {e.operation_name}{reboot_notice}\n")
            self.txt_history.insert("end", f"  Summary: {e.summary}\n")
            self.txt_history.insert("end", f"  Output : {e.details.strip()[:180]}...\n")
            self.txt_history.insert("end", "-" * 55 + "\n\n")

    # Repair action confirmation wrappers
    def _action_flush_dns(self) -> None:
        self.app.repair_service.flush_dns()
        self._refresh_history_display()

    def _action_dhcp_renew(self) -> None:
        def _worker():
            self.app.repair_service.release_and_renew_dhcp()
            self.after(0, self._refresh_history_display)
        threading.Thread(target=_worker, daemon=True).start()

    def _action_reset_winsock(self) -> None:
        confirm = messagebox.askyesno(
            "Confirm Winsock Reset",
            "Are you sure you want to reset the Windows Sockets Catalog?\n\n"
            "This will restore socket protocol providers. A system restart is required."
        )
        if confirm:
            try:
                self.app.repair_service.reset_winsock()
            except Exception as e:
                messagebox.showerror("Privilege Error", str(e))
            self._refresh_history_display()

    def _action_reset_tcpip(self) -> None:
        confirm = messagebox.askyesno(
            "Confirm TCP/IP Reset",
            "Are you sure you want to reset the TCP/IP stack?\n\n"
            "This rewrites core registry entries for network interfaces. A system restart is required."
        )
        if confirm:
            try:
                self.app.repair_service.reset_tcpip()
            except Exception as e:
                messagebox.showerror("Privilege Error", str(e))
            self._refresh_history_display()

    def _action_reset_firewall(self) -> None:
        confirm = messagebox.askyesno(
            "Confirm Firewall Reset",
            "WARNING: Resetting Windows Defender Firewall will remove all custom firewall rules!\n\n"
            "Do you want to restore default Windows Firewall configuration?"
        )
        if confirm:
            try:
                self.app.repair_service.reset_firewall()
            except Exception as e:
                messagebox.showerror("Privilege Error", str(e))
            self._refresh_history_display()
