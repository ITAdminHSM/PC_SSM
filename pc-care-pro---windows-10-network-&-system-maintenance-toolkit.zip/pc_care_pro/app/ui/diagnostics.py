"""
PC Care Pro - Internet & Network Diagnostics View
=================================================
Workbench with individual execution buttons for ipconfig, ping (custom target/count/timeout),
tracert, pathping, nslookup, netstat, arp, and route commands with output display.
"""

import threading
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class DiagnosticsView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Network testing and diagnostic execution page."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()

    def _build_widgets(self) -> None:
        # Title
        title_lbl = ctk.CTkLabel(
            self,
            text="Internet & Network Diagnostics",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Run standard Windows networking commands with customizable targets and live parsed metrics",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Split pane: Left controls (scrollable), Right output console
        panes = ctk.CTkFrame(self, fg_color="transparent")
        panes.pack(fill="both", expand=True, padx=25, pady=(0, 20))
        panes.grid_columnconfigure(0, weight=1)
        panes.grid_columnconfigure(1, weight=1)
        panes.grid_rowconfigure(0, weight=1)

        # Left Controls Pane
        controls_scroll = ctk.CTkScrollableFrame(panes, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        controls_scroll.grid(row=0, column=0, sticky="nsew", padx=(0, 10))

        # Section 1: Custom Ping Workbench
        ping_box = ctk.CTkFrame(controls_scroll, fg_color=COLOR_CARD_DARK, corner_radius=8)
        ping_box.pack(fill="x", padx=10, pady=10)

        ctk.CTkLabel(ping_box, text="High-Precision Ping Utility", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=15, pady=(10, 5))
        
        # Ping inputs
        f_target = ctk.CTkFrame(ping_box, fg_color="transparent")
        f_target.pack(fill="x", padx=15, pady=2)
        ctk.CTkLabel(f_target, text="Target (IP/Host):", width=110, anchor="w").pack(side="left")
        self.entry_ping_target = ctk.CTkEntry(f_target, width=160)
        self.entry_ping_target.insert(0, "google.com")
        self.entry_ping_target.pack(side="left", padx=5)

        f_params = ctk.CTkFrame(ping_box, fg_color="transparent")
        f_params.pack(fill="x", padx=15, pady=4)
        ctk.CTkLabel(f_params, text="Packets:", width=60, anchor="w").pack(side="left")
        self.entry_ping_count = ctk.CTkEntry(f_params, width=45)
        self.entry_ping_count.insert(0, "4")
        self.entry_ping_count.pack(side="left", padx=5)

        ctk.CTkLabel(f_params, text="Timeout (ms):", width=85, anchor="w").pack(side="left", padx=(10, 0))
        self.entry_ping_timeout = ctk.CTkEntry(f_params, width=65)
        self.entry_ping_timeout.insert(0, "2000")
        self.entry_ping_timeout.pack(side="left", padx=5)

        btn_run_ping = ctk.CTkButton(
            ping_box,
            text="Execute Custom Ping",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            command=self._run_custom_ping,
        )
        btn_run_ping.pack(fill="x", padx=15, pady=(8, 12))

        # Quick Ping targets
        quick_ping_f = ctk.CTkFrame(ping_box, fg_color="transparent")
        quick_ping_f.pack(fill="x", padx=15, pady=(0, 10))
        ctk.CTkButton(quick_ping_f, text="Ping 8.8.8.8", height=28, command=lambda: self._quick_ping("8.8.8.8")).pack(side="left", expand=True, fill="x", padx=2)
        ctk.CTkButton(quick_ping_f, text="Ping 1.1.1.1", height=28, command=lambda: self._quick_ping("1.1.1.1")).pack(side="left", expand=True, fill="x", padx=2)

        # Section 2: IP Configuration
        ip_box = ctk.CTkFrame(controls_scroll, fg_color=COLOR_CARD_DARK, corner_radius=8)
        ip_box.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(ip_box, text="Windows IP Configuration (ipconfig)", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=15, pady=(10, 5))

        grid_ip = ctk.CTkFrame(ip_box, fg_color="transparent")
        grid_ip.pack(fill="x", padx=15, pady=(0, 10))
        grid_ip.grid_columnconfigure((0, 1), weight=1)

        ctk.CTkButton(grid_ip, text="ipconfig", command=lambda: self._run_async(lambda: self.app.network_service.run_ipconfig())).grid(row=0, column=0, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_ip, text="ipconfig /all", command=lambda: self._run_async(lambda: self.app.network_service.run_ipconfig("/all"))).grid(row=0, column=1, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_ip, text="ipconfig /displaydns", command=lambda: self._run_async(lambda: self.app.network_service.run_ipconfig("/displaydns"))).grid(row=1, column=0, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_ip, text="ipconfig /flushdns", command=lambda: self._run_async(lambda: self.app.network_service.flush_dns())).grid(row=1, column=1, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_ip, text="ipconfig /release", command=lambda: self._run_async(lambda: self.app.network_service.release_ip())).grid(row=2, column=0, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_ip, text="ipconfig /renew", command=lambda: self._run_async(lambda: self.app.network_service.renew_ip())).grid(row=2, column=1, padx=3, pady=3, sticky="ew")

        # Section 3: Routing & DNS Diagnostics
        route_box = ctk.CTkFrame(controls_scroll, fg_color=COLOR_CARD_DARK, corner_radius=8)
        route_box.pack(fill="x", padx=10, pady=10)
        ctk.CTkLabel(route_box, text="Path, DNS & Connection Tables", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=15, pady=(10, 5))

        grid_route = ctk.CTkFrame(route_box, fg_color="transparent")
        grid_route.pack(fill="x", padx=15, pady=(0, 10))
        grid_route.grid_columnconfigure((0, 1), weight=1)

        ctk.CTkButton(grid_route, text="nslookup google.com", command=lambda: self._run_async(lambda: self.app.network_service.nslookup("google.com"))).grid(row=0, column=0, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_route, text="tracert 8.8.8.8", command=lambda: self._run_async(lambda: self.app.network_service.traceroute("8.8.8.8"))).grid(row=0, column=1, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_route, text="netstat -ano", command=lambda: self._run_async(lambda: self.app.network_service.get_netstat())).grid(row=1, column=0, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_route, text="arp -a", command=lambda: self._run_async(lambda: self.app.network_service.get_arp_table())).grid(row=1, column=1, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_route, text="route print", command=lambda: self._run_async(lambda: self.app.network_service.get_routing_table())).grid(row=2, column=0, padx=3, pady=3, sticky="ew")
        ctk.CTkButton(grid_route, text="getmac", command=lambda: self._run_async(lambda: self.app.network_service.get_mac_addresses())).grid(row=2, column=1, padx=3, pady=3, sticky="ew")

        # Right Output Terminal Pane
        right_panel = ctk.CTkFrame(panes, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        right_panel.grid(row=0, column=1, sticky="nsew")

        # Terminal Header
        term_hdr = ctk.CTkFrame(right_panel, fg_color="transparent")
        term_hdr.pack(fill="x", padx=15, pady=(12, 5))
        ctk.CTkLabel(term_hdr, text="Command Output & Interpretation", font=("Segoe UI", 13, "bold")).pack(side="left")
        ctk.CTkButton(term_hdr, text="Clear", width=60, height=24, command=self._clear_output).pack(side="right")

        # Output text box
        self.txt_output = ctk.CTkTextbox(
            right_panel,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#38BDF8",
            corner_radius=6,
        )
        self.txt_output.pack(fill="both", expand=True, padx=15, pady=(5, 15))
        self.txt_output.insert("end", "PC Care Pro Diagnostics Terminal Ready.\nSelect any diagnostic command on the left to begin.\n\n")

    def _clear_output(self) -> None:
        self.txt_output.delete("1.0", "end")

    def _append_output(self, text: str) -> None:
        self.txt_output.insert("end", text)
        self.txt_output.see("end")

    def _run_async(self, fn: Any) -> None:
        def _worker():
            self._append_output("[*] Running command...\n")
            try:
                res = fn()
                output = f"> {' '.join(res.command)}\n{res.full_output}\n(Exit code: {res.exit_code}, Duration: {res.duration_sec:.2f}s)\n\n"
                self.after(0, lambda: self._append_output(output))
            except Exception as e:
                self.after(0, lambda: self._append_output(f"[ERROR] {str(e)}\n\n"))

        threading.Thread(target=_worker, daemon=True).start()

    def _quick_ping(self, target: str) -> None:
        self.entry_ping_target.delete(0, "end")
        self.entry_ping_target.insert(0, target)
        self._run_custom_ping()

    def _run_custom_ping(self) -> None:
        target = self.entry_ping_target.get().strip()
        count = self.entry_ping_count.get().strip()
        timeout = self.entry_ping_timeout.get().strip()

        def _worker():
            self._append_output(f"[*] Initiating ping against {target} ({count} packets, {timeout}ms timeout)...\n")
            try:
                res, stats = self.app.network_service.ping(target=target, count=int(count), timeout_ms=int(timeout))
                summary = (
                    f"--- Ping Summary for {target} ---\n"
                    f"Packets Sent: {stats.packets_sent} | Received: {stats.packets_received} | Lost: {stats.packets_lost} ({stats.packet_loss_pct:.1f}% loss)\n"
                    f"Min Latency: {stats.min_ms or 'N/A'}ms | Max: {stats.max_ms or 'N/A'}ms | Avg: {stats.avg_ms or 'N/A'}ms\n"
                    f"Status: {'REACHABLE' if stats.is_reachable else 'UNREACHABLE'}\n"
                    f"{'-'*40}\n\n"
                )
                self.after(0, lambda: self._append_output(res.stdout + "\n\n" + summary))
            except Exception as e:
                self.after(0, lambda: self._append_output(f"[ERROR] {str(e)}\n\n"))

        threading.Thread(target=_worker, daemon=True).start()
