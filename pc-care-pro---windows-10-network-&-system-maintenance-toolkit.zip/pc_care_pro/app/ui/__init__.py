"""
PC Care Pro - UI Module Factory
===============================
Dynamically instantiates view classes based on page ID navigation keys.
"""

from typing import Any


def create_view_by_id(page_id: str, parent: Any, app: Any) -> Any:
    """Factory helper to load and return the requested view class."""
    if page_id == "dashboard":
        from app.ui.dashboard import DashboardView
        return DashboardView(parent, app)
    elif page_id == "diagnostics":
        from app.ui.diagnostics import DiagnosticsView
        return DiagnosticsView(parent, app)
    elif page_id == "wifi_manager":
        from app.ui.wifi_manager import WiFiManagerView
        return WiFiManagerView(parent, app)
    elif page_id == "repair_center":
        from app.ui.repair_center import RepairCenterView
        return RepairCenterView(parent, app)
    elif page_id == "cleaner":
        from app.ui.cleaner import CleanerView
        return CleanerView(parent, app)
    elif page_id == "windows_tools":
        from app.ui.windows_tools import WindowsToolsView
        return WindowsToolsView(parent, app)
    elif page_id == "system_info":
        from app.ui.system_info import SystemInfoView
        return SystemInfoView(parent, app)
    elif page_id == "console":
        from app.ui.console import ConsoleView
        return ConsoleView(parent, app)
    elif page_id == "reports":
        from app.ui.reports import ReportsView
        return ReportsView(parent, app)
    elif page_id == "settings":
        from app.ui.settings import SettingsView
        return SettingsView(parent, app)
    elif page_id == "about":
        from app.ui.about import AboutView
        return AboutView(parent, app)
    else:
        from app.ui.dashboard import DashboardView
        return DashboardView(parent, app)
