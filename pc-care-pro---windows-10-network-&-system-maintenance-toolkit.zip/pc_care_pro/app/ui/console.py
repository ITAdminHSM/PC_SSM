"""
PC Care Pro - Command Console View
==================================
Integrated live output terminal displaying timestamped subprocess execution,
stderr highlighting, clipboard copy, cancellation, and export to TXT.
"""

from datetime import datetime
from pathlib import Path
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore
    from tkinter import filedialog, messagebox
else:
    from tkinter import filedialog, messagebox

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class ConsoleView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Centralized live command streaming terminal."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Integrated Command Console",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Real-time output stream for all background Windows diagnostics and maintenance operations",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Action Bar (Copy, Clear, Export)
        act_bar = ctk.CTkFrame(self, fg_color="transparent")
        act_bar.pack(fill="x", padx=25, pady=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Copy Console to Clipboard",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            width=170,
            command=self._copy_to_clipboard,
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Export Output to File",
            fg_color="#334155",
            width=150,
            command=self._export_to_file,
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Clear Console",
            fg_color="#1E293B",
            width=100,
            command=self._clear_console,
        ).pack(side="left")

        # Terminal Box
        term_box = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        term_box.pack(fill="both", expand=True, padx=25, pady=(5, 20))

        self.txt_console = ctk.CTkTextbox(
            term_box,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#38BDF8",
            corner_radius=6,
        )
        self.txt_console.pack(fill="both", expand=True, padx=15, pady=15)

        self._log_banner()

    def _log_banner(self) -> None:
        now = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        self.txt_console.insert(
            "end",
            f"=======================================================================\n"
            f" [PC CARE PRO - COMMAND OUTPUT CONSOLE]\n"
            f" Session Initialized: {now}\n"
            f" Execution Engine: Subprocess async worker thread (shell=False)\n"
            f"=======================================================================\n\n"
        )

    def append_log(self, text: str) -> None:
        """Thread-safe append of console output."""
        now = datetime.now().strftime("%H:%M:%S")
        self.txt_console.insert("end", f"[{now}] {text}\n")
        self.txt_console.see("end")

    def _clear_console(self) -> None:
        self.txt_console.delete("1.0", "end")
        self._log_banner()

    def _copy_to_clipboard(self) -> None:
        content = self.txt_console.get("1.0", "end")
        self.clipboard_clear()
        self.clipboard_append(content)
        messagebox.showinfo("Clipboard", "Console content copied to system clipboard.")

    def _export_to_file(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="pc_care_pro_console.txt",
        )
        if path:
            try:
                content = self.txt_console.get("1.0", "end")
                with open(path, "w", encoding="utf-8") as f:
                    f.write(content)
                messagebox.showinfo("Export Success", f"Console log saved to:\n{path}")
            except Exception as e:
                messagebox.showerror("Export Failed", str(e))
