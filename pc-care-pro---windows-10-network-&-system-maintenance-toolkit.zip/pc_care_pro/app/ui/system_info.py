"""
PC Care Pro - System Information View
=====================================
Detailed breakdown of Windows version, CPU architecture, memory utilization,
drive partition geometries, and physical network adapters with export to TXT.
"""

from pathlib import Path
import threading
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore
    from tkinter import filedialog, messagebox
else:
    from tkinter import filedialog, messagebox

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class SystemInfoView(ctk.CTkScrollableFrame if hasattr(ctk, "CTkScrollableFrame") else ctk.Frame):
    """System information breakdown and export utility."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()
        self.load_system_info()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Detailed System & Hardware Information",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Comprehensive audit of host processor, memory layout, storage volumes, and network adapters",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Action bar
        act_bar = ctk.CTkFrame(self, fg_color="transparent")
        act_bar.pack(fill="x", padx=25, pady=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Export Information to TXT Report",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            command=self._export_report,
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Refresh Hardware Information",
            fg_color="#334155",
            command=self.load_system_info,
        ).pack(side="left")

        # System Specs Table Box
        table_box = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        table_box.pack(fill="both", expand=True, padx=25, pady=(5, 20))

        self.txt_display = ctk.CTkTextbox(
            table_box,
            font=("Consolas", 11),
            fg_color="#0A1128",
            text_color="#38BDF8",
            height=450,
            corner_radius=6,
        )
        self.txt_display.pack(fill="both", expand=True, padx=15, pady=15)

    def load_system_info(self) -> None:
        def _worker():
            report_text = self.app.report_service.generate_text_report()
            self.after(0, lambda: [
                self.txt_display.delete("1.0", "end"),
                self.txt_display.insert("end", report_text),
            ])
        threading.Thread(target=_worker, daemon=True).start()

    def _export_report(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".txt",
            filetypes=[("Text files", "*.txt"), ("All files", "*.*")],
            initialfile="pc_care_pro_system_info.txt",
        )
        if path:
            try:
                self.app.report_service.export_report_to_file(path, as_json=False)
                messagebox.showinfo("Export Success", f"Report saved to:\n{path}")
            except Exception as e:
                messagebox.showerror("Export Failed", str(e))
