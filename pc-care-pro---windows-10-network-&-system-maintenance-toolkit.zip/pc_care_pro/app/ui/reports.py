"""
PC Care Pro - Logs & Reports View
=================================
Inspects application rotating logs, opens user log directory,
and exports comprehensive diagnostic packages for IT technical support.
"""

import os
from pathlib import Path
import subprocess
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore
    from tkinter import filedialog, messagebox
else:
    from tkinter import filedialog, messagebox

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)
from app.core.logger import AppLogger


class ReportsView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """Log inspector and support report exporter."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()
        self.refresh_log_file()

    def _build_widgets(self) -> None:
        title_lbl = ctk.CTkLabel(
            self,
            text="Logs & IT Diagnostic Reports",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="View rotating audit logs, open application data folders, and export diagnostic packages",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # Action Bar
        act_bar = ctk.CTkFrame(self, fg_color="transparent")
        act_bar.pack(fill="x", padx=25, pady=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Open Logs Directory",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            command=self._open_log_folder,
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Export Diagnostic Report (JSON)",
            fg_color="#334155",
            command=self._export_json_report,
        ).pack(side="left", padx=(0, 10))

        ctk.CTkButton(
            act_bar,
            text="Refresh Log View",
            fg_color="#1E293B",
            command=self.refresh_log_file,
        ).pack(side="left")

        # Log Display Container
        log_box = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=10)
        log_box.pack(fill="both", expand=True, padx=25, pady=(5, 20))

        ctk.CTkLabel(log_box, text="Current Session Log (pc_care_pro.log)", font=("Segoe UI", 13, "bold")).pack(anchor="w", padx=15, pady=(15, 5))

        self.txt_log = ctk.CTkTextbox(
            log_box,
            font=("Consolas", 10),
            fg_color="#0A1128",
            text_color="#94A3B8",
            corner_radius=6,
        )
        self.txt_log.pack(fill="both", expand=True, padx=15, pady=(0, 15))

    def refresh_log_file(self) -> None:
        log_dir = AppLogger.get_log_dir()
        log_file = log_dir / "pc_care_pro.log"
        self.txt_log.delete("1.0", "end")

        if log_file.exists():
            try:
                with open(log_file, "r", encoding="utf-8", errors="replace") as f:
                    content = f.read()
                    self.txt_log.insert("end", content[-15000:])  # Show latest 15KB
                    self.txt_log.see("end")
            except Exception as e:
                self.txt_log.insert("end", f"Could not read log file: {e}")
        else:
            self.txt_log.insert("end", f"Log file not yet created at: {log_file}")

    def _open_log_folder(self) -> None:
        log_dir = AppLogger.get_log_dir()
        try:
            if os.name == "nt":
                os.startfile(str(log_dir))  # type: ignore
            else:
                subprocess.Popen(["xdg-open", str(log_dir)])
        except Exception as e:
            messagebox.showinfo("Log Folder Location", f"Logs are stored in:\n{log_dir}")

    def _export_json_report(self) -> None:
        path = filedialog.asksaveasfilename(
            defaultextension=".json",
            filetypes=[("JSON files", "*.json"), ("All files", "*.*")],
            initialfile="pc_care_pro_diagnostics.json",
        )
        if path:
            try:
                self.app.report_service.export_report_to_file(path, as_json=True)
                messagebox.showinfo("Export Success", f"Diagnostics JSON exported to:\n{path}")
            except Exception as e:
                messagebox.showerror("Export Failed", str(e))
