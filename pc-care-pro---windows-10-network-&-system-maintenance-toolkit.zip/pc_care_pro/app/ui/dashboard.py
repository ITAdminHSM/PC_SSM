"""
PC Care Pro - Dashboard View
============================
Displays live hardware telemetry, network connectivity indicators,
and 7 functional quick-action maintenance buttons.
"""

import threading
from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore

from app.constants import (
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_DANGER,
    COLOR_SUCCESS,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class DashboardView(ctk.CTkScrollableFrame if hasattr(ctk, "CTkScrollableFrame") else ctk.Frame):
    """Primary system health dashboard and quick actions."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()
        self.refresh_telemetry()

    def _build_widgets(self) -> None:
        """Constructs telemetry cards and quick action panel."""
        # Page Title
        title_lbl = ctk.CTkLabel(
            self,
            text="System & Network Dashboard",
            font=("Segoe UI", 20, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        title_lbl.pack(fill="x", padx=25, pady=(20, 5))

        subtitle_lbl = ctk.CTkLabel(
            self,
            text="Real-time Windows 10 connectivity metrics and system health indicators",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        subtitle_lbl.pack(fill="x", padx=25, pady=(0, 15))

        # ---------------------------------------------------------------------
        # Grid of Status Cards
        # ---------------------------------------------------------------------
        cards_grid = ctk.CTkFrame(self, fg_color="transparent")
        cards_grid.pack(fill="x", padx=25, pady=10)
        cards_grid.grid_columnconfigure((0, 1, 2, 3), weight=1, uniform="cards")

        # Card 1: Internet Connectivity
        self.card_internet = self._create_card(cards_grid, 0, 0, "Internet Link", "Checking...", COLOR_TEXT_MUTED)
        # Card 2: Wi-Fi Status
        self.card_wifi = self._create_card(cards_grid, 0, 1, "Wi-Fi SSID", "Scanning...", COLOR_TEXT_MUTED)
        # Card 3: Local IPv4
        self.card_ip = self._create_card(cards_grid, 0, 2, "Local IPv4", "127.0.0.1", COLOR_TEXT_PRIMARY)
        # Card 4: CPU Load
        self.card_cpu = self._create_card(cards_grid, 0, 3, "CPU Load", "0%", COLOR_ACCENT_TEAL)

        # Row 2 Cards
        self.card_ram = self._create_card(cards_grid, 1, 0, "RAM Usage", "0%", COLOR_ACCENT_TEAL)
        self.card_disk = self._create_card(cards_grid, 1, 1, "Disk (C:)", "0%", COLOR_ACCENT_TEAL)
        self.card_os = self._create_card(cards_grid, 1, 2, "OS & Build", "Windows 10", COLOR_TEXT_PRIMARY)
        self.card_uptime = self._create_card(cards_grid, 1, 3, "Uptime", "0h 0m", COLOR_TEXT_PRIMARY)

        # ---------------------------------------------------------------------
        # Quick Actions Section
        # ---------------------------------------------------------------------
        actions_frame = ctk.CTkFrame(self, fg_color=COLOR_CARD_DARK, corner_radius=10)
        actions_frame.pack(fill="x", padx=25, pady=20)

        act_title = ctk.CTkLabel(
            actions_frame,
            text="Quick Maintenance Operations",
            font=("Segoe UI", 15, "bold"),
            text_color=COLOR_TEXT_PRIMARY,
            anchor="w",
        )
        act_title.pack(fill="x", padx=20, pady=(15, 10))

        btn_grid = ctk.CTkFrame(actions_frame, fg_color="transparent")
        btn_grid.pack(fill="x", padx=20, pady=(0, 20))
        btn_grid.grid_columnconfigure((0, 1, 2, 3), weight=1)

        # 7 Working Quick-Action Buttons
        ctk.CTkButton(
            btn_grid,
            text="Test Internet",
            fg_color=COLOR_ACCENT_TEAL,
            text_color="#0A1128",
            hover_color="#48CAE4",
            command=self._quick_test_internet,
        ).grid(row=0, column=0, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Flush DNS",
            fg_color="#1E293B",
            hover_color="#334155",
            command=self._quick_flush_dns,
        ).grid(row=0, column=1, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Renew IP",
            fg_color="#1E293B",
            hover_color="#334155",
            command=self._quick_renew_ip,
        ).grid(row=0, column=2, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Ping Google",
            fg_color="#1E293B",
            hover_color="#334155",
            command=self._quick_ping_google,
        ).grid(row=0, column=3, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Open Wi-Fi Manager",
            fg_color="#1E293B",
            hover_color="#334155",
            command=lambda: self.app.navigate_to("wifi_manager"),
        ).grid(row=1, column=0, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Clean Temp Files",
            fg_color="#1E293B",
            hover_color="#334155",
            command=lambda: self.app.navigate_to("cleaner"),
        ).grid(row=1, column=1, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Open Console",
            fg_color="#1E293B",
            hover_color="#334155",
            command=lambda: self.app.navigate_to("console"),
        ).grid(row=1, column=2, padx=5, pady=5, sticky="ew")

        ctk.CTkButton(
            btn_grid,
            text="Refresh Dashboard",
            fg_color="#0F766E",
            hover_color="#14B8A6",
            command=self.refresh_telemetry,
        ).grid(row=1, column=3, padx=5, pady=5, sticky="ew")

        # Status notification banner
        self.status_banner = ctk.CTkLabel(
            self,
            text="Ready. Select an action or run diagnostics.",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
            anchor="w",
        )
        self.status_banner.pack(fill="x", padx=25, pady=(0, 20))

    def _create_card(self, parent: Any, row: int, col: int, title: str, init_val: str, val_color: str) -> Any:
        card = ctk.CTkFrame(parent, fg_color=COLOR_CARD_DARK, corner_radius=8, height=90)
        card.grid(row=row, column=col, padx=6, pady=6, sticky="nsew")

        lbl_title = ctk.CTkLabel(card, text=title, font=("Segoe UI", 11), text_color=COLOR_TEXT_MUTED)
        lbl_title.pack(anchor="w", padx=12, pady=(10, 2))

        lbl_val = ctk.CTkLabel(card, text=init_val, font=("Segoe UI", 16, "bold"), text_color=val_color)
        lbl_val.pack(anchor="w", padx=12, pady=(0, 10))
        return lbl_val

    def refresh_telemetry(self) -> None:
        """Polls system and network telemetry in a background thread."""
        def _worker():
            telemetry = self.app.system_service.get_telemetry()
            wifi = self.app.wifi_service.get_interface_details()
            net_test = self.app.network_service.test_internet_connectivity()

            # Schedule UI updates on main thread
            self.after(0, lambda: self._update_ui_values(telemetry, wifi, net_test))

        threading.Thread(target=_worker, daemon=True).start()

    def _update_ui_values(self, telemetry: Any, wifi: Any, net_test: Any) -> None:
        """Applies retrieved telemetry to card labels."""
        # Internet
        if net_test["is_connected"]:
            lat = f"{net_test['latency_ms']:.0f}ms" if net_test["latency_ms"] else ""
            self.card_internet.configure(text=f"Connected ({lat})", text_color=COLOR_SUCCESS)
        else:
            self.card_internet.configure(text="Offline", text_color=COLOR_DANGER)

        # Wi-Fi
        if wifi and wifi.ssid:
            sig = f"{wifi.signal_pct}%" if wifi.signal_pct else ""
            self.card_wifi.configure(text=f"{wifi.ssid} ({sig})", text_color=COLOR_ACCENT_TEAL)
        elif wifi:
            self.card_wifi.configure(text=f"{wifi.state}", text_color=COLOR_TEXT_MUTED)
        else:
            self.card_wifi.configure(text="No Wi-Fi HW", text_color=COLOR_TEXT_MUTED)

        # CPU & RAM
        self.card_cpu.configure(text=f"{telemetry.cpu_percent:.1f}%")
        self.card_ram.configure(text=f"{telemetry.ram_percent:.1f}% ({telemetry.used_ram_gb:.1f}GB)")

        # Disk
        c_part = next((p for p in telemetry.partitions if "C" in p.device), None)
        if c_part:
            self.card_disk.configure(text=f"{c_part.percent_used:.0f}% ({c_part.free_gb:.0f}GB free)")

        self.card_os.configure(text=f"{telemetry.os_name} b{telemetry.os_build[:5]}")
        self.card_uptime.configure(text=telemetry.uptime_str)
        self.status_banner.configure(text=f"Last updated: {telemetry.computer_name} | {net_test['details']}")

    # Quick action handlers
    def _quick_test_internet(self) -> None:
        self.status_banner.configure(text="Testing multi-point internet availability...")
        self.refresh_telemetry()

    def _quick_flush_dns(self) -> None:
        self.status_banner.configure(text="Flushing DNS client resolver cache...")
        threading.Thread(target=lambda: [
            self.app.repair_service.flush_dns(),
            self.after(0, lambda: self.status_banner.configure(text="DNS Cache successfully flushed.")),
        ], daemon=True).start()

    def _quick_renew_ip(self) -> None:
        self.status_banner.configure(text="Releasing and renewing DHCP IPv4 lease...")
        threading.Thread(target=lambda: [
            self.app.repair_service.release_and_renew_dhcp(),
            self.after(0, lambda: self.status_banner.configure(text="DHCP lease renewal completed.")),
        ], daemon=True).start()

    def _quick_ping_google(self) -> None:
        self.status_banner.configure(text="Pinging google.com...")
        def _worker():
            _, stats = self.app.network_service.ping("google.com", count=4)
            msg = f"Ping google.com: {stats.packet_loss_pct}% loss, Avg: {stats.avg_ms or 0:.1f}ms"
            self.after(0, lambda: self.status_banner.configure(text=msg))
        threading.Thread(target=_worker, daemon=True).start()
