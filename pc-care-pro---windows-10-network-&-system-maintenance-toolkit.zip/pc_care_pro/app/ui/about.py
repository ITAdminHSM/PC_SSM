"""
PC Care Pro - About View
========================
Displays system version, software license, architectural principles,
and the offline-first privacy guarantee.
"""

from typing import Any
try:
    import customtkinter as ctk  # type: ignore
except ImportError:
    import tkinter as ctk  # type: ignore

from app.constants import (
    APP_NAME,
    APP_SUBTITLE,
    APP_VERSION,
    COLOR_ACCENT_TEAL,
    COLOR_CARD_DARK,
    COLOR_PANEL_DARK,
    COLOR_TEXT_MUTED,
    COLOR_TEXT_PRIMARY,
)


class AboutView(ctk.CTkFrame if hasattr(ctk, "CTkFrame") else ctk.Frame):
    """About PC Care Pro and technology attribution."""

    def __init__(self, parent: Any, app: Any, **kwargs) -> None:
        super().__init__(parent, fg_color="transparent", **kwargs)
        self.app = app
        self._build_widgets()

    def _build_widgets(self) -> None:
        card = ctk.CTkFrame(self, fg_color=COLOR_PANEL_DARK, corner_radius=12)
        card.pack(fill="both", expand=True, padx=25, pady=25)

        title_lbl = ctk.CTkLabel(
            card,
            text=APP_NAME,
            font=("Segoe UI", 24, "bold"),
            text_color=COLOR_ACCENT_TEAL,
        )
        title_lbl.pack(pady=(30, 2))

        sub_lbl = ctk.CTkLabel(
            card,
            text=f"{APP_SUBTITLE} (Version {APP_VERSION})",
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_MUTED,
        )
        sub_lbl.pack(pady=(0, 20))

        desc_text = (
            "PC Care Pro is an all-in-one Windows 10 maintenance, diagnostics, and troubleshooting suite.\n\n"
            "Key Architectural Principles:\n"
            "• Offline-First: Zero telemetry, zero analytics, zero external API keys, zero cloud dependencies.\n"
            "• Operational Safety: Whitelisted file cleanup, non-destructive default modes, dry-run previews.\n"
            "• Defensive Execution: Strict input validation preventing command injections; shell=False execution.\n"
            "• Test-Driven Development: Comprehensive unit and integration test coverage across all services.\n\n"
            "Built with Python 3, CustomTkinter, and native Windows 10 administrative subsystems.\n"
            "Distributed under the MIT License."
        )

        txt_info = ctk.CTkLabel(
            card,
            text=desc_text,
            font=("Segoe UI", 12),
            text_color=COLOR_TEXT_PRIMARY,
            justify="center",
            wraplength=600,
        )
        txt_info.pack(padx=30, pady=10)

        # Admin status info
        is_admin = getattr(self.app, "is_admin", False)
        priv_text = f"Current Session Status: {'Windows Administrator (Elevated)' if is_admin else 'Standard User Privilege'}"
        lbl_priv = ctk.CTkLabel(
            card,
            text=priv_text,
            font=("Segoe UI", 11, "bold"),
            text_color="#10B981" if is_admin else "#94A3B8",
        )
        lbl_priv.pack(pady=(20, 30))
