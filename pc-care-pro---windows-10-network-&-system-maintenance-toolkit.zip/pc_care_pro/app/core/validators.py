"""
PC Care Pro - Input & Parameter Validators
==========================================
Strict input validation routines to protect against command injection,
invalid networking parameters, and unsafe filesystem access.
"""

import ipaddress
import os
import re
from pathlib import Path
from typing import Tuple

from app.constants import CLEANER_APPROVED_ROOT_NAMES
from app.core.exceptions import InvalidInputError, UnsafePathError

# RFC 1123 Hostname Regex
# Allowed: Alphanumeric and hyphens, separated by dots. Total length <= 253 chars.
HOSTNAME_REGEX = re.compile(
    r"^(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)*[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?$"
)

# Network Interface Name Regex (Windows interfaces typically contain alphanumeric, spaces, hyphens, and parenthesis)
INTERFACE_NAME_REGEX = re.compile(r"^[a-zA-Z0-9\s\-_\(\)\.]{1,128}$")


class InputValidators:
    """Provides static validation methods for networking and system parameters."""

    @staticmethod
    def validate_ipv4(ip_str: str) -> str:
        """
        Validates whether a string is a valid IPv4 address.
        
        Args:
            ip_str: The string to test.
            
        Returns:
            The normalized IPv4 string.
            
        Raises:
            InvalidInputError: If ip_str is not a valid IPv4 address.
        """
        cleaned = ip_str.strip()
        try:
            addr = ipaddress.IPv4Address(cleaned)
            return str(addr)
        except (ipaddress.AddressValueError, ValueError):
            raise InvalidInputError(
                f"'{ip_str}' is not a valid IPv4 address.",
                field_name="IPv4 Address",
                input_value=ip_str,
            )

    @staticmethod
    def validate_hostname(hostname: str) -> str:
        """
        Validates whether a string is a safe, valid domain name or hostname according to RFC 1123.
        Strictly forbids any shell metacharacters like &, |, ;, >, <, $, `
        
        Args:
            hostname: Target hostname (e.g., 'google.com', 'internal-server').
            
        Returns:
            The cleaned hostname string.
            
        Raises:
            InvalidInputError: If hostname is malformed or contains illegal characters.
        """
        cleaned = hostname.strip()
        if not cleaned:
            raise InvalidInputError("Hostname cannot be empty.", field_name="Hostname", input_value=hostname)

        if len(cleaned) > 253:
            raise InvalidInputError("Hostname exceeds maximum length of 253 characters.", field_name="Hostname", input_value=hostname)

        # Check for dangerous shell metacharacters explicitly
        dangerous_chars = set("&|;><`$!*?[]{}()\"'\\/")
        if any(c in dangerous_chars for c in cleaned):
            raise InvalidInputError(
                "Hostname contains invalid or dangerous characters.",
                field_name="Hostname",
                input_value=hostname,
            )

        if not HOSTNAME_REGEX.match(cleaned):
            raise InvalidInputError(
                f"'{hostname}' is not a valid hostname format.",
                field_name="Hostname",
                input_value=hostname,
            )

        return cleaned

    @classmethod
    def validate_hostname_or_ip(cls, target: str) -> Tuple[str, str]:
        """
        Validates whether the target is either a valid IPv4 address, IPv6 address, or hostname.
        
        Args:
            target: Input string (e.g., '192.168.1.1' or 'dns.google').
            
        Returns:
            Tuple of (cleaned_target, target_type) where target_type is 'ipv4', 'ipv6', or 'hostname'.
            
        Raises:
            InvalidInputError: If target matches none of the valid formats.
        """
        cleaned = target.strip()
        if not cleaned:
            raise InvalidInputError("Destination target cannot be empty.", field_name="Target", input_value=target)

        # Try IPv4
        try:
            ipaddress.IPv4Address(cleaned)
            return cleaned, "ipv4"
        except ValueError:
            pass

        # Try IPv6
        try:
            ipaddress.IPv6Address(cleaned)
            return cleaned, "ipv6"
        except ValueError:
            pass

        # Try Hostname
        try:
            valid_host = cls.validate_hostname(cleaned)
            return valid_host, "hostname"
        except InvalidInputError:
            raise InvalidInputError(
                f"'{target}' is neither a valid IP address nor a valid hostname.",
                field_name="Target",
                input_value=target,
            )

    @staticmethod
    def validate_ping_count(count: int | str) -> int:
        """
        Ensures ping packet count is within safe boundaries (1 to 100).
        """
        try:
            val = int(count)
        except (ValueError, TypeError):
            raise InvalidInputError("Packet count must be an integer.", field_name="Packet Count", input_value=str(count))

        if val < 1 or val > 100:
            raise InvalidInputError(
                "Packet count must be between 1 and 100.",
                field_name="Packet Count",
                input_value=str(count),
            )
        return val

    @staticmethod
    def validate_ping_timeout_ms(timeout_ms: int | str) -> int:
        """
        Ensures ping timeout is within safe boundaries (100ms to 60,000ms).
        """
        try:
            val = int(timeout_ms)
        except (ValueError, TypeError):
            raise InvalidInputError("Timeout must be an integer.", field_name="Timeout (ms)", input_value=str(timeout_ms))

        if val < 100 or val > 60000:
            raise InvalidInputError(
                "Timeout must be between 100ms and 60,000ms (60s).",
                field_name="Timeout (ms)",
                input_value=str(timeout_ms),
            )
        return val

    @staticmethod
    def validate_interface_name(name: str) -> str:
        """
        Validates Windows network interface name (e.g. 'Wi-Fi', 'Ethernet 2').
        """
        cleaned = name.strip()
        if not cleaned:
            raise InvalidInputError("Interface name cannot be empty.", field_name="Interface", input_value=name)

        if not INTERFACE_NAME_REGEX.match(cleaned):
            raise InvalidInputError(
                "Interface name contains illegal characters.",
                field_name="Interface",
                input_value=name,
            )
        return cleaned

    @staticmethod
    def validate_cleaner_path(candidate_path: str | Path) -> Path:
        """
        Enforces that candidate directories for cleanup reside strictly inside
        approved temporary directory roots.
        
        Prevents traversal attacks and accidental deletion of user folders.
        """
        p = Path(candidate_path).resolve()
        path_str_upper = str(p).upper()

        # Check against approved keywords in path
        matched = False
        for approved_root in CLEANER_APPROVED_ROOT_NAMES:
            if approved_root.upper() in path_str_upper:
                matched = True
                break

        if not matched:
            raise UnsafePathError(
                str(p),
                reason=f"Path '{p}' is not within any approved temporary root directories."
            )

        # Explicitly protect sensitive system and user roots
        prohibited_indicators = ["SYSTEM32", "SYSWOW64", "PROGRAM FILES", "DOCUMENTS", "DOWNLOADS", "DESKTOP", "PICTURES", "VIDEOS"]
        for prohibited in prohibited_indicators:
            # If path ends in or is exactly a prohibited user directory
            if f"\\{prohibited}" in path_str_upper or path_str_upper.endswith(f"\\{prohibited}"):
                raise UnsafePathError(str(p), reason=f"Path points to protected directory '{prohibited}'.")

        return p
