"""
PC Care Pro - Domain Exceptions
===============================
Strongly-typed exception hierarchy for controlled error reporting and
predictable error recovery across services and UI controllers.
"""


class PCCareProError(Exception):
    """Base exception for all PC Care Pro domain errors."""
    pass


class InvalidInputError(PCCareProError):
    """Raised when user input fails strict validation (e.g. malformed IP or command injection attempt)."""
    def __init__(self, message: str, field_name: str = "", input_value: str = "") -> None:
        super().__init__(message)
        self.field_name = field_name
        self.input_value = input_value


class CommandExecutionError(PCCareProError):
    """Raised when a system command returns a non-zero exit code or encounters runtime failure."""
    def __init__(self, message: str, command: str, exit_code: int = -1, stderr: str = "") -> None:
        super().__init__(message)
        self.command = command
        self.exit_code = exit_code
        self.stderr = stderr


class ExecutionTimeoutError(CommandExecutionError):
    """Raised when a system command exceeds its allocated timeout duration."""
    def __init__(self, command: str, timeout_sec: int) -> None:
        super().__init__(
            f"Command '{command}' timed out after {timeout_sec} seconds.",
            command=command,
            exit_code=124,
            stderr="Execution timed out"
        )
        self.timeout_sec = timeout_sec


class CommandNotFoundError(PCCareProError):
    """Raised when a required system utility is missing from PATH."""
    def __init__(self, command: str) -> None:
        super().__init__(f"System utility '{command}' was not found in PATH.")
        self.command = command


class PermissionDeniedError(PCCareProError):
    """Raised when an operation requires Windows Administrator elevation."""
    def __init__(self, operation_name: str) -> None:
        super().__init__(f"Operation '{operation_name}' requires Windows Administrator privileges.")
        self.operation_name = operation_name


class UnsafePathError(PCCareProError):
    """Raised when a cleaner operation attempts to access an unwhitelisted directory."""
    def __init__(self, path: str, reason: str = "Path is outside approved temporary directories.") -> None:
        super().__init__(f"Unsafe path detected '{path}': {reason}")
        self.path = path
