"""
PC Care Pro - Windows Administrator Privilege Manager
=====================================================
Handles Windows UAC detection, elevation verification, and safe elevation
requests using native Win32 Shell32 APIs without silent privilege escalation.
"""

import os
import platform
import sys
from typing import Dict, Final, List


class AdminManager:
    """
    Manages detection and escalation of Windows Administrator privileges.
    """

    # Operations requiring Windows administrative elevation
    ELEVATED_OPERATIONS: Final[Dict[str, str]] = {
        "reset_winsock": "Resetting the Winsock catalog modifies low-level Windows socket provider drivers.",
        "reset_tcpip": "Resetting TCP/IP rewrites system IP interface registry configurations.",
        "reset_firewall": "Restoring Windows Firewall to default state requires network security policy permissions.",
        "toggle_adapter": "Enabling or disabling network adapters changes hardware driver binding states.",
        "flush_dns": "Flushing DNS resolver cache (often succeeds standard, but full flush benefits from elevation).",
        "sfc_scannow": "System File Checker repairs protected operating system files in Windows servicing directories.",
        "dism_restore": "DISM component store cleanup writes to Windows side-by-side component store.",
        "clean_windows_temp": "Cleaning C:\\Windows\\Temp requires administrative permissions to remove system-created temporary files.",
    }

    @classmethod
    def is_running_as_admin(cls) -> bool:
        """
        Determines whether the current process has Windows Administrator privileges.
        
        On Windows: Uses ctypes.windll.shell32.IsUserAnAdmin()
        On POSIX: Uses os.geteuid() == 0 (for testing environments)
        
        Returns:
            True if process is elevated, False otherwise.
        """
        if platform.system() == "Windows":
            try:
                import ctypes
                return bool(ctypes.windll.shell32.IsUserAnAdmin())
            except Exception:
                return False
        else:
            # POSIX / Linux environment fallback
            try:
                return os.geteuid() == 0
            except AttributeError:
                return False

    @classmethod
    def requires_elevation(cls, operation_key: str) -> bool:
        """Checks if a given operation requires Windows Administrator rights."""
        return operation_key in cls.ELEVATED_OPERATIONS

    @classmethod
    def get_elevation_explanation(cls, operation_key: str) -> str:
        """Returns a clear, non-technical explanation for why elevation is required."""
        return cls.ELEVATED_OPERATIONS.get(
            operation_key,
            "This operation modifies system-wide Windows network or file configurations."
        )

    @classmethod
    def request_elevation(cls, extra_args: List[str] | None = None) -> bool:
        """
        Re-launches the current application with requested Windows Administrator privileges
        via Windows UAC 'runas' verb.
        
        Never runs silently.
        
        Returns:
            True if the elevation call was successfully dispatched, False otherwise.
        """
        if cls.is_running_as_admin():
            return True

        if platform.system() != "Windows":
            return False

        try:
            import ctypes
            args = sys.argv[1:]
            if extra_args:
                args.extend(extra_args)
            params = " ".join(f'"{a}"' for a in args)

            # ShellExecuteW with verb "runas" prompts Windows UAC
            ret = ctypes.windll.shell32.ShellExecuteW(
                None,
                "runas",
                sys.executable,
                params,
                None,
                1  # SW_SHOWNORMAL
            )
            return ret > 32
        except Exception:
            return False
