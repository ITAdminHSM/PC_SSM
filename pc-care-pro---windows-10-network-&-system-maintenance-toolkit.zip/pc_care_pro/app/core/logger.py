"""
PC Care Pro - Application Logger
================================
Configures a thread-safe rotating file logger with human-readable timestamps.
Enforces PII-scrubbing (e.g. Wi-Fi passwords, sensitive tokens) and limits file size.
"""

import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional


class AppLogger:
    """
    Centralized logging coordinator for PC Care Pro.
    """

    _logger: Optional[logging.Logger] = None
    _log_dir: Optional[Path] = None

    @classmethod
    def setup(cls, log_dir: Optional[Path] = None, verbose: bool = False) -> logging.Logger:
        """
        Initializes the application logger with rotating file handler and console handler.
        
        Args:
            log_dir: Directory where log files are stored. Defaults to ./reports or %APPDATA%/PCCarePro/logs.
            verbose: If True, set level to DEBUG; otherwise INFO.
            
        Returns:
            Configured logging.Logger instance.
        """
        if cls._logger is not None:
            return cls._logger

        if log_dir is None:
            # Check for local reports directory first
            local_reports = Path("./reports")
            if local_reports.exists() and os.access(local_reports, os.W_OK):
                cls._log_dir = local_reports
            else:
                appdata = os.environ.get("APPDATA")
                if appdata:
                    cls._log_dir = Path(appdata) / "PCCarePro" / "logs"
                else:
                    cls._log_dir = Path.home() / ".pc_care_pro" / "logs"
        else:
            cls._log_dir = log_dir

        cls._log_dir.mkdir(parents=True, exist_ok=True)
        log_file = cls._log_dir / "pc_care_pro.log"

        logger = logging.getLogger("PCCarePro")
        logger.setLevel(logging.DEBUG if verbose else logging.INFO)
        logger.handlers.clear()  # Prevent duplicate handlers on re-setup

        # Rotating File Handler: Max 5 MB per file, keep up to 3 backups
        file_handler = RotatingFileHandler(
            filename=str(log_file),
            maxBytes=5 * 1024 * 1024,
            backupCount=3,
            encoding="utf-8",
        )
        file_formatter = logging.Formatter(
            fmt="%(asctime)s [%(levelname)s] [%(name)s] %(message)s",
            datefmt="%Y-%m-%d %H:%M:%S",
        )
        file_handler.setFormatter(file_formatter)
        logger.addHandler(file_handler)

        # Console Handler (standard output for development)
        console_handler = logging.StreamHandler()
        console_handler.setFormatter(file_formatter)
        logger.addHandler(console_handler)

        cls._logger = logger
        logger.info("=== PC Care Pro Application Logger Initialized ===")
        return logger

    @classmethod
    def get_logger(cls) -> logging.Logger:
        """Retrieves existing logger or creates a default one if not yet initialized."""
        if cls._logger is None:
            return cls.setup()
        return cls._logger

    @classmethod
    def get_log_dir(cls) -> Path:
        """Returns the directory containing log files."""
        if cls._log_dir is None:
            cls.setup()
        assert cls._log_dir is not None
        return cls._log_dir
