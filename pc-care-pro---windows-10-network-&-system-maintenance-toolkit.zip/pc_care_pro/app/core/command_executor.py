"""
PC Care Pro - Command Execution Framework
=========================================
Provides safe, asynchronous and synchronous execution of native Windows commands
with output streaming, timeout guarantees, allowlist enforcement, and process cancellation.
"""

from dataclasses import dataclass
import os
import shutil
import subprocess
import threading
import time
from typing import Callable, Final, List, Optional

from app.constants import ALLOWED_SYSTEM_COMMANDS, DEFAULT_COMMAND_TIMEOUT_SEC
from app.core.exceptions import (
    CommandExecutionError,
    CommandNotFoundError,
    ExecutionTimeoutError,
    InvalidInputError,
)
from app.core.logger import AppLogger


@dataclass
class CommandResult:
    """
    Structured outcome of an executed Windows command.
    """
    command: List[str]
    exit_code: int
    stdout: str
    stderr: str
    duration_sec: float
    is_success: bool
    is_cancelled: bool = False
    timed_out: bool = False

    @property
    def full_output(self) -> str:
        """Combined standard output and error output."""
        if self.stderr:
            return f"{self.stdout}\n[STDERR]\n{self.stderr}".strip()
        return self.stdout


class CancellationToken:
    """Thread-safe flag to signal cancellation of a running background process."""
    def __init__(self) -> None:
        self._cancelled = threading.Event()

    def cancel(self) -> None:
        """Signals cancellation to the associated worker."""
        self._cancelled.set()

    @property
    def is_cancelled(self) -> bool:
        """Returns True if cancellation was requested."""
        return self._cancelled.is_set()


class CommandExecutor:
    """
    Executes native Windows CLI tools with defensive safeguards.
    """

    def __init__(self, enforce_allowlist: bool = True) -> None:
        self.enforce_allowlist = enforce_allowlist
        self.logger = AppLogger.get_logger()

    def _validate_command(self, cmd_args: List[str]) -> None:
        """Verifies that the command executable is in the approved allowlist."""
        if not cmd_args:
            raise InvalidInputError("Command argument list cannot be empty.", field_name="Command")

        binary_name = os.path.basename(cmd_args[0]).lower()
        if binary_name.endswith(".exe"):
            binary_name = binary_name[:-4]

        if self.enforce_allowlist and binary_name not in ALLOWED_SYSTEM_COMMANDS:
            raise InvalidInputError(
                f"Command '{binary_name}' is not in the approved system commands allowlist.",
                field_name="Command",
                input_value=cmd_args[0],
            )

    def execute_sync(
        self,
        cmd_args: List[str],
        timeout_sec: int = DEFAULT_COMMAND_TIMEOUT_SEC,
        cancellation_token: Optional[CancellationToken] = None,
    ) -> CommandResult:
        """
        Executes a Windows command synchronously with strict timeout.
        
        Args:
            cmd_args: List of command arguments, e.g. ['ping', '-n', '4', '8.8.8.8']
            timeout_sec: Maximum time allowed before process termination.
            cancellation_token: Optional token to request early termination.
            
        Returns:
            CommandResult with exit code, stdout, stderr, and timings.
        """
        self._validate_command(cmd_args)
        cmd_str = " ".join(cmd_args)
        self.logger.info(f"Executing: {cmd_str} (timeout: {timeout_sec}s)")

        start_time = time.time()
        try:
            # Check for executable existence
            executable_path = shutil.which(cmd_args[0])
            if not executable_path and not cmd_args[0].lower().endswith((".bat", ".cmd")):
                # On Windows, built-in commands might not always return a full path via which if in system32
                pass

            process = subprocess.Popen(
                cmd_args,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                text=True,
                shell=False,
                encoding="utf-8",
                errors="replace",
            )

            # Wait loop with cancellation check
            poll_interval = 0.1
            elapsed = 0.0

            while process.poll() is None:
                if cancellation_token and cancellation_token.is_cancelled:
                    process.terminate()
                    process.kill()
                    duration = time.time() - start_time
                    self.logger.warning(f"Command cancelled by user: {cmd_str}")
                    return CommandResult(
                        command=cmd_args,
                        exit_code=-1,
                        stdout="",
                        stderr="Operation cancelled by user.",
                        duration_sec=duration,
                        is_success=False,
                        is_cancelled=True,
                    )

                time.sleep(poll_interval)
                elapsed += poll_interval
                if elapsed >= timeout_sec:
                    process.kill()
                    duration = time.time() - start_time
                    self.logger.error(f"Command timed out: {cmd_str}")
                    return CommandResult(
                        command=cmd_args,
                        exit_code=124,
                        stdout="",
                        stderr=f"Command timed out after {timeout_sec}s.",
                        duration_sec=duration,
                        is_success=False,
                        timed_out=True,
                    )

            stdout, stderr = process.communicate()
            duration = time.time() - start_time

            result = CommandResult(
                command=cmd_args,
                exit_code=process.returncode,
                stdout=stdout.strip(),
                stderr=stderr.strip(),
                duration_sec=duration,
                is_success=(process.returncode == 0),
            )
            self.logger.info(f"Completed '{cmd_args[0]}' in {duration:.2f}s with code {process.returncode}")
            return result

        except FileNotFoundError:
            raise CommandNotFoundError(cmd_args[0])
        except Exception as e:
            duration = time.time() - start_time
            self.logger.error(f"Unexpected error running {cmd_str}: {str(e)}")
            raise CommandExecutionError(f"Failed to execute command: {str(e)}", command=cmd_str)

    def execute_async(
        self,
        cmd_args: List[str],
        on_chunk: Optional[Callable[[str], None]] = None,
        on_complete: Optional[Callable[[CommandResult], None]] = None,
        timeout_sec: int = DEFAULT_COMMAND_TIMEOUT_SEC,
        cancellation_token: Optional[CancellationToken] = None,
    ) -> threading.Thread:
        """
        Executes command in a background thread to prevent UI freezing,
        streaming stdout/stderr chunks as they arrive.
        """
        def _worker() -> None:
            self._validate_command(cmd_args)
            start_time = time.time()
            collected_stdout: List[str] = []
            collected_stderr: List[str] = []

            try:
                process = subprocess.Popen(
                    cmd_args,
                    stdout=subprocess.PIPE,
                    stderr=subprocess.PIPE,
                    text=True,
                    shell=False,
                    encoding="utf-8",
                    errors="replace",
                    bufsize=1,
                )

                def _read_stream(stream, accumulator, is_stderr: bool = False):
                    for line in iter(stream.readline, ""):
                        accumulator.append(line)
                        if on_chunk:
                            prefix = "[STDERR] " if is_stderr else ""
                            on_chunk(f"{prefix}{line}")
                    stream.close()

                stdout_thread = threading.Thread(target=_read_stream, args=(process.stdout, collected_stdout, False))
                stderr_thread = threading.Thread(target=_read_stream, args=(process.stderr, collected_stderr, True))
                stdout_thread.start()
                stderr_thread.start()

                elapsed = 0.0
                poll_interval = 0.1
                is_cancelled = False
                timed_out = False

                while process.poll() is None:
                    if cancellation_token and cancellation_token.is_cancelled:
                        process.terminate()
                        process.kill()
                        is_cancelled = True
                        break

                    time.sleep(poll_interval)
                    elapsed += poll_interval
                    if elapsed >= timeout_sec:
                        process.kill()
                        timed_out = True
                        break

                stdout_thread.join(timeout=2.0)
                stderr_thread.join(timeout=2.0)

                duration = time.time() - start_time
                exit_code = process.returncode if process.returncode is not None else -1

                res = CommandResult(
                    command=cmd_args,
                    exit_code=exit_code,
                    stdout="".join(collected_stdout).strip(),
                    stderr="".join(collected_stderr).strip(),
                    duration_sec=duration,
                    is_success=(exit_code == 0 and not is_cancelled and not timed_out),
                    is_cancelled=is_cancelled,
                    timed_out=timed_out,
                )

                if on_complete:
                    on_complete(res)

            except Exception as ex:
                duration = time.time() - start_time
                res = CommandResult(
                    command=cmd_args,
                    exit_code=-1,
                    stdout="".join(collected_stdout).strip(),
                    stderr=str(ex),
                    duration_sec=duration,
                    is_success=False,
                )
                if on_complete:
                    on_complete(res)

        thread = threading.Thread(target=_worker, daemon=True)
        thread.start()
        return thread
