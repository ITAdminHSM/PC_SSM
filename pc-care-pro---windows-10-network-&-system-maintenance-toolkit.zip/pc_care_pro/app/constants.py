"""
PC Care Pro - Constants & Configuration Keys
============================================
Defines application-wide constants, color palettes, allowed command binaries,
default ping parameters, and safety whitelists.
"""

from typing import Final, List, Set

# Application Metadata
APP_NAME: Final[str] = "PC Care Pro"
APP_SUBTITLE: Final[str] = "Windows Network & System Maintenance Toolkit"
APP_VERSION: Final[str] = "1.0.0"

# UI Color Palette (Dark Navy & Teal IT Utility Theme)
COLOR_BG_DARK: Final[str] = "#0A1128"       # Primary window background (deep navy)
COLOR_PANEL_DARK: Final[str] = "#101F3D"    # Sidebar and container panels
COLOR_CARD_DARK: Final[str] = "#1C2541"     # Card containers & frames
COLOR_ACCENT_TEAL: Final[str] = "#00B4D8"   # Primary brand accent (cyan/teal)
COLOR_ACCENT_HOVER: Final[str] = "#48CAE4"  # Accent button hover state
COLOR_TEXT_PRIMARY: Final[str] = "#F0F4F8"  # High-contrast readable foreground
COLOR_TEXT_MUTED: Final[str] = "#94A3B8"    # Subtitles and tertiary labels
COLOR_SUCCESS: Final[str] = "#10B981"       # Green status indicator
COLOR_WARNING: Final[str] = "#F59E0B"       # Yellow warning status
COLOR_DANGER: Final[str] = "#EF4444"        # Red error / destructive alert
COLOR_BORDER: Final[str] = "#1E293B"        # Subtle card boundary line

# Subprocess & Execution Limits
DEFAULT_COMMAND_TIMEOUT_SEC: Final[int] = 30
EXTENDED_COMMAND_TIMEOUT_SEC: Final[int] = 300  # For DISM/SFC scans
DEFAULT_PING_COUNT: Final[int] = 4
DEFAULT_PING_TIMEOUT_MS: Final[int] = 2000
DEFAULT_PING_TARGET: Final[str] = "8.8.8.8"

# Standard Allowed Commands (Strict allowlist to prevent arbitrary execution)
ALLOWED_SYSTEM_COMMANDS: Final[Set[str]] = {
    "ipconfig",
    "ping",
    "tracert",
    "pathping",
    "nslookup",
    "netstat",
    "arp",
    "route",
    "hostname",
    "getmac",
    "netsh",
    "sfc",
    "dism",
    "chkdsk",
}

# Standard Public Diagnostic Targets
DEFAULT_DNS_PRIMARY: Final[str] = "8.8.8.8"
DEFAULT_DNS_SECONDARY: Final[str] = "1.1.1.1"
DEFAULT_PING_DOMAIN: Final[str] = "google.com"

# Approved Directory Whitelist for PC Cleaner (Strictly enforced for safety)
# Any directory outside this list is immediately rejected by the cleaner module.
CLEANER_APPROVED_ROOT_NAMES: Final[List[str]] = [
    "TEMP",
    "TMP",
    "WINDOWS\\TEMP",
    "APPDATA\\LOCAL\\TEMP",
]
