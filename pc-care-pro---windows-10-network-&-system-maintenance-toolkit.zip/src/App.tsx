/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from 'react';
import {
  Activity,
  Wifi,
  Wrench,
  Trash2,
  Cpu,
  Terminal,
  FileText,
  Settings,
  Info,
  ShieldCheck,
  ShieldAlert,
  Globe,
  RefreshCw,
  HardDrive,
  Copy,
  Download,
  CheckCircle2,
  AlertTriangle,
  Radio,
  Play,
  RotateCcw,
  Zap,
  ChevronRight,
  Code2,
  Database,
  ExternalLink,
  Laptop
} from 'lucide-react';
import { PageId, ConsoleLogEntry, RepairAuditItem, CleanerTarget } from './types';
import { SYSTEM_INFO, INITIAL_SAVED_WIFI_PROFILES, VISIBLE_WIFI_NETWORKS } from './data/mockSystem';

export default function App() {
  const [activePage, setActivePage] = useState<PageId>('dashboard');
  const [isAdmin, setIsAdmin] = useState<boolean>(true);
  const [logs, setLogs] = useState<ConsoleLogEntry[]>([
    {
      id: 'init-1',
      timestamp: '00:38:00',
      command: 'system::bootstrap',
      status: 'success',
      stdout: '[*] PC Care Pro Engine Initialized.\n[*] Host: DESKTOP-WIN10PRO (Windows 10 Pro 22H2 Build 19045)\n[*] Subprocess sandbox active with shell=False argument enforcement.',
      durationSec: 0.04
    }
  ]);
  const [repairsHistory, setRepairsHistory] = useState<RepairAuditItem[]>([]);
  const [cleanerTargets, setCleanerTargets] = useState<CleanerTarget[]>([
    {
      id: 'user_temp',
      name: "User Temporary Files (%TEMP%)",
      path: 'C:\\Users\\Admin\\AppData\\Local\\Temp',
      fileCount: 1420,
      totalBytes: 2480000000,
      formattedSize: '2.48 GB',
      scanned: true,
      cleaned: false
    },
    {
      id: 'windows_temp',
      name: "Windows System Temp (C:\\Windows\\Temp)",
      path: 'C:\\Windows\\Temp',
      fileCount: 412,
      totalBytes: 890000000,
      formattedSize: '890.0 MB',
      scanned: true,
      cleaned: false
    }
  ]);
  const [isCleaning, setIsCleaning] = useState(false);
  const [cleanedSummary, setCleanedSummary] = useState<string | null>(null);

  // Ping Form State
  const [pingTarget, setPingTarget] = useState('8.8.8.8');
  const [pingCount, setPingCount] = useState('4');
  const [pingTimeout, setPingTimeout] = useState('2000');
  const [pingStats, setPingStats] = useState<{
    sent: number;
    received: number;
    lost: number;
    lossPct: number;
    minMs: number;
    maxMs: number;
    avgMs: number;
  } | null>(null);
  const [isRunningPing, setIsRunningPing] = useState(false);

  // Dynamic CPU & RAM simulation
  const [liveCpu, setLiveCpu] = useState(14.8);
  const [liveRam, setLiveRam] = useState(42.5);

  useEffect(() => {
    const interval = setInterval(() => {
      setLiveCpu(parseFloat((12 + Math.random() * 8).toFixed(1)));
      setLiveRam(parseFloat((41 + Math.random() * 3).toFixed(1)));
    }, 3000);
    return () => clearInterval(interval);
  }, []);

  const addLog = (command: string, stdout: string, status: 'success' | 'error' | 'warning' = 'success', stderr?: string, duration = 0.15) => {
    const d = new Date();
    const timeStr = d.toTimeString().split(' ')[0];
    const newEntry: ConsoleLogEntry = {
      id: Math.random().toString(36).substring(7),
      timestamp: timeStr,
      command,
      status,
      stdout,
      stderr,
      durationSec: duration
    };
    setLogs(prev => [newEntry, ...prev]);
  };

  const executePing = (target = pingTarget, count = parseInt(pingCount) || 4, timeout = parseInt(pingTimeout) || 2000) => {
    setIsRunningPing(true);
    addLog(`ping -n ${count} -w ${timeout} ${target}`, `Pinging ${target} with 32 bytes of data...`);
    
    setTimeout(() => {
      const min = Math.floor(11 + Math.random() * 4);
      const max = Math.floor(min + 2 + Math.random() * 5);
      const avg = Math.floor((min + max) / 2);
      const stats = {
        sent: count,
        received: count,
        lost: 0,
        lossPct: 0.0,
        minMs: min,
        maxMs: max,
        avgMs: avg
      };
      setPingStats(stats);
      setIsRunningPing(false);
      addLog(
        `ping ${target}`,
        `Reply from ${target}: bytes=32 time=${min}ms TTL=117\nReply from ${target}: bytes=32 time=${avg}ms TTL=117\n\nPing statistics for ${target}:\n    Packets: Sent = ${count}, Received = ${count}, Lost = 0 (0% loss)\nApproximate round trip times in milli-seconds:\n    Minimum = ${min}ms, Maximum = ${max}ms, Average = ${avg}ms`
      );
    }, 1200);
  };

  const handleRepairAction = (name: string, cmd: string, requiresReboot: boolean, explanation: string) => {
    if (!isAdmin && requiresReboot) {
      alert("This operation requires Windows Administrator elevation!");
      return;
    }
    const confirmed = window.confirm(`[CONFIRM OPERATION]\n\n${name}\n\n${explanation}\n\nProceed with execution?`);
    if (!confirmed) return;

    addLog(cmd, `Executing network stack repair: ${name}...`);
    setTimeout(() => {
      addLog(cmd, `Command completed successfully: 0 errors reported.`);
      const item: RepairAuditItem = {
        id: Math.random().toString(),
        timestamp: new Date().toLocaleTimeString(),
        name,
        status: 'success',
        summary: 'Completed with exit code 0.',
        details: `Dispatched '${cmd}'. ${requiresReboot ? 'Restart recommended.' : 'Operational.'}`,
        requiresReboot
      };
      setRepairsHistory(prev => [item, ...prev]);
    }, 800);
  };

  const handleCleanFiles = () => {
    const confirmed = window.confirm("Are you sure you want to clean selected temporary caches?\n\nFiles in Documents, Downloads, Desktop and Personal folders are safely excluded.");
    if (!confirmed) return;

    setIsCleaning(true);
    addLog('cleaner::execute', 'Starting safe temporary file removal across %TEMP% and C:\\Windows\\Temp...');
    setTimeout(() => {
      setIsCleaning(false);
      setCleanedSummary("Cleanup finished: 1,832 files removed (3.37 GB reclaimed). 14 in-use files safely skipped.");
      setCleanerTargets(prev => prev.map(t => ({ ...t, fileCount: 0, totalBytes: 0, formattedSize: '0.0 MB', cleaned: true })));
      addLog('cleaner::summary', 'Reclaimed 3.37 GB of disk space. Zero personal or system files modified.');
    }, 1500);
  };

  return (
    <div className="flex h-screen w-screen overflow-hidden bg-[#0A1128] text-slate-100 font-sans selection:bg-[#00B4D8]/30">
      
      {/* LEFT SIDEBAR NAVIGATION */}
      <aside className="w-64 bg-[#101F3D] border-r border-[#1E293B] flex flex-col justify-between shrink-0 select-none">
        <div>
          {/* Brand Header */}
          <div className="p-4 border-b border-[#1E293B]">
            <div className="flex items-center gap-2.5">
              <div className="w-9 h-9 rounded-lg bg-gradient-to-tr from-[#0077B6] to-[#00B4D8] flex items-center justify-center shadow-lg shadow-[#00B4D8]/20">
                <Laptop className="w-5 h-5 text-white" />
              </div>
              <div>
                <h1 className="text-base font-bold tracking-tight text-white flex items-center gap-1.5">
                  PC Care Pro
                  <span className="text-[10px] uppercase font-semibold px-1.5 py-0.5 rounded bg-[#00B4D8]/20 text-[#48CAE4]">v1.0</span>
                </h1>
                <p className="text-[11px] text-slate-400">Windows Network &amp; System Suite</p>
              </div>
            </div>

            {/* Admin Badge Toggle */}
            <div 
              onClick={() => setIsAdmin(!isAdmin)}
              className={`mt-3 px-2.5 py-1.5 rounded-md flex items-center justify-between text-xs cursor-pointer transition-colors ${
                isAdmin 
                  ? 'bg-emerald-950/60 border border-emerald-500/30 text-emerald-300' 
                  : 'bg-slate-800/80 border border-slate-700 text-slate-400'
              }`}
              title="Click to toggle simulated Administrator privilege level"
            >
              <div className="flex items-center gap-1.5">
                {isAdmin ? <ShieldCheck className="w-3.5 h-3.5 text-emerald-400" /> : <ShieldAlert className="w-3.5 h-3.5 text-slate-400" />}
                <span className="font-semibold text-[11px]">{isAdmin ? 'ADMINISTRATOR' : 'STANDARD USER'}</span>
              </div>
              <span className="text-[10px] text-slate-400 opacity-70">UAC</span>
            </div>
          </div>

          {/* Navigation Links */}
          <nav className="p-2 space-y-0.5 overflow-y-auto max-h-[calc(100vh-230px)]">
            {[
              { id: 'dashboard', label: 'Dashboard', icon: Activity },
              { id: 'diagnostics', label: 'Internet Diagnostics', icon: Globe },
              { id: 'wifi', label: 'Wi-Fi Manager', icon: Wifi },
              { id: 'repair', label: 'Network Repair Centre', icon: Wrench },
              { id: 'cleaner', label: 'PC Cleaner', icon: Trash2 },
              { id: 'windows_tools', label: 'Windows Repair Tools', icon: HardDrive },
              { id: 'system_info', label: 'System Information', icon: Cpu },
              { id: 'console', label: 'Command Console', icon: Terminal },
              { id: 'reports', label: 'Logs & Reports', icon: FileText },
              { id: 'python_suite', label: 'Python Architecture & Tests', icon: Code2, highlight: true },
              { id: 'settings', label: 'Settings', icon: Settings },
              { id: 'about', label: 'About PC Care Pro', icon: Info },
            ].map(item => {
              const Icon = item.icon;
              const isActive = activePage === item.id;
              return (
                <button
                  key={item.id}
                  onClick={() => setActivePage(item.id as PageId)}
                  className={`w-full flex items-center gap-2.5 px-3 py-2 rounded-md text-xs font-medium transition-all ${
                    isActive
                      ? 'bg-[#00B4D8] text-[#0A1128] font-bold shadow-md shadow-[#00B4D8]/20'
                      : item.highlight
                      ? 'text-[#48CAE4] hover:bg-[#1C2541] hover:text-white'
                      : 'text-slate-300 hover:bg-[#1C2541] hover:text-white'
                  }`}
                >
                  <Icon className={`w-4 h-4 ${isActive ? 'text-[#0A1128]' : item.highlight ? 'text-[#48CAE4]' : 'text-slate-400'}`} />
                  <span className="truncate">{item.label}</span>
                </button>
              );
            })}
          </nav>
        </div>

        {/* Offline Guarantee Footer */}
        <div className="p-3 border-t border-[#1E293B] text-[11px] text-slate-400 bg-[#0D182E]/50">
          <div className="flex items-center gap-1.5 text-emerald-400 font-medium">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            100% Offline-First
          </div>
          <p className="text-[10px] text-slate-500 mt-0.5">Zero Telemetry • Zero Cloud APIs</p>
        </div>
      </aside>

      {/* MAIN CONTENT AREA */}
      <main className="flex-1 flex flex-col overflow-hidden bg-[#0A1128]">
        
        {/* TOP STATUS BAR */}
        <header className="h-12 border-b border-[#1E293B] bg-[#101F3D]/80 backdrop-blur px-6 flex items-center justify-between shrink-0">
          <div className="flex items-center gap-3">
            <span className="text-xs text-slate-400">Host:</span>
            <span className="text-xs font-mono font-bold text-white bg-[#1C2541] px-2 py-0.5 rounded border border-[#1E293B]">
              {SYSTEM_INFO.computerName}
            </span>
            <span className="text-xs text-slate-500">|</span>
            <span className="text-xs text-slate-400">Gateway:</span>
            <span className="text-xs font-mono text-[#48CAE4]">{SYSTEM_INFO.defaultGateway}</span>
            <span className="text-xs text-slate-500">|</span>
            <span className="text-xs text-slate-400">IP:</span>
            <span className="text-xs font-mono text-emerald-400">{SYSTEM_INFO.localIpv4}</span>
          </div>

          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                executePing('8.8.8.8', 2, 1000);
                addLog('ping 8.8.8.8', 'Quick ping executed from header.');
              }}
              className="flex items-center gap-1.5 text-xs bg-[#1C2541] hover:bg-[#233055] text-slate-200 px-2.5 py-1 rounded border border-[#1E293B] transition"
            >
              <RefreshCw className="w-3 h-3 text-[#48CAE4]" />
              Quick Check
            </button>
            <button
              onClick={() => setActivePage('console')}
              className="flex items-center gap-1.5 text-xs bg-[#00B4D8]/10 hover:bg-[#00B4D8]/20 text-[#48CAE4] border border-[#00B4D8]/30 px-2.5 py-1 rounded transition"
            >
              <Terminal className="w-3 h-3" />
              Console ({logs.length})
            </button>
          </div>
        </header>

        {/* VIEW CONTAINER */}
        <div className="flex-1 overflow-y-auto p-6 space-y-6">

          {/* PAGE 1: DASHBOARD */}
          {activePage === 'dashboard' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">System &amp; Network Dashboard</h2>
                <p className="text-xs text-slate-400">Live hardware telemetry and networking status</p>
              </div>

              {/* Status Grid Cards */}
              <div className="grid grid-cols-4 gap-4">
                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span>Internet Link</span>
                    <Globe className="w-4 h-4 text-emerald-400" />
                  </div>
                  <div className="text-lg font-bold text-emerald-400 flex items-center gap-2">
                    <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span>
                    Connected
                  </div>
                  <div className="text-[11px] text-slate-400 mt-1 font-mono">RTT: 12ms (Primary DNS OK)</div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span>Wi-Fi Network</span>
                    <Wifi className="w-4 h-4 text-[#48CAE4]" />
                  </div>
                  <div className="text-lg font-bold text-white truncate">{SYSTEM_INFO.activeSsid}</div>
                  <div className="text-[11px] text-[#48CAE4] mt-1 font-mono">Signal: {SYSTEM_INFO.wifiSignal}% (Wi-Fi 6)</div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span>Processor Load</span>
                    <Cpu className="w-4 h-4 text-sky-400" />
                  </div>
                  <div className="text-lg font-bold text-white">{liveCpu}%</div>
                  <div className="w-full bg-[#1C2541] h-1.5 rounded-full mt-2 overflow-hidden">
                    <div className="bg-[#00B4D8] h-full transition-all duration-500" style={{ width: `${liveCpu}%` }}></div>
                  </div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <div className="flex items-center justify-between text-xs text-slate-400 mb-2">
                    <span>RAM Utilization</span>
                    <Activity className="w-4 h-4 text-purple-400" />
                  </div>
                  <div className="text-lg font-bold text-white">{liveRam}%</div>
                  <div className="w-full bg-[#1C2541] h-1.5 rounded-full mt-2 overflow-hidden">
                    <div className="bg-purple-500 h-full transition-all duration-500" style={{ width: `${liveRam}%` }}></div>
                  </div>
                </div>
              </div>

              {/* Second Row: System Details */}
              <div className="grid grid-cols-3 gap-4">
                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">Operating System</h3>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between"><span className="text-slate-400">Edition:</span><span className="font-semibold text-white">{SYSTEM_INFO.osName}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">Version / Build:</span><span className="font-mono text-[#48CAE4]">{SYSTEM_INFO.osVersion} ({SYSTEM_INFO.osBuild})</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">System Uptime:</span><span className="text-slate-300">{SYSTEM_INFO.uptime}</span></div>
                  </div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">Storage Capacity (C:)</h3>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between"><span className="text-slate-400">Used Space:</span><span className="text-white font-mono">{SYSTEM_INFO.partitions[0].usedGb} GB / {SYSTEM_INFO.partitions[0].totalGb} GB</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">Free Space:</span><span className="text-emerald-400 font-mono font-bold">{SYSTEM_INFO.partitions[0].freeGb} GB Free</span></div>
                    <div className="w-full bg-[#1C2541] h-2 rounded-full mt-2 overflow-hidden">
                      <div className="bg-amber-500 h-full" style={{ width: `${SYSTEM_INFO.partitions[0].percentUsed}%` }}></div>
                    </div>
                  </div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                  <h3 className="text-xs font-semibold uppercase tracking-wider text-slate-400 mb-3">Network Bindings</h3>
                  <div className="space-y-1.5 text-xs">
                    <div className="flex justify-between"><span className="text-slate-400">Subnet Mask:</span><span className="font-mono text-slate-300">{SYSTEM_INFO.subnetMask}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">DNS Servers:</span><span className="font-mono text-[#48CAE4]">{SYSTEM_INFO.primaryDns}, {SYSTEM_INFO.secondaryDns}</span></div>
                    <div className="flex justify-between"><span className="text-slate-400">MAC Address:</span><span className="font-mono text-slate-300">{SYSTEM_INFO.macAddress}</span></div>
                  </div>
                </div>
              </div>

              {/* 7 Functional Quick-Action Buttons */}
              <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl">
                <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-amber-400" />
                  Quick Maintenance Actions
                </h3>
                <div className="grid grid-cols-4 gap-3">
                  <button
                    onClick={() => {
                      executePing('8.8.8.8', 4, 2000);
                      setActivePage('diagnostics');
                    }}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Test Internet</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Ping public DNS resolvers</div>
                  </button>

                  <button
                    onClick={() => {
                      addLog('ipconfig /flushdns', 'Successfully flushed the DNS Resolver Cache.');
                      alert('DNS Resolver cache flushed successfully!');
                    }}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Flush DNS</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Clear local resolver cache</div>
                  </button>

                  <button
                    onClick={() => {
                      addLog('ipconfig /renew', 'DHCP configuration renewed: IPv4 assigned 192.168.1.145');
                      alert('DHCP IP lease refreshed!');
                    }}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Renew IP</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Re-query DHCP server</div>
                  </button>

                  <button
                    onClick={() => {
                      executePing('google.com', 4, 2000);
                      setActivePage('diagnostics');
                    }}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Ping Google</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Verify DNS &amp; web route</div>
                  </button>

                  <button
                    onClick={() => setActivePage('wifi')}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Wi-Fi Manager</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Scan visible networks</div>
                  </button>

                  <button
                    onClick={() => setActivePage('cleaner')}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Clean Temp Files</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Preview &amp; clean %TEMP%</div>
                  </button>

                  <button
                    onClick={() => setActivePage('console')}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Open Console</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Live execution stdout/stderr</div>
                  </button>

                  <button
                    onClick={() => setActivePage('repair')}
                    className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded-lg border border-[#1E293B] text-left transition group"
                  >
                    <div className="text-xs font-bold text-white group-hover:text-[#48CAE4]">Repair Centre</div>
                    <div className="text-[11px] text-slate-400 mt-0.5">Winsock &amp; TCP/IP stack</div>
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PAGE 2: INTERNET DIAGNOSTICS */}
          {activePage === 'diagnostics' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">Internet &amp; Network Diagnostics</h2>
                <p className="text-xs text-slate-400">Execute Windows networking utilities with custom parameters and parsed metrics</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                {/* Left: Ping & IP Configuration Workbenches */}
                <div className="space-y-4">
                  {/* Custom Ping */}
                  <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                    <h3 className="text-sm font-bold text-white mb-3 flex items-center gap-2">
                      <Radio className="w-4 h-4 text-[#00B4D8]" />
                      Custom Ping Utility
                    </h3>
                    <div className="space-y-3">
                      <div>
                        <label className="text-[11px] text-slate-400 block mb-1">Target Hostname or IP</label>
                        <input
                          type="text"
                          value={pingTarget}
                          onChange={e => setPingTarget(e.target.value)}
                          className="w-full bg-[#1C2541] border border-[#1E293B] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00B4D8] font-mono"
                          placeholder="e.g. google.com or 8.8.8.8"
                        />
                      </div>
                      <div className="grid grid-cols-2 gap-3">
                        <div>
                          <label className="text-[11px] text-slate-400 block mb-1">Packets (1-100)</label>
                          <input
                            type="number"
                            value={pingCount}
                            onChange={e => setPingCount(e.target.value)}
                            className="w-full bg-[#1C2541] border border-[#1E293B] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00B4D8] font-mono"
                          />
                        </div>
                        <div>
                          <label className="text-[11px] text-slate-400 block mb-1">Timeout (ms)</label>
                          <input
                            type="number"
                            value={pingTimeout}
                            onChange={e => setPingTimeout(e.target.value)}
                            className="w-full bg-[#1C2541] border border-[#1E293B] rounded px-3 py-1.5 text-xs text-white focus:outline-none focus:border-[#00B4D8] font-mono"
                          />
                        </div>
                      </div>

                      <div className="flex gap-2 pt-1">
                        <button
                          disabled={isRunningPing}
                          onClick={() => executePing()}
                          className="flex-1 bg-[#00B4D8] hover:bg-[#48CAE4] text-[#0A1128] font-bold py-2 rounded text-xs transition flex items-center justify-center gap-1.5"
                        >
                          <Play className="w-3.5 h-3.5 fill-current" />
                          {isRunningPing ? 'Pinging...' : 'Execute Ping'}
                        </button>
                        <button
                          onClick={() => executePing('1.1.1.1')}
                          className="px-3 bg-[#1C2541] hover:bg-[#253256] text-xs text-slate-200 rounded border border-[#1E293B]"
                        >
                          Ping Cloudflare (1.1.1.1)
                        </button>
                      </div>
                    </div>

                    {/* Ping Parsed Results */}
                    {pingStats && (
                      <div className="mt-4 p-3 bg-[#1C2541]/70 border border-[#1E293B] rounded-lg">
                        <div className="text-[11px] font-bold text-slate-300 uppercase mb-1">Parsed Performance Metrics</div>
                        <div className="grid grid-cols-4 gap-2 text-center text-xs">
                          <div className="bg-[#101F3D] p-1.5 rounded">
                            <span className="text-[10px] text-slate-400 block">Packet Loss</span>
                            <span className="font-bold text-emerald-400">{pingStats.lossPct}%</span>
                          </div>
                          <div className="bg-[#101F3D] p-1.5 rounded">
                            <span className="text-[10px] text-slate-400 block">Minimum</span>
                            <span className="font-bold text-white">{pingStats.minMs}ms</span>
                          </div>
                          <div className="bg-[#101F3D] p-1.5 rounded">
                            <span className="text-[10px] text-slate-400 block">Average</span>
                            <span className="font-bold text-[#48CAE4]">{pingStats.avgMs}ms</span>
                          </div>
                          <div className="bg-[#101F3D] p-1.5 rounded">
                            <span className="text-[10px] text-slate-400 block">Maximum</span>
                            <span className="font-bold text-white">{pingStats.maxMs}ms</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>

                  {/* IP Configuration Buttons */}
                  <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                    <h3 className="text-sm font-bold text-white mb-3">IP Configuration Commands (ipconfig)</h3>
                    <div className="grid grid-cols-2 gap-2 text-xs">
                      {[
                        { label: 'ipconfig', cmd: 'ipconfig', out: 'Windows IP Configuration\n\nWireless LAN adapter Wi-Fi:\n   IPv4 Address. . . : 192.168.1.145\n   Subnet Mask . . . : 255.255.255.0\n   Default Gateway . : 192.168.1.1' },
                        { label: 'ipconfig /all', cmd: 'ipconfig /all', out: 'Windows IP Configuration\n\n   Host Name . . . : DESKTOP-WIN10PRO\n   Primary Dns Suffix  . . . . . . . :\n   Node Type . . . . . . . . . . . . : Hybrid\n   IP Routing Enabled. . . . . . . . : No\n   WINS Proxy Enabled. . . . . . . . : No\n\nWireless LAN adapter Wi-Fi:\n   Description . . . : Intel(R) Wi-Fi 6 AX200 160MHz\n   Physical Address. : 3C-7C-3F-9B-A1-22\n   DHCP Enabled. . . : Yes\n   Autoconfiguration Enabled . : Yes\n   IPv4 Address. . . : 192.168.1.145(Preferred)\n   DNS Servers . . . : 8.8.8.8\n                       1.1.1.1' },
                        { label: 'ipconfig /displaydns', cmd: 'ipconfig /displaydns', out: 'Windows IP Configuration\n\n    dns.google\n    ----------------------------------------\n    Record Name . . . . . : dns.google\n    Record Type . . . . . : 1\n    Time To Live  . . . . : 240\n    Data Length . . . . . : 4\n    Section . . . . . . . : Answer\n    A (Host) Record  . . : 8.8.8.8' },
                        { label: 'ipconfig /flushdns', cmd: 'ipconfig /flushdns', out: 'Windows IP Configuration\n\nSuccessfully flushed the DNS Resolver Cache.' },
                        { label: 'ipconfig /release', cmd: 'ipconfig /release', out: 'Windows IP Configuration\n\nNo operation can be performed on Ethernet while it has its media disconnected.\nWireless LAN adapter Wi-Fi IP address released.' },
                        { label: 'ipconfig /renew', cmd: 'ipconfig /renew', out: 'Windows IP Configuration\n\nWireless LAN adapter Wi-Fi:\n   Connection-specific DNS Suffix  . : local\n   IPv4 Address. . . : 192.168.1.145\n   Default Gateway . : 192.168.1.1' },
                      ].map(item => (
                        <button
                          key={item.label}
                          onClick={() => addLog(item.cmd, item.out)}
                          className="p-2 bg-[#1C2541] hover:bg-[#253256] text-slate-200 rounded text-left font-mono text-[11px] border border-[#1E293B] transition"
                        >
                          &gt; {item.label}
                        </button>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Right: Networking Diagnostics Output */}
                <div className="space-y-4">
                  <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl">
                    <h3 className="text-sm font-bold text-white mb-3">Path, Route &amp; Socket Inspectors</h3>
                    <div className="grid grid-cols-2 gap-2 text-xs mb-4">
                      {[
                        { label: 'nslookup google.com', cmd: 'nslookup google.com', out: 'Server:  dns.google\nAddress:  8.8.8.8\n\nNon-authoritative answer:\nName:    google.com\nAddresses:  142.250.190.46' },
                        { label: 'tracert 8.8.8.8', cmd: 'tracert 8.8.8.8', out: 'Tracing route to dns.google [8.8.8.8] over a maximum of 30 hops:\n  1    <1 ms    <1 ms    <1 ms  192.168.1.1\n  2     8 ms     7 ms     7 ms  10.24.0.1\n  3    12 ms    11 ms    12 ms  dns.google [8.8.8.8]\n\nTrace complete.' },
                        { label: 'netstat -ano', cmd: 'netstat -ano', out: 'Active Connections\n  Proto  Local Address          Foreign Address        State           PID\n  TCP    0.0.0.0:135            0.0.0.0:0              LISTENING       892\n  TCP    192.168.1.145:51240    142.250.190.46:443     ESTABLISHED     12404\n  UDP    0.0.0.0:5353           *:*                                    2400' },
                        { label: 'arp -a', cmd: 'arp -a', out: 'Interface: 192.168.1.145 --- 0x12\n  Internet Address      Physical Address      Type\n  192.168.1.1           e0-28-6d-4b-12-aa     dynamic\n  192.168.1.255         ff-ff-ff-ff-ff-ff     static' },
                        { label: 'route print', cmd: 'route print', out: 'IPv4 Route Table\nActive Routes:\nNetwork Destination        Netmask          Gateway       Interface  Metric\n          0.0.0.0          0.0.0.0      192.168.1.1   192.168.1.145      35' },
                        { label: 'getmac', cmd: 'getmac', out: 'Physical Address    Transport Name\n=================== ====================================================\n3C-7C-3F-9B-A1-22   \\Device\\Tcpip_{4A2B3C4D-5E6F-7A8B-9C0D-1E2F3A4B5C6D}' }
                      ].map(item => (
                        <button
                          key={item.label}
                          onClick={() => addLog(item.cmd, item.out)}
                          className="p-2 bg-[#1C2541] hover:bg-[#253256] text-slate-200 rounded text-left font-mono text-[11px] border border-[#1E293B] transition"
                        >
                          &gt; {item.label}
                        </button>
                      ))}
                    </div>
                  </div>

                  {/* Terminal display for latest diagnostic */}
                  <div className="bg-[#101F3D] border border-[#1E293B] p-4 rounded-xl flex flex-col h-[280px]">
                    <div className="flex items-center justify-between pb-2 border-b border-[#1E293B] mb-2">
                      <span className="text-xs font-bold text-white flex items-center gap-1.5">
                        <Terminal className="w-3.5 h-3.5 text-[#48CAE4]" />
                        Latest Command Output
                      </span>
                      <button
                        onClick={() => {
                          const text = logs[0] ? logs[0].stdout : '';
                          navigator.clipboard.writeText(text);
                          alert('Copied output to clipboard!');
                        }}
                        className="text-[11px] text-[#48CAE4] hover:underline"
                      >
                        Copy Output
                      </button>
                    </div>
                    <pre className="flex-1 bg-[#0A1128] p-3 rounded font-mono text-[11px] text-sky-300 overflow-y-auto whitespace-pre-wrap">
                      {logs[0] ? `> ${logs[0].command}\n\n${logs[0].stdout}` : 'No command executed yet.'}
                    </pre>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PAGE 3: WI-FI MANAGER */}
          {activePage === 'wifi' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">Wi-Fi &amp; Wireless Adapter Manager</h2>
                <p className="text-xs text-slate-400">Wireless interface status, visible SSIDs, and saved profiles (passwords never exposed)</p>
              </div>

              <div className="grid grid-cols-3 gap-6">
                {/* Active Interface Card */}
                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <Radio className="w-4 h-4 text-[#00B4D8]" />
                    Wireless Hardware Adapter
                  </h3>
                  <div className="space-y-2 text-xs">
                    <div>
                      <span className="text-slate-400 block text-[11px]">Hardware Model:</span>
                      <span className="text-white font-semibold">{SYSTEM_INFO.adapterName}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Interface Status:</span>
                      <span className="text-emerald-400 font-bold flex items-center gap-1">
                        <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
                        Connected &amp; Operational
                      </span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Associated SSID:</span>
                      <span className="text-white font-mono">{SYSTEM_INFO.activeSsid}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Link Quality &amp; Band:</span>
                      <span className="text-[#48CAE4] font-semibold">{SYSTEM_INFO.wifiSignal}% Signal • {SYSTEM_INFO.wifiRadio}</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Tx/Rx Data Rates:</span>
                      <span className="text-slate-300 font-mono">{SYSTEM_INFO.txRateMbps} Mbps / {SYSTEM_INFO.rxRateMbps} Mbps</span>
                    </div>
                    <div>
                      <span className="text-slate-400 block text-[11px]">Security Protocol:</span>
                      <span className="text-slate-300 font-mono">{SYSTEM_INFO.wifiSecurity}</span>
                    </div>
                  </div>

                  {/* Adapter Controls */}
                  <div className="pt-3 border-t border-[#1E293B] space-y-2">
                    <button
                      onClick={() => {
                        const confirmed = window.confirm("Restarting the wireless adapter will temporarily disrupt active internet sessions for 3-5 seconds.\n\nProceed?");
                        if (confirmed) {
                          addLog('netsh interface set interface "Wi-Fi" disable', 'Adapter disabled.');
                          setTimeout(() => {
                            addLog('netsh interface set interface "Wi-Fi" enable', 'Adapter enabled.');
                            alert("Wireless adapter restarted successfully.");
                          }, 1000);
                        }
                      }}
                      className="w-full py-2 bg-amber-600 hover:bg-amber-500 text-white rounded text-xs font-semibold transition"
                    >
                      Restart Wireless Adapter
                    </button>
                    <button
                      onClick={() => addLog('netsh wlan show interfaces', 'Wireless interface status verified.')}
                      className="w-full py-2 bg-[#1C2541] hover:bg-[#253256] text-slate-200 rounded text-xs transition"
                    >
                      Refresh Adapter State
                    </button>
                  </div>
                </div>

                {/* Visible Networks */}
                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                  <div className="flex items-center justify-between">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <Wifi className="w-4 h-4 text-[#48CAE4]" />
                      Visible Wi-Fi Networks ({VISIBLE_WIFI_NETWORKS.length})
                    </h3>
                    <button 
                      onClick={() => addLog('netsh wlan show networks mode=bssid', 'Network scan completed: 5 APs detected.')}
                      className="text-[11px] text-[#48CAE4] hover:underline"
                    >
                      Rescan
                    </button>
                  </div>

                  <div className="space-y-2 max-h-[380px] overflow-y-auto">
                    {VISIBLE_WIFI_NETWORKS.map(net => (
                      <div key={net.ssid} className="p-3 bg-[#1C2541] rounded-lg border border-[#1E293B] flex items-center justify-between text-xs">
                        <div>
                          <div className="font-bold text-white flex items-center gap-1.5">
                            {net.ssid}
                            {net.ssid === SYSTEM_INFO.activeSsid && (
                              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-1 rounded">CONNECTED</span>
                            )}
                          </div>
                          <div className="text-[10px] text-slate-400 mt-0.5">{net.band} (Ch {net.channel}) • {net.auth}</div>
                        </div>
                        <div className="text-right">
                          <span className="font-mono font-bold text-[#48CAE4]">{net.signal}%</span>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* Saved Profiles */}
                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <FileText className="w-4 h-4 text-purple-400" />
                    Saved Wi-Fi Profiles
                  </h3>
                  <p className="text-[11px] text-slate-400">
                    Profiles registered in Windows WLAN service. Plaintext passwords are strictly protected and never displayed.
                  </p>

                  <div className="space-y-2">
                    {INITIAL_SAVED_WIFI_PROFILES.map(prof => (
                      <div key={prof} className="p-2.5 bg-[#1C2541] rounded border border-[#1E293B] flex items-center justify-between text-xs">
                        <span className="font-mono text-slate-200">{prof}</span>
                        <button
                          onClick={() => {
                            addLog(`netsh wlan connect name="${prof}" interface="Wi-Fi"`, `Connection request sent for profile '${prof}'.`);
                            alert(`Reconnecting to saved profile: ${prof}`);
                          }}
                          className="text-[10px] bg-[#00B4D8]/10 hover:bg-[#00B4D8]/20 text-[#48CAE4] border border-[#00B4D8]/30 px-2 py-0.5 rounded"
                        >
                          Connect
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PAGE 4: NETWORK REPAIR CENTRE */}
          {activePage === 'repair' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">Network Repair Centre</h2>
                <p className="text-xs text-slate-400">Step-by-step troubleshooting, catalog re-initialization, and firewall reset</p>
              </div>

              <div className="grid grid-cols-2 gap-6">
                {/* Repair Operations List */}
                <div className="space-y-3">
                  {[
                    {
                      name: '1. Flush DNS Resolver Cache',
                      cmd: 'ipconfig /flushdns',
                      desc: 'Clears stale or poisoned DNS mappings. Safe, non-elevated, no restart required.',
                      isElevated: false,
                      requiresReboot: false,
                      btnColor: 'bg-[#00B4D8] hover:bg-[#48CAE4] text-[#0A1128]'
                    },
                    {
                      name: '2. Release & Renew DHCP Configuration',
                      cmd: 'ipconfig /release && ipconfig /renew',
                      desc: 'Drops local IP assignment and queries DHCP server for new routing lease.',
                      isElevated: false,
                      requiresReboot: false,
                      btnColor: 'bg-[#00B4D8] hover:bg-[#48CAE4] text-[#0A1128]'
                    },
                    {
                      name: '3. Reset Winsock Catalog',
                      cmd: 'netsh winsock reset',
                      desc: 'Restores Windows socket API providers to default clean state. Fixes corrupted LSPs.',
                      isElevated: true,
                      requiresReboot: true,
                      btnColor: 'bg-amber-600 hover:bg-amber-500 text-white'
                    },
                    {
                      name: '4. Reset TCP/IP Stack (netsh int ip reset)',
                      cmd: 'netsh int ip reset C:\\Windows\\Temp\\tcpip_reset.log',
                      desc: 'Rewrites core IP registry configurations. Highly effective for persistent connection failure.',
                      isElevated: true,
                      requiresReboot: true,
                      btnColor: 'bg-amber-600 hover:bg-amber-500 text-white'
                    },
                    {
                      name: '5. Reset Windows Defender Firewall',
                      cmd: 'netsh advfirewall reset',
                      desc: 'Restores firewall policies to Windows default. WARNING: Custom port forwards and rules are removed!',
                      isElevated: true,
                      requiresReboot: false,
                      btnColor: 'bg-rose-600 hover:bg-rose-500 text-white'
                    },
                    {
                      name: '6. Windows Network Diagnostics Wizard',
                      cmd: 'msdt.exe /id NetworkDiagnosticsNetworkAdapter',
                      desc: 'Launches native Windows Network Diagnostics automated troubleshooting assistant.',
                      isElevated: false,
                      requiresReboot: false,
                      btnColor: 'bg-[#1C2541] hover:bg-[#253256] text-slate-200 border border-[#1E293B]'
                    }
                  ].map(op => (
                    <div key={op.name} className="p-4 bg-[#101F3D] border border-[#1E293B] rounded-xl flex items-center justify-between">
                      <div className="space-y-1 pr-4">
                        <div className="flex items-center gap-2">
                          <h4 className="text-xs font-bold text-white">{op.name}</h4>
                          {op.isElevated && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-amber-500/20 text-amber-300 border border-amber-500/30">
                              ADMIN REQUIRED
                            </span>
                          )}
                          {op.requiresReboot && (
                            <span className="text-[9px] font-bold px-1.5 py-0.5 rounded bg-rose-500/20 text-rose-300">
                              RESTART NEEDED
                            </span>
                          )}
                        </div>
                        <p className="text-[11px] text-slate-400">{op.desc}</p>
                      </div>

                      <button
                        onClick={() => handleRepairAction(op.name, op.cmd, op.requiresReboot, op.desc)}
                        className={`px-3 py-1.5 rounded text-xs font-bold shrink-0 transition ${op.btnColor}`}
                      >
                        Execute
                      </button>
                    </div>
                  ))}
                </div>

                {/* Repair Session Audit History */}
                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl flex flex-col h-[520px]">
                  <div className="flex items-center justify-between pb-3 border-b border-[#1E293B] mb-3">
                    <h3 className="text-sm font-bold text-white flex items-center gap-2">
                      <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                      Session Repair Audit Log ({repairsHistory.length})
                    </h3>
                    <button
                      onClick={() => setRepairsHistory([])}
                      className="text-[11px] text-slate-400 hover:text-white"
                    >
                      Clear History
                    </button>
                  </div>

                  <div className="flex-1 overflow-y-auto space-y-3 font-mono text-[11px]">
                    {repairsHistory.length === 0 ? (
                      <div className="text-slate-500 italic p-4 text-center">
                        No repair operations dispatched in this session yet.
                      </div>
                    ) : (
                      repairsHistory.map(item => (
                        <div key={item.id} className="p-3 bg-[#0A1128] rounded border border-[#1E293B] space-y-1">
                          <div className="flex items-center justify-between text-xs">
                            <span className="font-bold text-emerald-400">{item.name}</span>
                            <span className="text-slate-400">{item.timestamp}</span>
                          </div>
                          <div className="text-slate-300">{item.summary}</div>
                          <div className="text-slate-500 text-[10px]">{item.details}</div>
                        </div>
                      ))
                    )}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PAGE 5: PC CLEANER */}
          {activePage === 'cleaner' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">PC Cleaner &amp; Temporary File Reclaimer</h2>
                <p className="text-xs text-slate-400">Safely scan and clean %TEMP% and system caches with zero risk to personal documents</p>
              </div>

              {/* Safety Banner */}
              <div className="p-4 bg-emerald-950/30 border border-emerald-500/30 rounded-xl flex items-start gap-3 text-xs text-emerald-300">
                <ShieldCheck className="w-5 h-5 text-emerald-400 shrink-0 mt-0.5" />
                <div>
                  <h4 className="font-bold text-emerald-200">Defensive Protection Guarantee</h4>
                  <p className="text-[11px] text-emerald-300/80 mt-0.5">
                    This module strictly operates inside whitelisted temporary scratch directories. It will NEVER scan, touch, or modify User Documents, Downloads, Desktop files, personal photos, or browser profiles. In-use or locked files are safely bypassed.
                  </p>
                </div>
              </div>

              {/* Cleaner Summary Card */}
              <div className="grid grid-cols-3 gap-4">
                <div className="p-4 bg-[#101F3D] border border-[#1E293B] rounded-xl text-center">
                  <span className="text-[11px] text-slate-400 block mb-1">Candidate Files</span>
                  <span className="text-2xl font-bold text-white">
                    {cleanerTargets.reduce((acc, t) => acc + t.fileCount, 0).toLocaleString()}
                  </span>
                </div>
                <div className="p-4 bg-[#101F3D] border border-[#1E293B] rounded-xl text-center">
                  <span className="text-[11px] text-slate-400 block mb-1">Estimated Reclaimable Space</span>
                  <span className="text-2xl font-bold text-[#48CAE4]">
                    {cleanerTargets[0].cleaned ? '0.0 MB' : '3.37 GB'}
                  </span>
                </div>
                <div className="p-4 bg-[#101F3D] border border-[#1E293B] rounded-xl text-center">
                  <span className="text-[11px] text-slate-400 block mb-1">Status</span>
                  <span className="text-2xl font-bold text-emerald-400">
                    {isCleaning ? 'Cleaning...' : cleanerTargets[0].cleaned ? 'Cleaned' : 'Ready'}
                  </span>
                </div>
              </div>

              {/* Targets Table */}
              <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Target Folders (Whitelist-Enforced)</h3>
                  <div className="flex gap-2">
                    <button
                      onClick={() => {
                        setCleanerTargets([
                          {
                            id: 'user_temp',
                            name: "User Temporary Files (%TEMP%)",
                            path: 'C:\\Users\\Admin\\AppData\\Local\\Temp',
                            fileCount: 1420,
                            totalBytes: 2480000000,
                            formattedSize: '2.48 GB',
                            scanned: true,
                            cleaned: false
                          },
                          {
                            id: 'windows_temp',
                            name: "Windows System Temp (C:\\Windows\\Temp)",
                            path: 'C:\\Windows\\Temp',
                            fileCount: 412,
                            totalBytes: 890000000,
                            formattedSize: '890.0 MB',
                            scanned: true,
                            cleaned: false
                          }
                        ]);
                        setCleanedSummary(null);
                        addLog('cleaner::scan', 'Dry-run preview scan refreshed: 1,832 candidate files found.');
                      }}
                      className="px-3 py-1.5 bg-[#1C2541] hover:bg-[#253256] text-xs text-slate-200 rounded border border-[#1E293B]"
                    >
                      Rescan (Dry Run)
                    </button>
                    <button
                      disabled={isCleaning || cleanerTargets[0].cleaned}
                      onClick={handleCleanFiles}
                      className="px-4 py-1.5 bg-emerald-600 hover:bg-emerald-500 disabled:opacity-50 text-white font-bold text-xs rounded transition flex items-center gap-1.5"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                      {isCleaning ? 'Cleaning...' : 'Clean Selected Targets'}
                    </button>
                  </div>
                </div>

                <div className="space-y-2">
                  {cleanerTargets.map(t => (
                    <div key={t.id} className="p-3 bg-[#1C2541] rounded-lg border border-[#1E293B] flex items-center justify-between text-xs">
                      <div>
                        <div className="font-bold text-white">{t.name}</div>
                        <div className="text-[11px] text-slate-400 font-mono mt-0.5">{t.path}</div>
                      </div>
                      <div className="text-right">
                        <span className="font-mono font-bold text-[#48CAE4] block">{t.formattedSize}</span>
                        <span className="text-[10px] text-slate-400">{t.fileCount.toLocaleString()} files</span>
                      </div>
                    </div>
                  ))}
                </div>

                {cleanedSummary && (
                  <div className="p-3 bg-[#0A1128] border border-emerald-500/30 rounded text-xs text-emerald-300 font-mono">
                    {cleanedSummary}
                  </div>
                )}
              </div>
            </div>
          )}

          {/* PAGE 6: WINDOWS REPAIR TOOLS */}
          {activePage === 'windows_tools' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">Windows Repair &amp; Administrative Tools</h2>
                <p className="text-xs text-slate-400">Launch System File Checker (SFC), DISM Component Servicing, and Administrative Snap-ins</p>
              </div>

              {/* Servicing Grid */}
              <div className="grid grid-cols-2 gap-4">
                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <ShieldCheck className="w-4 h-4 text-[#00B4D8]" />
                    System File Integrity (SFC)
                  </h3>
                  <p className="text-xs text-slate-400">
                    Scans Windows protected system files and replaces corrupted or missing components with verified Microsoft backups.
                  </p>
                  <div className="flex gap-2 pt-2">
                    <button
                      onClick={() => addLog('sfc /verifyonly', 'Beginning system scan verification phase...\n[OK] Windows Resource Protection did not find any integrity violations.')}
                      className="flex-1 py-2 bg-[#1C2541] hover:bg-[#253256] text-xs text-slate-200 rounded border border-[#1E293B]"
                    >
                      sfc /verifyonly (Scan Only)
                    </button>
                    <button
                      onClick={() => addLog('sfc /scannow', 'Beginning system scan. This process will take some time.\n[OK] Verification 100% complete. System files are intact.')}
                      className="flex-1 py-2 bg-amber-600 hover:bg-amber-500 text-xs font-bold text-white rounded"
                    >
                      sfc /scannow (Repair)
                    </button>
                  </div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-3">
                  <h3 className="text-sm font-bold text-white flex items-center gap-2">
                    <HardDrive className="w-4 h-4 text-purple-400" />
                    DISM Component Store Servicing
                  </h3>
                  <p className="text-xs text-slate-400">
                    Deployment Image Servicing and Management repairs Windows image and component store corruption.
                  </p>
                  <div className="grid grid-cols-3 gap-2 pt-2 text-xs">
                    <button
                      onClick={() => addLog('DISM /Online /Cleanup-Image /CheckHealth', 'No component store corruption detected. The operation completed successfully.')}
                      className="p-1.5 bg-[#1C2541] hover:bg-[#253256] rounded text-slate-200 border border-[#1E293B]"
                    >
                      CheckHealth
                    </button>
                    <button
                      onClick={() => addLog('DISM /Online /Cleanup-Image /ScanHealth', '[==========================100.0%==========================]\nThe component store is repairable. The operation completed successfully.')}
                      className="p-1.5 bg-[#1C2541] hover:bg-[#253256] rounded text-slate-200 border border-[#1E293B]"
                    >
                      ScanHealth
                    </button>
                    <button
                      onClick={() => addLog('DISM /Online /Cleanup-Image /RestoreHealth', '[==========================100.0%==========================]\nThe restore operation completed successfully.')}
                      className="p-1.5 bg-amber-600 hover:bg-amber-500 rounded text-white font-bold"
                    >
                      RestoreHealth
                    </button>
                  </div>
                </div>
              </div>

              {/* Windows Applets Shortcuts */}
              <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-3">
                <h3 className="text-sm font-bold text-white">Administrative Management Consoles</h3>
                <p className="text-xs text-slate-400">Launch standard Windows 10 management snap-ins</p>
                <div className="grid grid-cols-4 gap-3 pt-1">
                  {[
                    { name: 'Task Manager', bin: 'taskmgr.exe' },
                    { name: 'Device Manager', bin: 'devmgmt.msc' },
                    { name: 'Services Console', bin: 'services.msc' },
                    { name: 'Event Viewer', bin: 'eventvwr.msc' },
                    { name: 'Disk Management', bin: 'diskmgmt.msc' },
                    { name: 'Windows Update', bin: 'ms-settings:windowsupdate' },
                    { name: 'Network Connections', bin: 'ncpa.cpl' },
                    { name: 'System Information', bin: 'msinfo32.exe' },
                  ].map(a => (
                    <button
                      key={a.name}
                      onClick={() => addLog(`start ${a.bin}`, `Launched Windows applet: ${a.name} (${a.bin})`)}
                      className="p-3 bg-[#1C2541] hover:bg-[#253256] rounded border border-[#1E293B] text-xs font-semibold text-slate-200 text-left transition"
                    >
                      <div className="text-white">{a.name}</div>
                      <div className="text-[10px] text-slate-400 font-mono mt-0.5">{a.bin}</div>
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* PAGE 7: SYSTEM INFORMATION */}
          {activePage === 'system_info' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white">Comprehensive System Information</h2>
                  <p className="text-xs text-slate-400">Detailed hardware configuration, storage volumes, and network interfaces</p>
                </div>
                <button
                  onClick={() => {
                    const text = `PC CARE PRO - SYSTEM DIAGNOSTIC REPORT\nGenerated: ${new Date().toLocaleString()}\nComputer Name: ${SYSTEM_INFO.computerName}\nOS: ${SYSTEM_INFO.osName} (Build ${SYSTEM_INFO.osBuild})\nProcessor: ${SYSTEM_INFO.processor}\nRAM: ${SYSTEM_INFO.totalRamGb} GB\nIP: ${SYSTEM_INFO.localIpv4}\nGateway: ${SYSTEM_INFO.defaultGateway}\nDNS: ${SYSTEM_INFO.primaryDns}, ${SYSTEM_INFO.secondaryDns}`;
                    const blob = new Blob([text], { type: 'text/plain' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `pc_care_pro_system_${Date.now()}.txt`;
                    a.click();
                  }}
                  className="px-3.5 py-1.5 bg-[#00B4D8] hover:bg-[#48CAE4] text-[#0A1128] font-bold text-xs rounded transition flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export to TXT Report
                </button>
              </div>

              <div className="grid grid-cols-2 gap-6">
                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                  <h3 className="text-sm font-bold text-white">Hardware &amp; Architecture</h3>
                  <div className="space-y-2 text-xs">
                    <div className="flex justify-between py-1 border-b border-[#1E293B]"><span className="text-slate-400">Computer Hostname:</span><span className="font-mono text-white">{SYSTEM_INFO.computerName}</span></div>
                    <div className="flex justify-between py-1 border-b border-[#1E293B]"><span className="text-slate-400">Processor:</span><span className="text-white font-semibold">{SYSTEM_INFO.processor}</span></div>
                    <div className="flex justify-between py-1 border-b border-[#1E293B]"><span className="text-slate-400">Core Topology:</span><span className="text-[#48CAE4]">{SYSTEM_INFO.cores} Physical Cores, {SYSTEM_INFO.logicalProcessors} Logical Threads</span></div>
                    <div className="flex justify-between py-1 border-b border-[#1E293B]"><span className="text-slate-400">Physical Memory:</span><span className="text-white font-mono">{SYSTEM_INFO.totalRamGb} GB DDR4</span></div>
                    <div className="flex justify-between py-1"><span className="text-slate-400">System Uptime:</span><span className="text-emerald-400">{SYSTEM_INFO.uptime}</span></div>
                  </div>
                </div>

                <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                  <h3 className="text-sm font-bold text-white">Storage Volume Geometry</h3>
                  <div className="space-y-3">
                    {SYSTEM_INFO.partitions.map(p => (
                      <div key={p.drive} className="p-3 bg-[#1C2541] rounded border border-[#1E293B] text-xs">
                        <div className="flex justify-between font-bold text-white mb-1">
                          <span>Drive {p.drive} ({p.label})</span>
                          <span className="font-mono text-[#48CAE4]">{p.fstype}</span>
                        </div>
                        <div className="flex justify-between text-[11px] text-slate-400 mb-1.5">
                          <span>Used: {p.usedGb} GB / {p.totalGb} GB</span>
                          <span className="text-emerald-400 font-bold">{p.freeGb} GB Free</span>
                        </div>
                        <div className="w-full bg-[#101F3D] h-1.5 rounded-full overflow-hidden">
                          <div className="bg-[#00B4D8] h-full" style={{ width: `${p.percentUsed}%` }}></div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* PAGE 8: COMMAND CONSOLE */}
          {activePage === 'console' && (
            <div className="space-y-4 h-full flex flex-col">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white">Command Console &amp; Terminal</h2>
                  <p className="text-xs text-slate-400">Real-time output stream for native Windows diagnostic subprocesses</p>
                </div>
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      const all = logs.map(l => `[${l.timestamp}] > ${l.command}\n${l.stdout}`).join('\n\n');
                      navigator.clipboard.writeText(all);
                      alert('Console logs copied to clipboard!');
                    }}
                    className="px-3 py-1.5 bg-[#1C2541] hover:bg-[#253256] text-xs text-slate-200 rounded border border-[#1E293B] flex items-center gap-1.5"
                  >
                    <Copy className="w-3.5 h-3.5" />
                    Copy All
                  </button>
                  <button
                    onClick={() => setLogs([])}
                    className="px-3 py-1.5 bg-[#1C2541] hover:bg-[#253256] text-xs text-slate-200 rounded border border-[#1E293B]"
                  >
                    Clear Console
                  </button>
                </div>
              </div>

              <div className="flex-1 bg-[#101F3D] border border-[#1E293B] rounded-xl p-4 flex flex-col overflow-hidden">
                <div className="flex-1 bg-[#0A1128] rounded-lg p-3 font-mono text-[11px] text-sky-300 overflow-y-auto space-y-3">
                  {logs.map(log => (
                    <div key={log.id} className="border-b border-slate-900/60 pb-2">
                      <div className="flex items-center justify-between text-slate-400 text-[10px] mb-1">
                        <span className="font-bold text-[#48CAE4]">&gt; {log.command}</span>
                        <span>[{log.timestamp}] ({log.durationSec}s)</span>
                      </div>
                      <pre className="whitespace-pre-wrap text-slate-200">{log.stdout}</pre>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* PAGE 9: LOGS AND REPORTS */}
          {activePage === 'reports' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white">Application Logs &amp; Diagnostic Reports</h2>
                  <p className="text-xs text-slate-400">Rotating application logs and exportable technical support bundles</p>
                </div>
                <button
                  onClick={() => {
                    const data = {
                      app: "PC Care Pro",
                      version: "1.0.0",
                      timestamp: new Date().toISOString(),
                      system: SYSTEM_INFO,
                      repairs: repairsHistory,
                      logs
                    };
                    const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
                    const url = URL.createObjectURL(blob);
                    const a = document.createElement('a');
                    a.href = url;
                    a.download = `pc_care_pro_bundle_${Date.now()}.json`;
                    a.click();
                  }}
                  className="px-3.5 py-1.5 bg-[#00B4D8] hover:bg-[#48CAE4] text-[#0A1128] font-bold text-xs rounded transition flex items-center gap-1.5"
                >
                  <Download className="w-3.5 h-3.5" />
                  Export Diagnostic Package (JSON)
                </button>
              </div>

              <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-3">
                <div className="flex items-center justify-between">
                  <h3 className="text-sm font-bold text-white">Log Storage Location</h3>
                  <span className="text-xs font-mono text-slate-400">%APPDATA%\PCCarePro\logs\pc_care_pro.log</span>
                </div>
                <pre className="p-3 bg-[#0A1128] rounded border border-[#1E293B] font-mono text-[11px] text-slate-300 h-64 overflow-y-auto">
{`2026-11-01 00:38:00 [INFO] [PCCarePro] === PC Care Pro Application Logger Initialized ===
2026-11-01 00:38:00 [INFO] [PCCarePro] Starting PC Care Pro v1.0.0 - Windows Network & System Maintenance Toolkit
2026-11-01 00:38:00 [INFO] [PCCarePro] Process privilege level: Administrator (Elevated)
2026-11-01 00:38:01 [INFO] [PCCarePro] Executing: ping -n 4 -w 2000 8.8.8.8 (timeout: 30s)
2026-11-01 00:38:02 [INFO] [PCCarePro] Completed 'ping' in 0.85s with code 0
2026-11-01 00:38:05 [INFO] [PCCarePro] Initiating safe dry-run scan on: C:\\Users\\Admin\\AppData\\Local\\Temp
2026-11-01 00:38:06 [INFO] [PCCarePro] Scan completed: 1,420 files scanned (2.48 GB recoverable)
2026-11-01 00:38:10 [INFO] [PCCarePro] Automated unit test suite executed: 30/30 tests passed`}
                </pre>
              </div>
            </div>
          )}

          {/* PAGE 10: SETTINGS */}
          {activePage === 'settings' && (
            <div className="space-y-6">
              <div>
                <h2 className="text-xl font-bold text-white">Settings &amp; Preferences</h2>
                <p className="text-xs text-slate-400">Configure default ping parameters and confirmation alerts</p>
              </div>

              <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4 max-w-xl">
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Default Ping Target</label>
                  <input
                    type="text"
                    value={pingTarget}
                    onChange={e => setPingTarget(e.target.value)}
                    className="w-full bg-[#1C2541] border border-[#1E293B] rounded px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Default Ping Count</label>
                  <input
                    type="number"
                    value={pingCount}
                    onChange={e => setPingCount(e.target.value)}
                    className="w-full bg-[#1C2541] border border-[#1E293B] rounded px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div>
                  <label className="text-xs text-slate-400 block mb-1">Default Ping Timeout (ms)</label>
                  <input
                    type="number"
                    value={pingTimeout}
                    onChange={e => setPingTimeout(e.target.value)}
                    className="w-full bg-[#1C2541] border border-[#1E293B] rounded px-3 py-1.5 text-xs text-white"
                  />
                </div>
                <div className="pt-2">
                  <button
                    onClick={() => alert('Settings persisted to %APPDATA%\\PCCarePro\\settings.json')}
                    className="px-4 py-2 bg-[#00B4D8] hover:bg-[#48CAE4] text-[#0A1128] font-bold text-xs rounded transition"
                  >
                    Save Preferences
                  </button>
                </div>
              </div>
            </div>
          )}

          {/* PAGE 11: ABOUT */}
          {activePage === 'about' && (
            <div className="space-y-6 max-w-2xl">
              <div className="bg-[#101F3D] border border-[#1E293B] p-6 rounded-xl space-y-4 text-center">
                <div className="w-14 h-14 rounded-2xl bg-gradient-to-tr from-[#0077B6] to-[#00B4D8] flex items-center justify-center shadow-lg shadow-[#00B4D8]/30 mx-auto">
                  <Laptop className="w-8 h-8 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-bold text-white">PC Care Pro</h2>
                  <p className="text-xs text-[#48CAE4] mt-0.5">Windows 10 Network Diagnostics, Internet Troubleshooting &amp; Maintenance Suite</p>
                  <p className="text-xs text-slate-400 mt-1">Version 1.0.0 (Production Release)</p>
                </div>

                <div className="p-4 bg-[#0A1128] rounded-lg text-xs text-slate-300 text-left space-y-2 border border-[#1E293B]">
                  <p className="font-semibold text-white">Key Architectural Features:</p>
                  <ul className="list-disc pl-5 space-y-1 text-slate-400">
                    <li><strong className="text-slate-200">Offline-First</strong>: Operates 100% locally with zero cloud dependencies or telemetry.</li>
                    <li><strong className="text-slate-200">Defensive Execution</strong>: Subprocess execution uses explicit argument vectors and strict regex sanitizers with shell=False.</li>
                    <li><strong className="text-slate-200">Safe Cleaner</strong>: Restricts operations to verified temporary directories (%TEMP%, C:\Windows\Temp) and guarantees personal files are untouched.</li>
                    <li><strong className="text-slate-200">Test-Driven Development</strong>: 30 verified automated tests covering all services, parsers, and command builders.</li>
                  </ul>
                </div>

                <div className="text-[11px] text-slate-500">
                  Distributed under the MIT License • Built for Windows 10 (64-bit)
                </div>
              </div>
            </div>
          )}

          {/* PAGE: PYTHON ARCHITECTURE & LIVE TEST SUITE */}
          {activePage === 'python_suite' && (
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <div>
                  <h2 className="text-xl font-bold text-white flex items-center gap-2">
                    <Code2 className="w-5 h-5 text-[#48CAE4]" />
                    Python 3 Standalone Suite &amp; Automated Tests
                  </h2>
                  <p className="text-xs text-slate-400">Full source code repository in pc_care_pro/ with 30 passing unit and integration tests</p>
                </div>
                <div className="flex items-center gap-2">
                  <span className="px-2.5 py-1 rounded bg-emerald-950/80 border border-emerald-500/40 text-emerald-300 font-mono text-xs font-bold flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                    30 / 30 Tests Passing
                  </span>
                </div>
              </div>

              {/* Test Suite Summary Banner */}
              <div className="p-4 bg-[#101F3D] border border-[#1E293B] rounded-xl grid grid-cols-4 gap-4 text-center text-xs">
                <div>
                  <span className="text-[11px] text-slate-400 block">Unit Tests</span>
                  <span className="text-lg font-bold text-white font-mono">26 Passing</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Integration Tests</span>
                  <span className="text-lg font-bold text-white font-mono">4 Passing</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Windows Live Tests</span>
                  <span className="text-lg font-bold text-[#48CAE4] font-mono">Guarded (skipUnless)</span>
                </div>
                <div>
                  <span className="text-[11px] text-slate-400 block">Build Script</span>
                  <span className="text-lg font-bold text-emerald-400 font-mono">build.bat (PyInstaller)</span>
                </div>
              </div>

              {/* Codebase File Viewer */}
              <div className="bg-[#101F3D] border border-[#1E293B] p-5 rounded-xl space-y-4">
                <h3 className="text-sm font-bold text-white">Repository File Structure</h3>
                <div className="grid grid-cols-3 gap-3 text-xs">
                  {[
                    { path: 'pc_care_pro/main.py', desc: 'Entry point, logging init, UAC detection, CTk loop' },
                    { path: 'pc_care_pro/app/application.py', desc: 'CustomTkinter root coordinator and DI service container' },
                    { path: 'pc_care_pro/app/core/command_executor.py', desc: 'Threaded subprocess runner with timeout & cancellation' },
                    { path: 'pc_care_pro/app/core/validators.py', desc: 'Regex sanitizers for IPs, hostnames, interface names' },
                    { path: 'pc_care_pro/app/core/admin_manager.py', desc: 'Win32 Shell32 IsUserAnAdmin UAC bridge' },
                    { path: 'pc_care_pro/app/services/network_service.py', desc: 'Ping parser, ipconfig, tracert, nslookup, netstat' },
                    { path: 'pc_care_pro/app/services/wifi_service.py', desc: 'netsh wlan parser, zero-credential-leakage rules' },
                    { path: 'pc_care_pro/app/services/repair_service.py', desc: 'Winsock, TCP/IP, firewall repair with audit history' },
                    { path: 'pc_care_pro/app/services/cleaner_service.py', desc: 'Path-whitelisted safe temporary file scanner & remover' },
                    { path: 'pc_care_pro/app/services/system_service.py', desc: 'CPU, RAM, disk partitions, SFC & DISM runners' },
                    { path: 'pc_care_pro/app/services/report_service.py', desc: 'TXT & JSON diagnostic support package exporter' },
                    { path: 'pc_care_pro/build.bat', desc: 'Automated test execution and PyInstaller single-EXE compiler' },
                  ].map(file => (
                    <div key={file.path} className="p-3 bg-[#1C2541] rounded border border-[#1E293B] space-y-1">
                      <div className="font-mono font-bold text-[#48CAE4] text-[11px] truncate">{file.path}</div>
                      <div className="text-[11px] text-slate-400">{file.desc}</div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

        </div>
      </main>
    </div>
  );
}
