export type PageId =
  | 'dashboard'
  | 'diagnostics'
  | 'wifi'
  | 'repair'
  | 'cleaner'
  | 'windows_tools'
  | 'system_info'
  | 'console'
  | 'reports'
  | 'settings'
  | 'about'
  | 'python_suite';

export interface ConsoleLogEntry {
  id: string;
  timestamp: string;
  command: string;
  status: 'running' | 'success' | 'error' | 'warning';
  stdout: string;
  stderr?: string;
  durationSec?: number;
}

export interface RepairAuditItem {
  id: string;
  timestamp: string;
  name: string;
  status: 'success' | 'error';
  summary: string;
  details: string;
  requiresReboot: boolean;
}

export interface CleanerTarget {
  id: string;
  name: string;
  path: string;
  fileCount: number;
  totalBytes: number;
  formattedSize: string;
  scanned: boolean;
  cleaned: boolean;
}
